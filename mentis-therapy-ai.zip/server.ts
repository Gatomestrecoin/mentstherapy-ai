import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.post("/api/gemini/analyze-session", async (req, res) => {
    try {
      const { transcript, patientContext } = req.body;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analise a seguinte transcrição de uma sessão de terapia. 
        Contexto do paciente: ${patientContext}
        Transcrição: ${transcript}
        
        Por favor, forneça uma análise profunda contendo:
        1. Resumo da sessão
        2. Emoções detectadas (infira o tom de voz e estado emocional pela transcrição)
        3. Temperamento predominante (melancólico, sanguíneo, fleumático, colérico)
        4. Palavras-chave emocionais (termos que carregam forte carga afetiva)
        5. Padrões repetitivos (frases, comportamentos ou ciclos que se repetem)
        6. Temas da sessão (organize o que foi falado em temas principais)
        7. Mapeamento de traumas e crenças (identifique possíveis traumas e crenças limitantes citados ou implícitos)
        8. Evolução do paciente (como o paciente progrediu em relação a sessões anteriores com base no contexto)
        9. Sugestões de intervenções terapêuticas
        10. Sugestões de perguntas para a próxima sessão
        11. Hipóteses clínicas (apenas sugestões)`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              summary: { type: Type.STRING },
              emotions: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              temperament: { type: Type.STRING },
              emotionalKeywords: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              repetitivePatterns: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              themes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    theme: { type: Type.STRING },
                    content: { type: Type.STRING }
                  }
                }
              },
              traumaMapping: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              beliefMapping: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              patientEvolution: { type: Type.STRING },
              therapeuticInterventions: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              suggestedQuestions: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              clinicalHypothesis: { type: Type.STRING }
            },
            required: [
              "summary", "emotions", "temperament", "emotionalKeywords", 
              "repetitivePatterns", "themes", "traumaMapping", "beliefMapping", 
              "patientEvolution", "therapeuticInterventions", "suggestedQuestions", 
              "clinicalHypothesis"
            ]
          }
        }
      });

      res.json(JSON.parse(response.text || "{}"));
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Failed to analyze session" });
    }
  });

  app.post("/api/gemini/analyze-time-tunnel", async (req, res) => {
    try {
      const { blockTitle, responses, patientContext } = req.body;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Analise as seguintes respostas do questionário "Túnel do Tempo" (Investigação Emocional Profunda). 
        Contexto do paciente: ${patientContext}
        Bloco: ${blockTitle}
        Respostas: ${JSON.stringify(responses)}
        
        Por favor, forneça uma análise profunda para este bloco contendo:
        1. Traumas emocionais identificados (fatos marcantes)
        2. Padrões repetitivos detectados (comportamentos que se repetem)
        3. Crenças limitantes criadas a partir destas experiências
        4. Emoções predominantes neste período/tema
        5. Gatilhos específicos identificados nestas respostas
        6. Palavras-chave traumáticas detectadas`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              traumas: { type: Type.ARRAY, items: { type: Type.STRING } },
              patterns: { type: Type.ARRAY, items: { type: Type.STRING } },
              beliefs: { type: Type.ARRAY, items: { type: Type.STRING } },
              emotions: { type: Type.ARRAY, items: { type: Type.STRING } },
              triggers: { type: Type.ARRAY, items: { type: Type.STRING } },
              traumaticWords: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["traumas", "patterns", "beliefs", "emotions", "triggers", "traumaticWords"]
          }
        }
      });

      res.json(JSON.parse(response.text || "{}"));
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Failed to analyze time tunnel block" });
    }
  });

  app.post("/api/gemini/generate-time-tunnel-report", async (req, res) => {
    try {
      const { allBlocks, patientContext } = req.body;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Gere um relatório final consolidado para o questionário "Túnel do Tempo" (Investigação Emocional Profunda). 
        Contexto do paciente: ${patientContext}
        Dados de todos os blocos: ${JSON.stringify(allBlocks)}
        
        Por favor, forneça:
        1. Mapa emocional completo (Visão geral técnica e psicanalítica)
        2. Principais traumas (Lista hierárquica por impacto)
        3. Gatilhos emocionais identificados (O que ativa a dor hoje)
        4. Emoções predominantes ao longo da história
        5. Crenças criadas (Padrões de pensamento enraizados)
        6. Resumo terapêutico automático (Sugestão de abordagem para o terapeuta)
        7. Linha do tempo emocional (Períodos e eventos marcantes de 0 anos até hoje)
        8. Áreas prioritárias para tratamento (Onde focar nas próximas sessões)`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              emotionalMap: { type: Type.STRING },
              mainTraumas: { type: Type.ARRAY, items: { type: Type.STRING } },
              triggers: { type: Type.ARRAY, items: { type: Type.STRING } },
              predominantEmotions: { type: Type.ARRAY, items: { type: Type.STRING } },
              coreBeliefs: { type: Type.ARRAY, items: { type: Type.STRING } },
              summary: { type: Type.STRING },
              timeline: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT,
                  properties: {
                    period: { type: Type.STRING },
                    events: { type: Type.ARRAY, items: { type: Type.STRING } }
                  }
                }
              },
              priorityAreas: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["emotionalMap", "mainTraumas", "triggers", "predominantEmotions", "coreBeliefs", "summary", "timeline", "priorityAreas"]
          }
        }
      });

      res.json(JSON.parse(response.text || "{}"));
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Failed to generate final report" });
    }
  });

  app.post("/api/gemini/generate-hypnosis", async (req, res) => {
    try {
      const { objective, patientProfile, selectedFocus } = req.body;
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Crie um roteiro avançado de hipnoterapia inteligente baseado em Psicanálise, Hipnose Clínica e Reprogramação Emocional.
        
        OBJETIVO: ${objective}
        PERFIL DO PACIENTE: ${patientProfile}
        ÁREAS DE FOCO: ${selectedFocus.join(", ")}
        
        ESTRUTURA OBRIGATÓRIA DO ROTEIRO:
        1. Indução Hipnótica (Foco no relaxamento consciente)
        2. Relaxamento Profundo (Aprofundamento progressivo)
        3. Respiração Guiada (Técnicas de regulação vagal)
        4. Visualização Terapêutica (Criação de cenário seguro e simbólico)
        5. Ressignificação Emocional (Tratamento direto dos traumas/crenças citados)
        6. Fortalecimento Mental (Afirmações de empoderamento)
        7. Reprogramação Emocional (Substituição de padrões negativos por positivos)
        8. Sugestões Pós-Hipnóticas (Diretrizes para o cotidiano)
        9. Encerramento Terapêutico (Retorno gradual e ancoragem de bem-estar)
        
        Use uma linguagem que se conecte ao tom de voz e emoções prováveis do paciente baseadas no perfil.`,
        config: {
          systemInstruction: "Você é um mestre hipnoterapeuta clínico e psicanalista especializado em reprogramação mental rápida e ética."
        }
      });
      res.json({ script: response.text });
    } catch (error) {
       console.error("Gemini Error:", error);
       res.status(500).json({ error: "Failed to generate hypnosis script" });
    }
  });

  app.post("/api/gemini/personalize-habits", async (req, res) => {
    try {
      const { patientContext, currentMood, recentStressLevel } = req.body;
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Como um mentor de alta performance e neurocientista, sugira uma rotina personalizada de hábitos para este paciente.
        
        CONTEXTO DO PACIENTE: ${patientContext}
        HUMOR ATUAL: ${currentMood}
        NÍVEL DE ESTRESSE RECENTE: ${recentStressLevel}
        
        Por favor, forneça:
        1. 3 hábitos prioritários para hoje baseados no estado emocional.
        2. Um desafio de 7 dias para uma área específica (amor, saúde, etc).
        3. Uma frase motivacional profunda e personalizada.
        4. Uma mini-meditação ou exercício de respiração rápido.
        5. Explicação científica (breve) de por que esses hábitos ajudarão agora.
        6. Identificação de padrões emocionais ou necessidades (ex: vazio emocional, necessidade de propósito, excesso de ansiedade, desconexão emocional).`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              priorityHabits: { 
                type: Type.ARRAY, 
                items: { 
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    description: { type: Type.STRING }
                  }
                } 
              },
              sevenDayChallenge: {
                type: Type.OBJECT,
                properties: {
                  area: { type: Type.STRING },
                  goal: { type: Type.STRING },
                  dailyAction: { type: Type.STRING }
                }
              },
              motivationalQuote: { type: Type.STRING },
              quickExercise: { type: Type.STRING },
              scientificRationale: { type: Type.STRING },
              identifiedPatterns: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Emotional or behavioral patterns identified by AI (e.g., emptiness, anxiety)"
              }
            },
            required: ["priorityHabits", "sevenDayChallenge", "motivationalQuote", "quickExercise", "scientificRationale", "identifiedPatterns"]
          }
        }
      });
      res.json(JSON.parse(response.text || "{}"));
    } catch (error) {
      console.error("Gemini Error:", error);
      res.status(500).json({ error: "Failed to personalize habits" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
