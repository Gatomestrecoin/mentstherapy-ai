import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  BarChart, 
  Users, 
  Calendar, 
  Target,
  Brain, 
  Wind, 
  ClipboardList, 
  CheckCircle2, 
  FileText, 
  ShieldAlert, 
  Settings as SettingsIcon,
  LayoutDashboard,
  History,
  Menu,
  X,
  Plus,
  Search,
  ChevronRight,
  TrendingUp,
  BrainCircuit,
  MessageSquare,
  Mic,
  Activity,
  Sparkles,
  Crown,
  Shield
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from './lib/utils';
import Dashboard from './components/Dashboard';
import PatientsList from './components/PatientsList';
import AnamneseProfunda from './components/AnamneseProfunda';
import TherapeuticPlan from './components/TherapeuticPlan';
import Hypnotherapy from './components/Hypnotherapy';
import Reports from './components/Reports';
import Habits from './components/Habits';
import TimeTunnel from './components/TimeTunnel';
import PsychologicalAssessment from './components/PsychologicalAssessment';
import Settings from './components/Settings';
import Subscriptions from './components/Subscriptions';
import Login from './components/Login';
import Register from './components/Register';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Patient, Session } from './types';

function Sidebar({ open, setOpen }: { open: boolean; setOpen: (o: boolean) => void }) {
  const location = useLocation();
  const { logout, user } = useAuth();
  const menuItems = [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/' },
    { name: 'Meus Pacientes', icon: Users, path: '/patients' },
    { name: 'Anamnese Viva IA', icon: Sparkles, path: '/initial-assessment' },
    { name: 'Avaliação Mental', icon: BarChart, path: '/psychological-assessment' },
    { name: 'Plano de Jornada', icon: Target, path: '/therapeutic-plan' },
    { name: 'Túnel do Tempo', icon: History, path: '/time-tunnel' },
    { name: 'Rituais & Hábitos', icon: CheckCircle2, path: '/habits' },
    { name: 'Gerador de Relatórios', icon: FileText, path: '/reports' },
    { name: 'Planos & Assinaturas', icon: Crown, path: '/subscriptions' },
    { name: 'Configurações Inteligentes', icon: SettingsIcon, path: '/settings' },
  ];

  return (
    <>
      <div className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-slate-950 border-r border-white/5 transform transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0",
        open ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="h-full flex flex-col">
          <div className="p-6 flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <Brain size={24} />
            </div>
            <span className="text-xl font-bold text-white tracking-tight italic-serif">Mentis Therapy AI</span>
          </div>

          <nav className="flex-1 px-4 space-y-1">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setOpen(false)}
                className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 group border-l-4",
                  location.pathname === item.path
                    ? "bg-indigo-500/10 text-indigo-400 border-indigo-500"
                    : "text-slate-400 hover:bg-white/5 hover:text-white border-transparent"
                )}
              >
                <item.icon size={20} className={cn(
                  location.pathname === item.path ? "text-indigo-400" : "text-slate-500 group-hover:text-slate-300"
                )} />
                <span className="font-medium">{item.name}</span>
              </Link>
            ))}
          </nav>

          <div className="p-4 space-y-4">
            <button 
              onClick={logout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg text-rose-400 hover:bg-rose-500/10 transition-all font-medium"
            >
              <X size={20} />
              Sair do Sistema
            </button>

            <div className="bg-indigo-600/10 border border-indigo-500/20 rounded-xl p-4 text-indigo-300">
              <p className="text-[10px] font-bold uppercase tracking-wider opacity-60 mb-1">Criptografia Ativa</p>
              <p className="text-xs font-medium mb-3">Protocolo Zero-Knowledge</p>
              <div className="flex items-center gap-2 text-[10px] bg-white/5 p-2 rounded-lg">
                <ShieldAlert size={12} />
                <span>Mentis Cloud Vault v1.0</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function MainApp() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
        <div className="w-16 h-16 bg-indigo-500 rounded-2xl flex items-center justify-center text-white animate-pulse mb-6">
          <Brain size={32} />
        </div>
        <div className="w-48 bg-white/5 h-1 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            transition={{ duration: 2, repeat: Infinity }}
            className="h-full bg-indigo-500"
          />
        </div>
        <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mt-4">Sincronizando Cognição Digital...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="*" element={<Login />} />
      </Routes>
    );
  }

  return (
    <div className="flex h-screen bg-slate-950 overflow-hidden font-sans text-slate-300">
      <Sidebar open={sidebarOpen} setOpen={setSidebarOpen} />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden bg-slate-950/50">
        <header className="h-16 bg-slate-950/50 backdrop-blur-xl border-b border-white/5 flex items-center justify-between px-4 lg:px-8 shrink-0 relative z-40">
          <button 
            onClick={() => setSidebarOpen(true)}
            className="p-2 -ml-2 lg:hidden text-slate-400"
          >
            <Menu size={24} />
          </button>
          <div className="relative max-w-sm flex-1 hidden lg:block">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-600" size={18} />
            <input 
              type="text" 
              placeholder="Pesquisar consciência..."
              className="w-full bg-white/5 border border-white/5 rounded-full py-2 pl-10 pr-4 text-sm text-slate-300 focus:bg-white/10 focus:border-indigo-500/50 transition-all outline-none"
            />
          </div>
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-slate-500 hover:text-white transition-colors">
              <Activity size={20} />
              <span className="absolute top-1 right-1 w-2 h-2 bg-emerald-500 rounded-full shadow-lg shadow-emerald-500/50"></span>
            </button>
            <div className="flex items-center gap-3 pl-4 border-l border-white/10">
              <div className="hidden sm:block text-right">
                <p className="text-sm font-semibold text-white leading-tight">{user?.name || 'Dr. Fernando Silva'}</p>
                <p className="text-[10px] uppercase font-bold tracking-widest text-slate-500">{user?.profession || 'Mestre de Análise'}</p>
              </div>
              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-indigo-900 flex items-center justify-center text-white font-bold shadow-lg shadow-indigo-500/20">
                {user?.name?.split(' ').map(n => n[0]).join('') || 'FS'}
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 lg:p-8">
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<Dashboard patients={patients} sessions={sessions} />} />
              <Route path="/patients" element={<PatientsList patients={patients} setPatients={setPatients} />} />
              <Route path="/therapeutic-plan" element={<TherapeuticPlan patients={patients} />} />
              <Route path="/time-tunnel" element={<TimeTunnel patients={patients} />} />
              <Route path="/initial-assessment" element={<AnamneseProfunda patients={patients} />} />
              <Route path="/psychological-assessment" element={<PsychologicalAssessment patients={patients} />} />
              <Route path="/hypnotherapy" element={<Hypnotherapy />} />
              <Route path="/habits" element={<Habits patients={patients} />} />
              <Route path="/reports" element={<Reports sessions={sessions} patients={patients} />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="/subscriptions" element={<Subscriptions />} />
              <Route path="*" element={<Dashboard patients={patients} sessions={sessions} />} />
            </Routes>
          </AnimatePresence>

          {/* Professional Copyright Footer */}
          <footer className="mt-16 pt-8 pb-4 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 opacity-30 hover:opacity-80 transition-opacity duration-500">
             <div className="flex flex-col items-center md:items-start gap-1">
                <p className="text-[10px] font-black text-white uppercase tracking-[0.3em]">Sistema Mentis AI — Professional Clinical Suite</p>
                <p className="text-[10px] text-slate-500 font-medium">Todos os direitos reservados à Propriedade Intelectual do Criador.</p>
             </div>
             <div className="flex items-center gap-2 px-6 py-2 bg-indigo-500/5 rounded-full border border-indigo-500/10">
                <Shield size={12} className="text-indigo-400" />
                <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none">
                  Direito de Exclusividade: <span className="text-white">Renato Fernandes</span>
                </span>
             </div>
             <div className="text-[9px] font-bold text-slate-600 uppercase tracking-widest text-center md:text-right">
                CPF: 014.061.056-19 <br />
                <span className="text-slate-700 italic">Contagem, Minas Gerais — 2026</span>
             </div>
          </footer>
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <MainApp />
      </AuthProvider>
    </Router>
  );
}

