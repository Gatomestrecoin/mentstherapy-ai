import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';
import { 
  Users, 
  Calendar as CalendarIcon, 
  TrendingUp, 
  AlertCircle, 
  Clock,
  ChevronRight,
  Brain,
  Timer as TimerIcon,
  Play,
  RotateCcw,
  Zap,
  ShieldAlert,
  MessageSquare,
  Smile,
  Meh,
  Frown,
  Activity,
  Heart,
  Target,
  ArrowRight,
  Search,
  CheckCircle2,
  Bell,
  Shield
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  BarChart,
  Bar,
  Cell
} from 'recharts';
import { cn } from '../lib/utils';
import { Patient, Session } from '../types';
import { useAuth } from '../contexts/AuthContext';

const AI_QUOTES = [
  "Cada sessão pode mudar uma história.",
  "Escutar também é uma forma de cura.",
  "Acolher é transformar.",
  "O autoconhecimento é o início da liberdade.",
  "A mente é um universo esperando para ser explorado.",
  "A transformação silenciosa é a que mais ecoa.",
];

const EMOTIONAL_TREND_DATA = [
  { name: 'Seg', valor: 65 },
  { name: 'Ter', valor: 58 },
  { name: 'Qua', valor: 72 },
  { name: 'Qui', valor: 60 },
  { name: 'Sex', valor: 55 },
  { name: 'Sáb', valor: 48 },
];

const TEMPERAMENT_DATA = [
  { subject: 'Colérico', A: 80, fullMark: 100 },
  { subject: 'Sanguíneo', A: 65, fullMark: 100 },
  { subject: 'Fleumático', A: 45, fullMark: 100 },
  { subject: 'Melancólico', A: 90, fullMark: 100 },
];

export default function Dashboard({ patients, sessions }: { patients: Patient[], sessions: Session[] }) {
  const { user } = useAuth();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [timerActive, setTimerActive] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [dailyQuote, setDailyQuote] = useState(AI_QUOTES[0]);
  const [showAssistant, setShowAssistant] = useState(false);
  const [professionalMood, setProfessionalMood] = useState<null | 'good' | 'neutral' | 'bad'>(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    setDailyQuote(AI_QUOTES[Math.floor(Math.random() * AI_QUOTES.length)]);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    let interval: any;
    if (timerActive) {
      interval = setInterval(() => setTimerSeconds(s => s + 1), 1000);
    }
    return () => clearInterval(interval);
  }, [timerActive]);

  const formatTimer = (totalSeconds: number) => {
    const hrs = Math.floor(totalSeconds / 3600);
    const mins = Math.floor((totalSeconds % 3600) / 60);
    const secs = totalSeconds % 60;
    return `${hrs.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const dayName = currentTime.toLocaleDateString('pt-BR', { weekday: 'long' });
  const fullDate = currentTime.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' });

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8 pb-10"
    >
      {/* Header Top Badge */}
      <div className="flex justify-between items-center mb-6">
         <div className="flex items-center gap-2 px-4 py-1.5 bg-white/5 border border-white/10 rounded-full">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-lg shadow-emerald-500/50"></div>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Sistema Operacional Verificado</span>
         </div>
         <div className="flex items-center gap-2">
            <Shield size={14} className="text-indigo-400" />
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest italic">Licenciado para Renato Fernandes</span>
         </div>
      </div>

      {/* Trial Alert Banner */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 bg-gradient-to-r from-rose-500/10 via-rose-500/5 to-transparent border border-rose-500/20 rounded-[1.5rem] flex items-center justify-between gap-4 backdrop-blur-md"
      >
        <div className="flex items-center gap-4">
           <div className="w-10 h-10 bg-rose-500/20 rounded-xl flex items-center justify-center text-rose-400">
              <Clock size={20} className="animate-pulse" />
           </div>
           <div>
              <p className="text-xs font-black text-rose-400 uppercase tracking-widest">Seu teste gratuito Trial IA expira em breve</p>
              <p className="text-[10px] text-slate-400 font-medium italic">Faltam 06 dias 14h 22min para o encerramento do seu acesso premium.</p>
           </div>
        </div>
        <button 
          onClick={() => window.location.href = '/subscriptions'}
          className="px-6 py-2 bg-rose-500 hover:bg-rose-600 text-white text-[10px] font-black uppercase tracking-widest rounded-xl transition-all shadow-lg shadow-rose-500/20"
        >
          Fazer Upgrade Agora
        </button>
      </motion.div>

      {/* Top Bar: Greeting & Real-time Clock */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-slate-900/40 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/5 shadow-2xl relative overflow-hidden group">
        <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500 opacity-50" />
        
        <div className="space-y-1 relative z-10">
          <h1 className="text-3xl font-bold text-white tracking-tight italic-serif flex items-center gap-3">
            Bom dia, {user?.name?.split(' ')[0] || 'Dr. Renato'} 👋
          </h1>
          <p className="text-indigo-400 font-bold italic-serif italic text-lg opacity-80">
            "{dailyQuote}"
          </p>
        </div>

        <div className="flex items-center gap-8 relative z-10">
          <div className="text-right">
            <div className="flex items-center justify-end gap-2 text-indigo-400 mb-1">
              <Clock size={16} />
              <span className="text-[10px] font-black uppercase tracking-[0.2em]">Tempo Real</span>
            </div>
            <p className="text-3xl font-mono font-bold text-white tracking-tighter">
              {currentTime.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </p>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">
              {dayName}, {fullDate}
            </p>
          </div>

          <div className="h-12 w-px bg-white/5 hidden md:block" />

          {/* Session Timer Widget */}
          <div className="bg-slate-950/50 p-4 rounded-3xl border border-white/5 flex items-center gap-4 min-w-[200px] shadow-inner group">
            <div className={cn(
              "w-12 h-12 rounded-2xl flex items-center justify-center transition-all",
              timerActive ? "bg-emerald-500 text-white animate-pulse" : "bg-white/5 text-slate-500"
            )}>
              <TimerIcon size={24} />
            </div>
            <div>
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-1">Cronômetro Clínico</p>
              <div className="flex items-center gap-3">
                <span className="text-xl font-mono font-bold text-white">{formatTimer(timerSeconds)}</span>
                <div className="flex gap-1">
                  <button 
                    onClick={() => setTimerActive(!timerActive)}
                    className="p-1.5 hover:bg-white/10 rounded-lg text-indigo-400 transition-all"
                  >
                    <Play size={14} fill={timerActive ? "currentColor" : "none"} className={timerActive ? "rotate-90" : ""} />
                  </button>
                  <button 
                    onClick={() => { setTimerActive(false); setTimerSeconds(0); }}
                    className="p-1.5 hover:bg-white/10 rounded-lg text-slate-500 transition-all"
                  >
                    <RotateCcw size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="absolute -right-20 -top-20 w-64 h-64 bg-indigo-500/5 blur-[100px] rounded-full group-hover:bg-indigo-500/10 transition-all duration-1000" />
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Pacientes em Acompanhamento', value: patients.length || '24', icon: Users, color: 'text-indigo-400', bg: 'bg-indigo-500/10', sub: '+2 novos no mês', trend: 'blue' },
          { label: 'Sessões Agendadas Hoje', value: '08', icon: CalendarIcon, color: 'text-emerald-400', bg: 'bg-emerald-500/10', sub: 'Próxima às 14:00', trend: 'green' },
          { label: 'Alertas IA Críticos', value: '03', icon: AlertCircle, color: 'text-amber-400', bg: 'bg-amber-500/10', sub: 'Risco emocional alto', trend: 'amber' },
          { label: 'Horas Clínicas Ativas', value: '124h', icon: Activity, color: 'text-lilac-500', bg: 'bg-indigo-500/10', sub: 'Meta: 160h/mês', trend: 'indigo' },
        ].map((stat, i) => (
          <motion.div 
            key={i} 
            whileHover={{ y: -5 }}
            className="bg-slate-900/50 backdrop-blur-3xl p-6 rounded-[2rem] border border-white/5 relative overflow-hidden group shadow-xl"
          >
            <div className={cn("p-4 rounded-2xl w-fit mb-6 transition-transform group-hover:scale-110", stat.bg, stat.color)}>
              <stat.icon size={28} />
            </div>
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">{stat.label}</p>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold text-white tracking-tighter italic-serif">{stat.value}</span>
            </div>
            <p className="text-[11px] font-medium text-slate-400 mt-4 flex items-center gap-1.5">
               <span className="w-1 h-1 rounded-full bg-indigo-500" />
               {stat.sub}
            </p>
          </motion.div>
        ))}
      </div>

      {/* Middle Section: Main Evolution & Temperament Map */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        <div className="lg:col-span-2 bg-slate-900/50 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/5 shadow-2xl space-y-8">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold text-white italic-serif">Evolução Clínica Agregada</h3>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Análise de intensidade emocional da base de pacientes</p>
            </div>
            <div className="flex gap-2">
              {['Semanal', 'Mensal'].map(t => (
                <button key={t} className="px-4 py-2 rounded-xl bg-white/5 border border-white/5 text-[10px] font-bold text-slate-400 hover:text-white transition-all uppercase tracking-widest">
                  {t}
                </button>
              ))}
            </div>
          </div>

          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={EMOTIONAL_TREND_DATA}>
                <defs>
                  <linearGradient id="colorPulse" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#ffffff05" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 'bold'}} dy={10} />
                <YAxis dataKey="valor" hide />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderRadius: '16px', border: '1px solid rgba(255,255,255,0.05)', padding: '12px' }}
                  itemStyle={{ fontSize: '10px', fontWeight: 'bold', color: '#fff' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="valor" 
                  stroke="#6366f1" 
                  strokeWidth={4} 
                  fillOpacity={1} 
                  fill="url(#colorPulse)" 
                  animationDuration={2000}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Mapa de Diversidade Psíquica */}
        <div className="bg-slate-900/50 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/5 shadow-2xl flex flex-col">
          <h3 className="text-xl font-bold text-white italic-serif">Mapa de Diversidade</h3>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1 mb-8">Os 4 Temperamentos Dominantes</p>
          
          <div className="flex-1 min-h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={TEMPERAMENT_DATA}>
                <PolarGrid stroke="#ffffff10" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 'bold' }} />
                <Radar
                  name="Base de Pacientes"
                  dataKey="A"
                  stroke="#6366f1"
                  fill="#6366f1"
                  fillOpacity={0.3}
                  animationDuration={2000}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-6">
             {TEMPERAMENT_DATA.map((t, i) => (
               <div key={i} className="p-3 bg-white/5 border border-white/5 rounded-2xl">
                 <div className="flex items-center justify-between mb-1">
                   <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{t.subject}</span>
                   <span className="text-xs font-bold text-indigo-400">{t.A}%</span>
                 </div>
                 <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${t.A}%` }}
                      className="h-full bg-indigo-500/50" 
                    />
                 </div>
               </div>
             ))}
          </div>
        </div>
      </div>

      {/* Bottom Section: Fluxo de Hoje & Insights */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Agenda / Fluxo */}
        <div className="lg:col-span-12 xl:col-span-7 bg-slate-900/50 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/5 shadow-2xl">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold text-white italic-serif">Fluxo Clínico Diário</h3>
            <div className="flex items-center gap-4">
               <div className="flex -space-x-3">
                 {[1,2,3,4].map(i => (
                   <div key={i} className="w-8 h-8 rounded-full border-2 border-slate-900 bg-indigo-600 flex items-center justify-center text-[10px] font-bold text-white">
                      {String.fromCharCode(64 + i)}
                   </div>
                 ))}
                 <div className="w-8 h-8 rounded-full border-2 border-slate-900 bg-slate-800 flex items-center justify-center text-[10px] font-bold text-slate-400">
                    +4
                 </div>
               </div>
               <button className="p-2 text-slate-500 hover:text-white transition-all"><ChevronRight size={20}/></button>
            </div>
          </div>

          <div className="space-y-3">
            {[
              { time: '14:00', patient: 'Ana Beatriz', status: 'Confirmado', type: 'Hipnoterapia IA', mood: 'good', active: true },
              { time: '15:15', patient: 'Carlos Eduardo', status: 'Aguardando', type: 'TCC - Sessão 04', mood: 'neutral', active: false },
              { time: '16:30', patient: 'Mariana Costa', status: 'Triagem', type: 'Anamnese Viva IA', mood: 'bad', active: false },
              { time: '18:00', patient: 'João Pedro', status: 'Confirmado', type: 'Terapia Familiar', mood: 'good', active: false },
            ].map((s, i) => (
              <div 
                key={i} 
                className={cn(
                  "p-5 rounded-[1.5rem] border transition-all flex items-center justify-between group cursor-pointer",
                  s.active ? "bg-indigo-500/10 border-indigo-500/30 ring-1 ring-indigo-500/10 shadow-lg shadow-indigo-500/5" : "bg-white/5 border-white/5 hover:bg-white/10"
                )}
              >
                <div className="flex items-center gap-6">
                  <div className="text-right min-w-[70px]">
                    <p className="text-lg font-mono font-bold text-white leading-none">{s.time}</p>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-1">Horário</p>
                  </div>
                  <div className="w-px h-8 bg-white/5" />
                  <div>
                    <p className="text-base font-bold text-white group-hover:text-indigo-400 transition-colors">{s.patient}</p>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-0.5">{s.type}</p>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  <div className="text-right hidden sm:block">
                    <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Nível Emocional</p>
                    <div className="flex justify-end gap-1 mt-1">
                      {s.mood === 'good' ? <Smile className="text-emerald-400" size={16}/> : s.mood === 'neutral' ? <Meh className="text-amber-400" size={16}/> : <Frown className="text-rose-400" size={16}/>}
                    </div>
                  </div>
                  <div className={cn(
                    "px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-[0.2em] shadow-sm",
                    s.status === 'Confirmado' ? "bg-emerald-500/10 text-emerald-400" : "bg-white/10 text-slate-400"
                  )}>
                    {s.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Insight Sidebar */}
        <div className="lg:col-span-12 xl:col-span-5 space-y-8">
           {/* Professional Mood Widget */}
           <div className="bg-slate-900/50 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/5 shadow-2xl">
              <h3 className="text-sm font-bold text-white uppercase tracking-widest mb-6 text-center">Como você está hoje, Dr?</h3>
              <div className="flex justify-center gap-8">
                {[
                  { id: 'bad', icon: Frown, color: 'text-rose-400', bg: 'bg-rose-500/10' },
                  { id: 'neutral', icon: Meh, color: 'text-amber-400', bg: 'bg-amber-500/10' },
                  { id: 'good', icon: Smile, color: 'text-emerald-400', bg: 'bg-emerald-500/10' }
                ].map((m) => (
                  <button 
                    key={m.id}
                    onClick={() => setProfessionalMood(m.id as any)}
                    className={cn(
                      "w-16 h-16 rounded-3xl flex items-center justify-center transition-all border group",
                      professionalMood === m.id ? cn(m.bg, "border-white/20 scale-110 shadow-lg") : "bg-white/5 border-white/5 grayscale opacity-40 hover:grayscale-0 hover:opacity-100"
                    )}
                  >
                    <m.icon size={32} className={professionalMood === m.id ? m.color : "text-white"} />
                  </button>
                ))}
              </div>
              <p className="text-center text-[10px] font-bold text-slate-600 uppercase tracking-widest mt-6">A IA recomenda uma pausa de 10 min entre sessões críticas.</p>
           </div>

           {/* Risk Radar / AI Insights */}
           <div className="bg-gradient-to-br from-indigo-900/40 to-indigo-950/40 p-8 rounded-[2.5rem] border border-white/10 shadow-2xl relative overflow-hidden">
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-indigo-400 mb-6 border border-white/10">
                <Brain size={24} />
              </div>
              <h3 className="text-2xl font-bold text-white italic-serif leading-tight mb-4">Mente Terapêutica Connect</h3>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-3 p-3 bg-white/5 rounded-2xl border border-white/5">
                  <Zap size={18} className="text-amber-400 shrink-0 mt-1" />
                  <p className="text-sm text-slate-300 italic-serif italic leading-relaxed">
                    "Detectado padrão de autossabotagem em Mariana Costa. Sugerimos abordagem via Túnel do Tempo."
                  </p>
                </div>
                <div className="flex items-start gap-3 p-3 bg-white/5 rounded-2xl border border-white/5">
                  <TrendingUp size={18} className="text-emerald-400 shrink-0 mt-1" />
                  <p className="text-sm text-slate-300 italic-serif italic leading-relaxed">
                    "Ansiedade geral da base diminuiu 12% na última semana. Ótimo progresso terapêutico!"
                  </p>
                </div>
              </div>

              <div className="p-4 bg-slate-950/50 rounded-2xl border border-white/5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Radar de Risco</span>
                  <ShieldAlert size={14} className="text-rose-500" />
                </div>
                <div className="flex flex-wrap gap-2">
                  <span className="px-2 py-1 bg-rose-500/10 text-rose-400 text-[10px] font-bold rounded-lg border border-rose-500/20">Ansiedade Severa</span>
                  <span className="px-2 py-1 bg-amber-500/10 text-amber-400 text-[10px] font-bold rounded-lg border border-amber-500/20">Inatividade</span>
                  <span className="px-2 py-1 bg-indigo-500/10 text-indigo-400 text-[10px] font-bold rounded-lg border border-indigo-500/20">Baixa Adesão</span>
                </div>
              </div>

              {/* Metas Terapêuticas Widget */}
              <div className="mt-8 pt-8 border-t border-white/5">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Metas da Semana</h4>
                  <Target size={14} className="text-indigo-400" />
                </div>
                <div className="space-y-3">
                  {[
                    { label: 'Evolução de Autoestima', progress: 85 },
                    { label: 'Altas Previstas', progress: 40 },
                  ].map((meta, i) => (
                    <div key={i} className="space-y-1.5">
                      <div className="flex justify-between text-[10px] font-bold">
                        <span className="text-slate-400">{meta.label}</span>
                        <span className="text-white">{meta.progress}%</span>
                      </div>
                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${meta.progress}%` }}
                          transition={{ duration: 1, delay: i * 0.2 }}
                          className="h-full bg-gradient-to-r from-indigo-500 to-indigo-400"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="absolute -bottom-10 -right-10 w-24 h-24 bg-indigo-500/20 blur-[50px] rounded-full" />
           </div>
        </div>
      </div>

      {/* Fixed AI Assistant Trigger */}
      <div className="fixed bottom-8 right-8 z-50">
        <motion.button 
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setShowAssistant(true)}
          className="w-16 h-16 bg-indigo-600 text-white rounded-full flex items-center justify-center shadow-2xl shadow-indigo-600/40 relative group"
        >
          <div className="absolute inset-0 bg-indigo-400 rounded-full animate-ping opacity-20 pointer-events-none group-hover:hidden" />
          <Brain size={32} />
        </motion.button>
      </div>

      {/* Mini Assistant Modal Placeholder */}
      <AnimatePresence>
        {showAssistant && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 50 }}
            className="fixed bottom-28 right-8 w-80 bg-slate-900 border border-white/10 rounded-[2rem] shadow-2xl z-50 overflow-hidden"
          >
            <div className="p-4 bg-indigo-600 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Brain size={18} className="text-white" />
                <span className="text-xs font-bold text-white uppercase tracking-widest">IA Clínica Online</span>
              </div>
              <button onClick={() => setShowAssistant(false)} className="text-white/60 hover:text-white transition-colors">
                <Meh size={18} className="rotate-45" />
              </button>
            </div>
            <div className="p-4 h-64 overflow-y-auto space-y-4 bg-slate-950/50">
              <div className="p-3 bg-white/5 rounded-2xl text-xs text-slate-300 leading-relaxed italic-serif">
                Olá, Dr. Renato! Qual insight clínico você deseja analisar agora?
              </div>
            </div>
            <div className="p-4 border-t border-white/5 bg-slate-900">
               <div className="relative">
                  <input 
                    type="text" 
                    placeholder="Perguntar à IA..." 
                    className="w-full bg-white/5 border border-white/5 rounded-xl py-2 px-3 text-xs text-white outline-none focus:border-indigo-500/50"
                  />
                  <ArrowRight size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-indigo-400 cursor-pointer" />
               </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}



