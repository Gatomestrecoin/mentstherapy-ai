import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useNavigate } from 'react-router-dom';
import { 
  ChevronRight, 
  Target, 
  Calendar, 
  CheckCircle2, 
  Circle, 
  Clock, 
  Sparkles, 
  Plus, 
  MoreHorizontal,
  LayoutList,
  Activity,
  Save,
  MessageSquare,
  FileText,
  Mic,
  TrendingUp,
  ShieldCheck,
  BrainCircuit,
  History
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Patient, TherapeuticPlan as IPlan, Session } from '../types';
import InlineRecorder from './InlineRecorder';

const defaultPlanStages = [
  { 
    number: 1, 
    title: 'Acolhimento + Vínculo', 
    description: 'Criar segurança emocional, confiança e abertura terapêutica.',
    questions: [
      'O que te trouxe para a terapia neste momento?',
      'Como você está emocionalmente hoje?',
      'O que mais tem te incomodado ultimamente?',
      'Você já fez terapia antes?',
      'Como costuma lidar com problemas emocionais?',
      'Existe algo que sente dificuldade em falar?',
      'Como você descreveria sua vida atualmente?',
      'O que espera alcançar com a terapia?',
      'Quem é sua rede de apoio?',
      'Você se sente compreendido pelas pessoas?',
      'Como costuma reagir quando sofre?',
      'Você sente que guarda muitas emoções?',
      'Tem facilidade para confiar nas pessoas?',
      'O que mais deseja mudar em si?',
      'Qual seria sua maior dor emocional hoje?'
    ],
    aiInsights: "A IA detectou sentimentos predominantes de ansiedade, solidão e insegurança afetiva. Paciente apresenta dificuldade de expressão emocional e necessidade elevada de acolhimento."
  },
  { 
    number: 2, 
    title: 'Infância Emocional', 
    description: 'Investigar formação emocional e experiências infantis.',
    questions: [
      'Como você descreveria sua infância?',
      'Você se sentia amado(a)?',
      'Como era o ambiente da sua casa?',
      'Existiam brigas frequentes?',
      'Você tinha medo de alguém?',
      'Como seus pais lidavam com emoções?',
      'Você recebia carinho?',
      'Já se sentiu rejeitado(a) na infância?',
      'Qual lembrança mais te marcou?',
      'Você podia expressar tristeza ou raiva?',
      'Como era sua relação com sua mãe?',
      'Como era sua relação com seu pai?',
      'Sentia necessidade de agradar?',
      'Houve abandono emocional?',
      'O que a criança dentro de você precisava ouvir?'
    ]
  },
  { 
    number: 3, 
    title: 'Crenças Limitantes', 
    description: 'Detectar pensamentos inconscientes que sabotam a vida.',
    questions: [
      'O que você acredita sobre si mesmo?',
      'Você se sente suficiente?',
      'Qual frase negativa mais repete mentalmente?',
      'Tem medo de fracassar?',
      'Você acredita merecer felicidade?',
      'Como vê dinheiro e sucesso?',
      'Você sente necessidade de aprovação?',
      'Costuma se comparar?',
      'O que aprendeu sobre amor?',
      'Você acredita que precisa agradar?',
      'Qual crítica mais marcou sua vida?',
      'Você se cobra excessivamente?',
      'Tem medo de rejeição?',
      'Existe culpa em ser feliz?',
      'O que te impede de avançar?'
    ]
  },
  { 
    number: 4, 
    title: 'Traumas', 
    description: 'Mapear dores emocionais profundas e gatilhos.',
    questions: [
      'Existe algum evento que marcou profundamente sua vida?',
      'Já sofreu humilhação?',
      'Já sofreu abandono?',
      'Passou por violência física ou emocional?',
      'Já viveu perdas traumáticas?',
      'Existe algo que evita lembrar?',
      'Tem gatilhos emocionais?',
      'O que mais te machuca até hoje?',
      'Você sente medo constante?',
      'Existem traumas familiares?',
      'Como seu corpo reage ao sofrimento?',
      'Tem dificuldade em confiar?',
      'Existe alguma dor que nunca contou?',
      'Você sente raiva reprimida?',
      'Qual dor ainda não conseguiu superar?'
    ]
  },
  { 
    number: 5, 
    title: 'Autoestima', 
    description: 'Fortalecer identity e valor pessoal.',
    questions: [
      'Como você se enxerga?',
      'O que gosta em si?',
      'O que mais critica em você?',
      'Você sente orgulho de quem é?',
      'Como reage a elogios?',
      'Você se sente capaz?',
      'Costuma se colocar em último lugar?',
      'Tem dificuldade em dizer “não”?',
      'Você se sente amado(a)?',
      'O que destrói sua autoestima?',
      'Qual sua maior qualidade?',
      'Você se sente bonito(a)?',
      'Se sente digno(a) de amor?',
      'Como gostaria de se sentir?',
      'O que precisa mudar para se valorizar?'
    ]
  },
  { 
    number: 6, 
    title: 'Ansiedade e Depressão', 
    description: 'Compreender sintomas emocionais e persistentes.',
    questions: [
      'Você sente pensamentos acelerados?',
      'Tem dificuldade para dormir?',
      'Sente cansaço constante?',
      'Tem crises de ansiedade?',
      'Existe falta de motivação?',
      'Você sente vazio emocional?',
      'Já perdeu interesse pela vida?',
      'Tem medo constante?',
      'O corpo manifesta sintomas físicos?',
      'Você se sente sozinho(a)?',
      'Costuma pensar excessivamente?',
      'Tem dificuldade em relaxar?',
      'Já teve sensação de desespero?',
      'O que mais piora sua ansiedade?',
      'O que traz alívio emocional?'
    ]
  },
  { 
    number: 7, 
    title: 'Ressignificação', 
    description: 'Transformar dores em novos significados emocionais.',
    questions: [
      'O que você aprendeu com sua dor?',
      'Existe algo que precisa perdoar?',
      'O que deseja deixar no passado?',
      'Como gostaria de reescrever sua história?',
      'O que ainda prende você emocionalmente?',
      'Qual ferida deseja curar?',
      'O que significa liberdade emocional?',
      'Você consegue enxergar evolução em si?',
      'O que deseja reconstruir?',
      'O que precisa aceitar?',
      'Qual nova versão de você deseja criar?',
      'Existe algo que deseja falar para seu “eu” do passado?',
      'Como deseja viver daqui para frente?',
      'O que hoje faz sentido diferente?',
      'O que deseja ressignificar em sua vida?'
    ]
  },
  { 
    number: 8, 
    title: 'Fortalecimento Emocional e Espiritual', 
    description: 'Fortalecer propósito, esperança e equilíbrio interno.',
    questions: [
      'O que dá sentido à sua vida?',
      'Você acredita em algo maior?',
      'Como cuida da sua espiritualidade?',
      'O que traz paz para você?',
      'O que deseja construir emocionalmente?',
      'Você consegue sentir gratidão?',
      'Como deseja estar emocionalmente no futuro?',
      'O que te fortalece?',
      'Quem você deseja se tornar?',
      'Existe esperança dentro de você?',
      'O que precisa abandonar?',
      'Como deseja cuidar da mente e alma?',
      'O que te conecta consigo mesmo?',
      'Qual propósito sente ter?',
      'O que significa cura para você?'
    ]
  },
];

const extraStages12 = [
  { number: 9, title: 'Relacionamentos Afetivos', description: 'Exploração da dinâmica de casal e padrões de escolha.' },
  { number: 10, title: 'Dependência Emocional', description: 'Quebra de vínculos simbióticos e busca por autonomia.' },
  { number: 11, title: 'Perdão e Aceitação', description: 'Processo de liberação de mágoas e integração do passado.' },
  { number: 12, title: 'Propósito de Vida', description: 'Definição de valores e metas alinhadas à nova identidade.' },
];

const extraStages15 = [
  { number: 13, title: 'Inteligência Emocional', description: 'Gestão fina de emoções no cotidiano e ambientes sociais.' },
  { number: 14, title: 'Projeto de Vida', description: 'Estruturação de planos práticos para o futuro pós-terapia.' },
  { number: 15, title: 'Gestão de Crises', description: 'Ferramentas de resiliência para situações de estresse elevado.' },
];

export default function TherapeuticPlan({ patients }: { patients: Patient[] }) {
  const navigate = useNavigate();
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [activePlan, setActivePlan] = useState<IPlan | null>(null);
  const [editingSession, setEditingSession] = useState<number | null>(null);
  const [mainTab, setMainTab] = useState<'plan' | 'evolution'>('plan');
  const [recordingSession, setRecordingSession] = useState<{ number: number, title: string } | null>(null);
  const [lastAnalysis, setLastAnalysis] = useState<Partial<Session> | null>(null);

  const createPlan = (patientId: string) => {
    const newPlan: IPlan = {
      id: Math.random().toString(36).substr(2, 9),
      patientId,
      title: 'Plano Terapêutico Inteligente (8 Sessões)',
      sessions: defaultPlanStages.map(stage => ({
        ...stage,
        status: 'pending',
        notes: ''
      }))
    };
    setActivePlan(newPlan);
  };

  const expandPlan = (total: number) => {
    if (!activePlan) return;
    
    let updatedSessions = [...activePlan.sessions];
    
    if (total >= 12 && updatedSessions.length < 12) {
      const remaining = extraStages12.map(s => ({ ...s, status: 'pending' as const, notes: '' }));
      updatedSessions = [...updatedSessions, ...remaining];
    }
    
    if (total >= 15 && updatedSessions.length < 15) {
      const remaining = extraStages15.map(s => ({ ...s, status: 'pending' as const, notes: '' }));
      updatedSessions = [...updatedSessions, ...remaining];
    }

    setActivePlan({
      ...activePlan,
      title: `Plano Terapêutico Inteligente (${total} Sessões)`,
      sessions: updatedSessions
    });
  };

  const toggleSession = (num: number) => {
    if (!activePlan) return;
    const newSessions = activePlan.sessions.map(s => 
      s.number === num ? { ...s, status: s.status === 'completed' ? 'pending' : 'completed' } : s
    );
    setActivePlan({ ...activePlan, sessions: newSessions });
  };

  const getProgress = () => {
    if (!activePlan) return 0;
    const completed = activePlan.sessions.filter(s => s.status === 'completed').length;
    return Math.round((completed / activePlan.sessions.length) * 100);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-6xl mx-auto space-y-6"
    >
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/50 backdrop-blur-md p-6 rounded-[2rem] border border-white/5 shadow-2xl">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight italic-serif">Arquitetura Terapêutica</h1>
          <p className="text-[10px] text-slate-400 font-medium uppercase tracking-widest mt-1">Fluxo automatizado de imersão emocional.</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 min-w-[300px]">
          <div className="flex-1">
            <label className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.2em] block mb-1.5 ml-1">Consciência em Análise</label>
            <select 
              value={selectedPatientId}
              onChange={e => {
                setSelectedPatientId(e.target.value);
                if (e.target.value) createPlan(e.target.value);
              }}
              className="w-full bg-slate-950 border border-white/5 rounded-xl px-4 py-2.5 text-xs font-medium text-slate-300 outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all appearance-none shadow-inner"
            >
              <option value="" className="bg-slate-900 text-slate-500">Selecionar Paciente...</option>
              {patients.map(p => (
                <option key={p.id} value={p.id} className="bg-slate-900">{p.name}</option>
              ))}
              <option value="demo-1" className="bg-slate-900">Ana Beatriz (Demo)</option>
            </select>
          </div>
          {activePlan && (
            <button className="flex items-center justify-center gap-2 bg-indigo-500 text-white px-6 py-2.5 rounded-xl text-[10px] font-bold hover:bg-indigo-400 transition-all self-end h-[42px] shadow-lg shadow-indigo-500/20 active:scale-95 uppercase tracking-widest">
              <Save size={14} />
              Arquivar Ciclo
            </button>
          )}
        </div>
      </div>

      {activePlan && (
        <div className="flex bg-slate-900/50 p-1 rounded-xl border border-white/5 w-fit mx-auto shadow-2xl backdrop-blur-md">
          <button 
            onClick={() => setMainTab('plan')}
            className={cn(
              "px-8 py-2 rounded-lg text-[9px] font-bold transition-all flex items-center gap-2 uppercase tracking-[0.2em]",
              mainTab === 'plan' ? "bg-indigo-500 text-white shadow-lg shadow-indigo-500/20" : "text-slate-500 hover:text-slate-300 hover:bg-white/5"
            )}
          >
            <LayoutList size={14} /> Mapa de Imersão
          </button>
          <button 
            onClick={() => setMainTab('evolution')}
            className={cn(
              "px-8 py-2 rounded-lg text-[9px] font-bold transition-all flex items-center gap-2 uppercase tracking-[0.2em]",
              mainTab === 'evolution' ? "bg-indigo-500 text-white shadow-lg shadow-indigo-500/20" : "text-slate-500 hover:text-slate-300 hover:bg-white/5"
            )}
          >
            <TrendingUp size={14} /> Pulso Evolutivo
          </button>
        </div>
      )}

      {!activePlan ? (
        <div className="bg-slate-900/40 border border-dashed border-white/5 rounded-[2rem] p-16 text-center flex flex-col items-center backdrop-blur-sm">
          <div className="w-16 h-16 bg-indigo-500/10 rounded-2xl flex items-center justify-center mb-6 border border-indigo-500/20 shadow-xl">
            <Target size={32} className="text-indigo-400" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-2 italic-serif">Projetar Novo Mapa</h3>
          <p className="text-xs text-slate-500 max-w-xs mx-auto font-medium">Capture uma consciência acima para parametrizar o fluxo de evolução assistida por inteligência profunda.</p>
        </div>
      ) : mainTab === 'plan' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Progress Overview Sidebar */}
          <div className="lg:col-span-4 space-y-5">
            <div className="bg-slate-950 rounded-[2rem] p-8 text-white relative overflow-hidden border border-white/5 shadow-2xl">
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center border border-white/10">
                    <Activity size={20} className="text-indigo-400" />
                  </div>
                  <div>
                    <p className="text-[9px] font-bold text-indigo-400 uppercase tracking-[0.2em]">Fluxo de Integração</p>
                    <p className="text-lg font-bold italic-serif">Geração de Valor</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-end justify-between font-mono">
                    <span className="text-4xl font-bold tracking-tighter">{getProgress()}%</span>
                    <span className="text-[9px] font-bold opacity-40 uppercase tracking-widest px-1">Nível Vital</span>
                  </div>
                  <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden shadow-inner">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${getProgress()}%` }}
                      className="bg-gradient-to-r from-indigo-500 to-emerald-400 h-full rounded-full shadow-[0_0_15px_rgba(99,102,241,0.3)]"
                    />
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed italic-serif pt-2">
                    "A inteligência indica progresso satisfatório na zona de confiança. Recomendado: Iniciar mapeamento de sombras."
                  </p>
                </div>
              </div>
              <div className="absolute -top-8 -right-8 p-6 opacity-5">
                <LayoutList size={200} />
              </div>
            </div>

            <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-6 space-y-4 backdrop-blur-md">
              <h3 className="text-[10px] font-bold text-white uppercase tracking-[0.2em] flex items-center gap-2 ml-1">
                <Plus size={14} className="text-indigo-400" />
                Dinamizar Ciclo
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => expandPlan(12)}
                  className="p-3 bg-slate-950 rounded-xl text-[9px] font-bold text-emerald-400 uppercase tracking-widest hover:bg-white/5 transition-all border border-white/5 hover:border-emerald-500/30 shadow-inner"
                >
                  Exp: 12 Sessões
                </button>
                <button 
                  onClick={() => expandPlan(15)}
                  className="p-3 bg-slate-950 rounded-xl text-[9px] font-bold text-emerald-400 uppercase tracking-widest hover:bg-white/5 transition-all border border-white/5 hover:border-emerald-500/30 shadow-inner"
                >
                  Exp: 15 Sessões
                </button>
              </div>
              <button className="w-full p-4 border border-white/5 rounded-xl text-[10px] font-bold text-slate-500 hover:text-slate-300 hover:bg-white/5 transition-all flex items-center justify-center gap-2 uppercase tracking-widest">
                <Clock size={14} />
                Manutenção Vitalícia
              </button>
            </div>
          </div>

          {/* Sessions List */}
          <div className="lg:col-span-8 space-y-3">
            {activePlan.sessions.map((session, i) => (
              <motion.div 
                key={session.number}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className={cn(
                  "bg-slate-900/40 rounded-[1.5rem] border transition-all overflow-hidden backdrop-blur-sm",
                  session.status === 'completed' ? "border-indigo-500/20 bg-indigo-500/5" : "border-white/5 group hover:border-white/10 hover:bg-white/[0.02]"
                )}
              >
                <div className="p-5 flex items-center gap-5">
                  <button 
                    onClick={() => toggleSession(session.number)}
                    className={cn(
                      "w-11 h-11 rounded-xl flex items-center justify-center transition-all shrink-0 border",
                      session.status === 'completed' ? "bg-indigo-500 text-white border-indigo-400/30" : "bg-slate-950 text-slate-800 border-white/5 group-hover:bg-indigo-500/10 group-hover:text-indigo-400 group-hover:border-indigo-500/20 shadow-inner"
                    )}
                  >
                    {session.status === 'completed' ? <CheckCircle2 size={24} /> : <Circle size={24} />}
                  </button>

                  <div className="flex-1 cursor-pointer" onClick={() => setEditingSession(editingSession === session.number ? null : session.number)}>
                    <div className="flex items-center gap-3 mb-1">
                      <span className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.2em]">Estágio {session.number}</span>
                      {session.status === 'completed' && (
                        <span className="px-2 py-0.5 bg-indigo-500/10 rounded-full text-[8px] font-bold text-indigo-400 uppercase tracking-widest border border-indigo-500/20 flex items-center gap-1">
                          <CheckCircle2 size={10} /> Concluído
                        </span>
                      )}
                    </div>
                    <h4 className={cn(
                      "text-lg font-bold tracking-tight italic-serif",
                      session.status === 'completed' ? "text-slate-600 line-through opacity-60" : "text-white"
                    )}>
                      {session.title}
                    </h4>
                    <p className="text-[11px] text-slate-500 font-medium leading-tight">{session.description}</p>
                  </div>

                  <button 
                    onClick={() => setEditingSession(editingSession === session.number ? null : session.number)}
                    className="w-9 h-9 flex items-center justify-center text-slate-600 hover:text-white hover:bg-white/5 rounded-lg transition-all"
                  >
                    <MoreHorizontal size={20} />
                  </button>
                </div>

                <AnimatePresence>
                  {editingSession === session.number && (
                    <motion.div 
                      initial={{ height: 0 }}
                      animate={{ height: 'auto' }}
                      exit={{ height: 0 }}
                      className="border-t border-white/5"
                    >
                      <div className="p-6 bg-slate-950/30 space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                          <div className="p-5 bg-slate-950 rounded-2xl border border-white/5 shadow-2xl space-y-3">
                             <div className="flex items-center gap-2.5 text-indigo-400">
                               <Sparkles size={16} />
                               <span className="text-[9px] font-bold uppercase tracking-widest">Heurística Clínica</span>
                             </div>
                             <p className="text-xs text-slate-400 leading-relaxed italic-serif italic">
                               {session.aiInsights || `"Nesta fase, priorize a técnica de 'Associação Livre' focada especificamente no tema: ${session.title.toLowerCase()}."`}
                             </p>
                          </div>
                          <div className="p-5 bg-slate-950 rounded-2xl border border-white/5 shadow-2xl space-y-4 h-fit">
                             <div className="flex items-center gap-2.5 text-emerald-400">
                               <MessageSquare size={16} />
                               <span className="text-[9px] font-bold uppercase tracking-widest">Disparadores de Diálogo</span>
                             </div>
                             <div className="space-y-3 overflow-y-auto max-h-[180px] pr-2 custom-scrollbar">
                               {session.questions?.map((q, idx) => (
                                 <div key={idx} className="flex items-start gap-2.5 group/q cursor-help border-b border-white/5 pb-2 last:border-0">
                                   <div className="w-1 h-1 rounded-full bg-indigo-500 mt-1.5 shrink-0 opacity-40 group-hover/q:opacity-100 transition-all" />
                                   <p className="text-[11px] text-slate-500 font-medium leading-relaxed group-hover/q:text-white transition-colors">{q}</p>
                                 </div>
                               ))}
                             </div>
                          </div>
                        </div>
                        
                        <div className="space-y-3">
                          <label className="text-[9px] font-bold text-slate-500 uppercase tracking-widest px-2">Síntese do Atendimento</label>
                          <textarea 
                            value={session.notes}
                            onChange={(e) => {
                              const newSessions = activePlan.sessions.map(s => 
                                s.number === session.number ? { ...s, notes: e.target.value } : s
                              );
                              setActivePlan({ ...activePlan, sessions: newSessions });
                            }}
                            placeholder="Mapeie os avanços e resistências detectadas..."
                            className="w-full bg-slate-950 border border-white/5 rounded-xl p-4 text-xs text-slate-300 font-medium outline-none focus:ring-2 focus:ring-indigo-500/30 resize-none min-h-[100px] shadow-inner placeholder:text-slate-700"
                          />
                        </div>
                        
                        <div className="flex justify-end gap-3 pt-2">
                          {recordingSession?.number === session.number ? (
                            <div className="w-full">
                              <InlineRecorder 
                                patientId={selectedPatientId}
                                focus={recordingSession.title}
                                sessionId={recordingSession.number}
                                onClose={() => setRecordingSession(null)}
                                onComplete={(analysis, transcript) => {
                                  setLastAnalysis(analysis);
                                  setRecordingSession(null);
                                  
                                  if (activePlan) {
                                    const newSessions = activePlan.sessions.map(s => 
                                      s.number === recordingSession.number 
                                        ? { 
                                            ...s, 
                                            status: 'completed' as const, 
                                            aiInsights: analysis.summary,
                                            notes: s.notes ? `${s.notes}\n\nTranscrição IA:\n${transcript}` : `Transcrição IA:\n${transcript}`
                                          } 
                                        : s
                                    );
                                    setActivePlan({ ...activePlan, sessions: newSessions });
                                  }
                                  
                                  setTimeout(() => setMainTab('evolution'), 500);
                                }}
                              />
                            </div>
                          ) : (
                            <>
                              <button className="flex items-center gap-2 text-[9px] font-bold text-slate-400 bg-white/5 px-4 py-2 rounded-lg border border-white/5 hover:bg-white/10 hover:text-white transition-all uppercase tracking-widest">
                                <FileText size={14} /> Relatório
                              </button>
                              <button 
                                onClick={() => setRecordingSession({ number: session.number, title: session.title })}
                                className="flex items-center gap-2 text-[9px] font-bold text-white bg-indigo-500 px-6 py-2 rounded-lg hover:bg-indigo-400 transition-all shadow-lg shadow-indigo-500/20 uppercase tracking-widest"
                              >
                                <Mic size={14} /> Varredura IA
                              </button>
                            </>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ))}
          </div>
        </div>
      ) : (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 lg:grid-cols-3 gap-6"
        >
          {/* Evolution Data */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-900/50 rounded-[2rem] p-8 border border-white/5 shadow-2xl backdrop-blur-md space-y-8">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-bold text-white italic-serif">Genômica Emocional</h3>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Decodificação de padrões profundos.</p>
                </div>
                <div className="w-12 h-12 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-400 border border-indigo-500/20 shadow-xl">
                  <TrendingUp size={24} />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="p-6 bg-slate-950 rounded-2xl border border-white/5 space-y-4 shadow-2xl">
                  <div className="flex items-center gap-2 text-indigo-400">
                    <Target size={16} />
                    <span className="text-[9px] font-bold uppercase tracking-widest text-slate-500">Expansão do Self</span>
                  </div>
                  <p className="text-sm text-slate-300 leading-relaxed italic-serif italic">
                    {lastAnalysis?.patientEvolution || "A consciência demonstra saltos quantitativos na percepção de gatilhos inconscientes."}
                  </p>
                </div>
                <div className="p-6 bg-slate-950 rounded-2xl border border-white/5 space-y-5 shadow-2xl">
                  <div className="flex items-center gap-2 text-rose-500">
                    <History size={16} />
                    <span className="text-[9px] font-bold uppercase tracking-widest text-slate-500">Mapeamento de Sombras</span>
                  </div>
                  <ul className="space-y-2.5">
                    {(lastAnalysis?.traumaMapping || ["Abandono (Ciclo 2)", "Crença: Insuficiência Vital"]).map((item, idx) => (
                      <li key={idx} className="text-[10px] text-slate-400 font-bold uppercase tracking-wider flex items-center gap-2.5 bg-white/5 p-2.5 rounded-lg border border-white/5">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(244,63,94,0.6)]" /> {item}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-[9px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2.5 px-1">
                  <ShieldCheck size={16} className="text-emerald-400" /> Prescrições de Arquitetura
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {(lastAnalysis?.therapeuticInterventions || [
                    "Vazio Central",
                    "Fluxo Cognitivo",
                    "Âncora de Segurança"
                  ]).map((int, idx) => (
                    <div key={idx} className="p-4 bg-white/5 border border-white/5 rounded-xl text-[10px] font-bold text-slate-300 leading-relaxed hover:bg-white/10 transition-all cursor-default text-center">
                      {int}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-indigo-900/80 to-indigo-950/80 rounded-[2rem] p-8 text-white relative overflow-hidden border border-white/10 shadow-2xl backdrop-blur-md">
               <div className="relative z-10 space-y-4">
                 <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-white/10 rounded-xl flex items-center justify-center text-indigo-400 border border-white/10 shadow-xl">
                      <Sparkles size={20} />
                   </div>
                   <h3 className="text-xl font-bold italic-serif">Trajetória Sugerida</h3>
                 </div>
                 <p className="text-base text-indigo-100/80 leading-relaxed italic-serif italic">
                   "Antecipar módulo de Reconstrução de Autoestima para quebrar o ciclo de estagnação detectado."
                 </p>
                 <button className="bg-white text-indigo-950 px-8 py-3 rounded-xl text-[10px] font-bold hover:bg-indigo-50 transition-all uppercase tracking-[0.2em] shadow-xl shadow-indigo-950/40 active:scale-95">
                   Relatório Profundo
                 </button>
               </div>
               <div className="absolute -bottom-8 -right-8 p-6 opacity-10 rotate-12">
                 <BrainCircuit size={150} />
               </div>
            </div>
          </div>

          {/* Emotional Map Sidebar */}
          <div className="space-y-6">
            <div className="bg-slate-900/50 rounded-[2rem] p-8 border border-white/5 shadow-2xl backdrop-blur-md space-y-8">
              <h3 className="font-bold text-white flex items-center gap-2.5 text-[10px] uppercase tracking-widest px-1">
                <Activity size={16} className="text-emerald-400" /> Bio-Ritmo Emocional
              </h3>
              
              <div className="space-y-6">
                {[
                  { label: 'Sobrecarga', val: 85, color: 'bg-rose-500' },
                  { label: 'Resistência', val: 60, color: 'bg-amber-500' },
                  { label: 'Sintonia', val: 92, color: 'bg-emerald-500' },
                ].map((stat, i) => (
                  <div key={i} className="space-y-2">
                    <div className="flex justify-between text-[8px] font-bold uppercase text-slate-500 tracking-widest">
                      <span>{stat.label}</span>
                      <span className="text-white bg-white/5 px-1.5 py-0.5 rounded-full">{stat.val}%</span>
                    </div>
                    <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden shadow-inner">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${stat.val}%` }}
                        className={cn("h-full rounded-full", stat.color)} 
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-8 border-t border-white/5">
                <h4 className="text-[9px] font-bold text-slate-500 uppercase tracking-widest mb-4 px-1">Gráficos de Consciência</h4>
                <div className="flex flex-wrap gap-2">
                  {["Trauma", "Sombra", "Ego", "Self"].map(tag => (
                    <span key={tag} className="text-[8px] font-bold bg-white/5 text-slate-400 border border-white/5 px-3 py-1.5 rounded-lg hover:text-white hover:bg-indigo-500/20 transition-all cursor-default">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
