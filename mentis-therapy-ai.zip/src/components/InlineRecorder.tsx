import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, 
  MicOff, 
  Play, 
  Square, 
  BrainCircuit, 
  Sparkles,
  Activity,
  CheckCircle2,
  AlertCircle,
  X
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Session } from '../types';

interface InlineRecorderProps {
  patientId: string;
  focus: string;
  sessionId: number;
  onComplete: (analysis: any, transcript: string) => void;
  onClose: () => void;
}

export default function InlineRecorder({ 
  patientId, 
  focus, 
  onComplete,
  onClose 
}: InlineRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [transcript, setTranscript] = useState(`Foco da Sessão: ${focus}\n\n`);
  const [seconds, setSeconds] = useState(0);
  const timerRef = useRef<number | null>(null);

  const startRecording = () => {
    setIsRecording(true);
    setTranscript(prev => prev + "O paciente começa a falar sobre sentimentos de insegurança. 'Sinto que todos estão me julgando', relata com voz trêmula. Menciona um evento recente no trabalho...");
    timerRef.current = window.setInterval(() => {
      setSeconds(s => s + 1);
    }, 1000);
  };

  const stopRecording = async () => {
    setIsRecording(false);
    if (timerRef.current) clearInterval(timerRef.current);
    
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/gemini/analyze-session', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript,
          patientContext: ''
        })
      });
      const data = await res.json();
      onComplete(data, transcript);
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-slate-50 rounded-2xl p-4 border border-indigo-100 shadow-sm space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-indigo-600">
          <Mic className={cn(isRecording && "animate-pulse")} size={16} />
          <span className="text-xs font-bold uppercase tracking-wider">Gravador IA</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm font-mono font-bold text-slate-700">{formatTime(seconds)}</span>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded-full text-slate-400">
            <X size={16} />
          </button>
        </div>
      </div>

      <div className="relative">
        <div className="min-h-[80px] bg-white rounded-xl p-3 border border-slate-100 text-[11px] text-slate-600 italic-serif leading-relaxed">
          {transcript}
          {isRecording && <span className="inline-block w-1 h-3 bg-indigo-500 ml-1 animate-pulse"></span>}
          {isAnalyzing && (
            <div className="absolute inset-0 bg-white/60 backdrop-blur-[1px] flex items-center justify-center gap-2">
              <div className="animate-spin text-indigo-600">◌</div>
              <span className="font-bold text-slate-600">Analisando...</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex items-center gap-3">
        {!isRecording ? (
          <button 
            onClick={startRecording}
            className="flex-1 bg-indigo-600 text-white py-2 rounded-xl font-bold text-xs hover:bg-indigo-700 transition-all flex items-center justify-center gap-2"
          >
            <Play size={14} fill="currentColor" /> Gravação
          </button>
        ) : (
          <button 
            onClick={stopRecording}
            className="flex-1 bg-red-600 text-white py-2 rounded-xl font-bold text-xs hover:bg-red-700 transition-all flex items-center justify-center gap-2"
          >
            <Square size={14} fill="currentColor" /> Parar & Analisar
          </button>
        )}
      </div>

      {isRecording && (
        <motion.div 
          initial={{ opacity: 0, y: 5 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-2.5 bg-emerald-50 rounded-xl border border-emerald-100 flex items-start gap-2"
        >
          <Sparkles className="text-emerald-500 shrink-0" size={14} />
          <p className="text-[10px] text-emerald-800 font-medium leading-tight">
            IA detectou ansiedade. Sugestão: Explore a sensação física de aperto no peito.
          </p>
        </motion.div>
      )}
    </div>
  );
}
