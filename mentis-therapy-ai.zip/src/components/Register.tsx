import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, 
  Mail, 
  Lock, 
  Phone,
  ArrowRight, 
  ChevronRight, 
  ChevronLeft,
  Briefcase,
  IdCard,
  MapPin,
  Check,
  ShieldCheck,
  Stethoscope,
  Upload
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import AuthLayout from './AuthLayout';
import { cn } from '../lib/utils';

export default function Register() {
  const [step, setStep] = useState(1);
  const { register, isLoading } = useAuth();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    profession: '',
    crp: '',
    specialty: '',
    city: '',
    state: '',
    lgpd: false
  });

  const professions = [
    'Psicanalista',
    'Psicólogo',
    'Terapeuta Holístico',
    'Hipnoterapeuta',
    'Psicoterapeuta',
    'Clínico Geral',
    'Estudante / Acadêmico'
  ];

  const handleNext = () => setStep(prev => prev + 1);
  const handleBack = () => setStep(prev => prev - 1);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.lgpd) return;
    await register(formData);
  };

  return (
    <AuthLayout 
      title="Faça parte da revolução terapêutica."
      subtitle="Cadastre-se para ter acesso a ferramentas exclusivas de análise profunda, hipnoterapia assistida por IA e gestão clínica avançada."
    >
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-white italic-serif">Cadastro Profissional</h2>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Passo {step} de 3</p>
          </div>
          <div className="flex gap-1">
            {[1, 2, 3].map(i => (
              <div key={i} className={cn(
                "w-8 h-1 rounded-full transition-all duration-300",
                step >= i ? "bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.5)]" : "bg-white/5"
              )} />
            ))}
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <AnimatePresence mode="wait">
            {step === 1 && (
              <motion.div 
                key="step1"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Nome Completo</label>
                  <div className="relative group">
                    <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-400" size={18} />
                    <input 
                      type="text"
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      placeholder="Dr(a). Nome Sobrenome"
                      className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">E-mail Profissional</label>
                    <div className="relative group">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-400" size={18} />
                      <input 
                        type="email"
                        value={formData.email}
                        onChange={e => setFormData({...formData, email: e.target.value})}
                        placeholder="seu@contato.com"
                        className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Telefone</label>
                    <div className="relative group">
                      <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-400" size={18} />
                      <input 
                        type="tel"
                        value={formData.phone}
                        onChange={e => setFormData({...formData, phone: e.target.value})}
                        placeholder="(00) 00000-0000"
                        className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Senha</label>
                    <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-400" size={18} />
                      <input 
                        type="password"
                        value={formData.password}
                        onChange={e => setFormData({...formData, password: e.target.value})}
                        placeholder="••••••••"
                        className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Confirmar Senha</label>
                    <div className="relative group">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-400" size={18} />
                      <input 
                        type="password"
                        value={formData.confirmPassword}
                        onChange={e => setFormData({...formData, confirmPassword: e.target.value})}
                        placeholder="••••••••"
                        className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all"
                      />
                    </div>
                  </div>
                </div>

                <button 
                  type="button"
                  onClick={handleNext}
                  className="w-full bg-indigo-500 text-white rounded-2xl py-4 font-bold text-sm flex items-center justify-center gap-2 hover:bg-indigo-600 transition-all mt-4"
                >
                  Próxima Etapa
                  <ChevronRight size={18} />
                </button>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div 
                key="step2"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Sua Profissão</label>
                  <div className="grid grid-cols-1 gap-2 max-h-[220px] overflow-y-auto pr-2 custom-scrollbar">
                    {professions.map(prof => (
                      <button
                        key={prof}
                        type="button"
                        onClick={() => setFormData({...formData, profession: prof})}
                        className={cn(
                          "flex items-center justify-between p-3 rounded-xl border transition-all text-xs font-bold uppercase tracking-widest",
                          formData.profession === prof 
                            ? "bg-indigo-500/10 border-indigo-500 text-indigo-400" 
                            : "bg-white/5 border-white/5 text-slate-500 hover:bg-white/10"
                        )}
                      >
                        {prof}
                        {formData.profession === prof && <Check size={14} />}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">CRP / Registro</label>
                    <div className="relative">
                      <IdCard className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={16} />
                      <input 
                        type="text"
                        value={formData.crp}
                        onChange={e => setFormData({...formData, crp: e.target.value})}
                        placeholder="00/00000"
                        className="w-full bg-white/5 border border-white/5 rounded-2xl py-3 pl-11 pr-4 text-xs text-white focus:bg-white/10 outline-none transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Especialidade</label>
                    <div className="relative">
                      <Stethoscope className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={16} />
                      <input 
                        type="text"
                        value={formData.specialty}
                        onChange={e => setFormData({...formData, specialty: e.target.value})}
                        placeholder="Ex: TCC"
                        className="w-full bg-white/5 border border-white/5 rounded-2xl py-3 pl-11 pr-4 text-xs text-white focus:bg-white/10 outline-none transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4 mt-6">
                  <button 
                    type="button"
                    onClick={handleBack}
                    className="flex-1 bg-white/5 text-slate-400 rounded-2xl py-4 font-bold text-sm flex items-center justify-center gap-2 hover:bg-white/10 transition-all"
                  >
                    <ChevronLeft size={18} />
                    Voltar
                  </button>
                  <button 
                    type="button"
                    onClick={handleNext}
                    className="flex-[2] bg-indigo-500 text-white rounded-2xl py-4 font-bold text-sm flex items-center justify-center gap-2 hover:bg-indigo-600 transition-all"
                  >
                    Mais Um Passo
                    <ChevronRight size={18} />
                  </button>
                </div>
              </motion.div>
            )}

            {step === 3 && (
              <motion.div 
                key="step3"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Cidade</label>
                    <input 
                      type="text"
                      value={formData.city}
                      onChange={e => setFormData({...formData, city: e.target.value})}
                      placeholder="Sua Cidade"
                      className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-4 text-sm text-white focus:bg-white/10 outline-none transition-all"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Estado</label>
                    <input 
                      type="text"
                      value={formData.state}
                      onChange={e => setFormData({...formData, state: e.target.value})}
                      placeholder="UF"
                      maxLength={2}
                      className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-4 text-sm text-white focus:bg-white/10 outline-none transition-all text-center uppercase"
                    />
                  </div>
                </div>

                <div className="p-4 bg-indigo-500/5 rounded-2xl border border-indigo-500/10 space-y-4">
                  <div className="flex items-start gap-3">
                    <input 
                      type="checkbox"
                      id="lgpd"
                      checked={formData.lgpd}
                      onChange={e => setFormData({...formData, lgpd: e.target.checked})}
                      className="mt-1 w-4 h-4 rounded bg-white/10 border-white/10 text-indigo-500 focus:ring-indigo-500/50 transition-all cursor-pointer"
                    />
                    <label htmlFor="lgpd" className="text-xs text-slate-400 leading-relaxed cursor-pointer">
                      Estou ciente e aceito os <span className="text-indigo-400 underline">Termos de Uso</span> e a <span className="text-indigo-400 underline">Política de Privacidade</span> em conformidade com a LGPD para segurança de dados clínicos.
                    </label>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button 
                    type="button"
                    onClick={handleBack}
                    className="flex-1 bg-white/5 text-slate-400 rounded-2xl py-4 font-bold text-sm flex items-center justify-center gap-2 hover:bg-white/10 transition-all"
                  >
                    <ChevronLeft size={18} />
                  </button>
                  <button 
                    type="submit"
                    disabled={isLoading || !formData.lgpd}
                    className="flex-[4] bg-indigo-500 text-white rounded-2xl py-4 font-bold text-sm flex items-center justify-center gap-2 hover:bg-indigo-600 transition-all shadow-xl shadow-indigo-500/20 disabled:opacity-50"
                  >
                    {isLoading ? (
                       <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        Finalizar Registro Profissional
                        <ShieldCheck size={18} />
                      </>
                    )}
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </form>

        <p className="text-center text-sm text-slate-500 font-medium">
          Já possui conta? {' '}
          <Link to="/login" className="text-indigo-400 font-bold hover:text-indigo-300 transition-colors">Fazer Login</Link>
        </p>
      </div>
    </AuthLayout>
  );
}
