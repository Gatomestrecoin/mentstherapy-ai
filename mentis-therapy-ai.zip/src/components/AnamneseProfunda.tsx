import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Baby, 
  Users, 
  HeartCrack,
  UserMinus, 
  ShieldAlert, 
  UserCircle, 
  Zap, 
  Heart, 
  Flame, 
  Activity, 
  Moon, 
  AlertTriangle, 
  BrainCircuit,
  Brain,
  Target,
  MessageSquare,
  Mic,
  ChevronRight,
  ChevronDown,
  Search,
  CheckCircle2,
  Sparkles,
  Save,
  LineChart,
  History
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Patient } from '../types';

const essentialCategories = [
  {
    id: 'acolhimento',
    icon: Sparkles,
    title: '📍 Bloco 1 — Acolhimento',
    subtitle: 'Vínculo e Presença',
    questions: [
      { q: 'O que trouxe você até aqui hoje?', placeholder: 'Escuta aberta e empática...' },
      { q: 'Como você está emocionalmente neste momento?', placeholder: 'A fotografia do agora...' },
      { q: 'O que você mais espera da nossa jornada juntos?', placeholder: 'Alinhamento de expectativas...' }
    ]
  },
  {
    id: 'historico-essencial',
    icon: History,
    title: '📍 Bloco 2 — Histórico Vital',
    subtitle: 'Segurança e Próximos Passos',
    questions: [
      { q: 'Já realizou terapia ou acompanhamento psiquiátrico antes?', placeholder: 'Experiências e diagnósticos prévios...' },
      { q: 'Faz uso de alguma medicação atualmente?', placeholder: 'Substâncias e dosagens...' },
      { q: 'Existe algum tema urgente ou risco que precisamos priorizar?', placeholder: 'Foco imediato e segurança...' }
    ]
  },
  {
    id: 'perfil-ia',
    icon: BrainCircuit,
    title: '🤖 Perfil Emocional IA',
    subtitle: 'Síntese das Primeiras Conexões',
    questions: null
  }
];

const continuousModules = [
  { id: 'infancia', title: '👶 Infância', icon: Baby, description: 'As raízes e os primeiros vínculos familiares.' },
  { id: 'relacionamentos', title: '💑 Afetividade', icon: Heart, description: 'Padrões de conexão e vida amorosa.' },
  { id: 'sexualidade', title: '🔥 Sexualidade', icon: Flame, description: 'Desejo, identidade e expressão íntima.' },
  { id: 'sonhos', title: '🌙 Onírico', icon: Moon, description: 'O inconsciente revelado através dos sonhos.' },
  { id: 'culpa-vergonha', title: '⚖️ Culpa/Vergonha', icon: AlertTriangle, description: 'Pesos e julgamentos internos.' },
  { id: 'autoestima', title: '✨ Autoestima', icon: Brain, description: 'A percepção do valor do próprio ser.' },
  { id: 'compulsoes', title: '🔄 Compulsões', icon: Activity, description: 'Mecanismos de escape e vícios.' },
  { id: 'ansiedade-medo', title: '🌪️ Ansiedade', icon: ShieldAlert, description: 'Mapeamento de medos e inseguranças.' },
];

export default function AnamneseProfunda({ patients }: { patients: Patient[] }) {
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [activeCategory, setActiveCategory] = useState(essentialCategories[0].id);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [showContinuous, setShowContinuous] = useState(false);

  const handleAnswerChange = (question: string, value: string) => {
    setAnswers(prev => ({ ...prev, [question]: value }));
  };

  const currentCategory = [...essentialCategories, ...continuousModules].find(c => c.id === activeCategory) || essentialCategories[0];

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-7xl mx-auto space-y-6 pb-20 p-4 md:p-8"
    >
      {/* Header Premium */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8 bg-slate-900/40 p-10 rounded-[3rem] border border-white/5 shadow-2xl backdrop-blur-3xl relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/5 to-transparent opacity-50" />
        <div className="relative z-10 space-y-2">
          <div className="flex items-center gap-3 mb-2">
            <span className="px-3 py-1 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-[10px] font-black text-indigo-400 uppercase tracking-widest">IA Co-Pilot</span>
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          </div>
          <h1 className="text-4xl font-bold text-white tracking-tighter italic-serif">Anamnese Viva IA</h1>
          <p className="text-slate-400 text-sm max-w-md leading-relaxed">
            Uma investigação fluida e inteligente que evolui conforme o paciente se revela nas sessões.
          </p>
        </div>
        
        <div className="relative z-10 flex flex-col sm:flex-row gap-4 min-w-[320px]">
          <div className="flex-1">
            <label className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.3em] block mb-3 ml-1">Paciente em Jornada</label>
            <div className="relative group">
              <select 
                value={selectedPatientId}
                onChange={e => setSelectedPatientId(e.target.value)}
                className="w-full bg-slate-950/80 border border-white/10 rounded-2xl px-6 py-4 text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-500/50 text-slate-200 shadow-2xl transition-all appearance-none italic-serif"
              >
                <option value="">Selecione a Essência...</option>
                {patients.map(p => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-500" />
            </div>
          </div>
          <button className="group flex items-center justify-center gap-3 bg-indigo-600 text-white px-10 py-4 rounded-2xl font-bold hover:bg-indigo-500 transition-all self-end h-[56px] shadow-2xl shadow-indigo-600/30 active:scale-95 uppercase tracking-widest text-[10px]">
             <Save size={18} className="transition-transform group-hover:scale-110" />
             Sincronizar IA
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Navigation Sidebar */}
        <div className="lg:col-span-3 space-y-8">
          <div className="bg-slate-900/40 rounded-[2.5rem] border border-white/5 overflow-hidden shadow-2xl backdrop-blur-md">
            <div className="p-6 bg-slate-950/50 border-b border-white/5 flex items-center justify-between">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Anamnese Essencial</span>
              <Sparkles size={14} className="text-indigo-400" />
            </div>
            <div className="p-3 space-y-2">
              {essentialCategories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => {
                    setActiveCategory(cat.id);
                    setShowContinuous(false);
                  }}
                  className={cn(
                    "w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-left transition-all duration-500 group relative",
                    (activeCategory === cat.id && !showContinuous)
                      ? "bg-indigo-600 text-white shadow-2xl shadow-indigo-600/30" 
                      : "text-slate-500 hover:bg-white/5 hover:text-slate-300"
                  )}
                >
                  <cat.icon size={18} className={cn((activeCategory === cat.id && !showContinuous) ? "text-white" : "text-slate-500 group-hover:text-indigo-400")} />
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black uppercase tracking-widest">{cat.title.includes('—') ? cat.title.split('—')[1].trim() : cat.title}</span>
                    <span className="text-[8px] font-bold opacity-50 uppercase tracking-tighter">{cat.subtitle}</span>
                  </div>
                  {(activeCategory === cat.id && !showContinuous) && <ChevronRight size={14} className="ml-auto" />}
                </button>
              ))}
            </div>

            <div className="p-6 bg-slate-950/50 border-y border-white/5 flex items-center justify-between">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Mapa Contínuo IA</span>
              <BrainCircuit size={14} className="text-emerald-400 animate-pulse" />
            </div>
            <div className="p-3 space-y-2">
              <div className="grid grid-cols-2 gap-2">
                {continuousModules.map((mod) => (
                  <button
                    key={mod.id}
                    onClick={() => {
                      setActiveCategory(mod.id);
                      setShowContinuous(true);
                    }}
                    className={cn(
                      "flex flex-col items-center justify-center p-4 rounded-2xl border transition-all duration-500 text-center gap-2",
                      (activeCategory === mod.id && showContinuous)
                        ? "bg-emerald-600 border-emerald-400 text-white shadow-xl shadow-emerald-500/20"
                        : "bg-white/5 border-white/5 text-slate-500 hover:border-emerald-500/30 group"
                    )}
                  >
                    <mod.icon size={16} className={cn((activeCategory === mod.id && showContinuous) ? "text-white" : "text-slate-500 group-hover:text-emerald-400")} />
                    <span className="text-[8px] font-black uppercase tracking-widest leading-tight">{mod.title.split(' ')[1]}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-indigo-900/40 to-indigo-950/40 rounded-[2.5rem] p-8 text-white shadow-2xl border border-white/5 relative overflow-hidden group">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,_rgba(99,102,241,0.1),transparent)] group-hover:opacity-100 opacity-50 transition-opacity" />
            <div className="relative z-10 flex flex-col items-center text-center">
              <Brain className="mb-4 text-emerald-400 animate-pulse" size={40} />
              <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-indigo-300 mb-3">Escuta Preditiva</h4>
              <p className="text-xs font-semibold leading-relaxed italic-serif opacity-80 text-slate-300">
                "O mapa emocional sugere foco em {(selectedPatientId === 'demo-1' ? 'Vínculos Maternos' : 'Temas de Infância')} para destravar a jornada atual."
              </p>
            </div>
          </div>
        </div>

        {/* Assessment Area */}
        <div className="lg:col-span-9">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -30 }}
              className="bg-slate-900/40 rounded-[3rem] border border-white/5 overflow-hidden shadow-2xl flex flex-col min-h-[700px] backdrop-blur-3xl relative"
            >
              {/* Decorative Glow */}
              <div className="absolute -top-40 -right-40 w-96 h-96 bg-indigo-600/10 blur-[150px] rounded-full pointer-events-none" />
              <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-emerald-600/10 blur-[150px] rounded-full pointer-events-none" />

              <div className="p-10 border-b border-white/5 flex items-center justify-between bg-slate-950/40 relative z-10">
                <div className="flex items-center gap-6">
                  <div className={cn(
                    "p-5 rounded-3xl text-white shadow-2xl transition-all scale-110",
                    showContinuous ? "bg-emerald-600 shadow-emerald-500/30" : "bg-indigo-600 shadow-indigo-500/30"
                  )}>
                    <currentCategory.icon size={32} />
                  </div>
                  <div>
                    <h2 className="text-3xl font-bold text-white italic-serif tracking-tighter">{(currentCategory as any).title}</h2>
                    <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mt-1 italic-serif">{(currentCategory as any).subtitle || 'Mergulho Profundo'}</p>
                  </div>
                </div>
                {!showContinuous && (
                  <div className="hidden sm:flex items-center gap-3 text-indigo-400 bg-indigo-500/10 px-6 py-3 rounded-2xl border border-indigo-500/20 shadow-2xl">
                    <Sparkles size={18} className="animate-pulse" />
                    <span className="text-[10px] font-black uppercase tracking-[0.2em]">Prioridade Terapêutica</span>
                  </div>
                )}
              </div>

              <div className="p-10 space-y-12 relative z-10 flex-1">
                {activeCategory === 'perfil-ia' ? (
                  <div className="space-y-10">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <section className="bg-indigo-500/5 p-8 rounded-[2.5rem] border border-indigo-500/10 space-y-4">
                          <h4 className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em] flex items-center gap-2">
                             <Sparkles size={14} /> Síntese Terapêutica IA
                          </h4>
                          <p className="text-xl font-bold text-slate-100 italic-serif leading-relaxed">
                            "A partir dos relatos iniciais, a IA detecta uma base de resiliência alta, porém com bloqueios profundos em temas de vulnerabilidade familiar. O foco imediato deve ser o acolhimento da queixa principal."
                          </p>
                       </section>
                       
                       <section className="bg-emerald-500/5 p-8 rounded-[2.5rem] border border-emerald-500/10 space-y-6">
                          <h4 className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.3em] flex items-center gap-2">
                             <LineChart size={14} /> Vetores Emocionais
                          </h4>
                          <div className="space-y-4">
                             {[
                               { label: 'Abertura ao Vínculo', value: 85, color: 'bg-emerald-500' },
                               { label: 'Nível de Ansiedade', value: 45, color: 'bg-indigo-500' },
                               { label: 'Energia Vital', value: 60, color: 'bg-amber-500' },
                               { label: 'Rigidez Cognitiva', value: 30, color: 'bg-rose-500' },
                             ].map((v, i) => (
                               <div key={i} className="space-y-1.5">
                                 <div className="flex justify-between items-center text-[9px] font-black text-slate-500 uppercase tracking-widest">
                                    <span>{v.label}</span>
                                    <span className="text-white">{v.value}%</span>
                                 </div>
                                 <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden shadow-inner">
                                    <motion.div 
                                      initial={{ width: 0 }}
                                      animate={{ width: `${v.value}%` }}
                                      transition={{ delay: 0.2 + i * 0.1, duration: 1 }}
                                      className={cn("h-full", v.color)}
                                    />
                                 </div>
                               </div>
                             ))}
                          </div>
                       </section>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                       <section className="bg-white/5 p-6 rounded-3xl border border-white/5 space-y-4">
                          <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                             <ShieldAlert size={12} /> Áreas Prioritárias
                          </h4>
                          <div className="flex flex-wrap gap-2">
                             {['Vínculo Materno', 'Autoestima', 'Sono'].map(t => (
                               <span key={t} className="px-3 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-[10px] font-bold text-indigo-300">
                                 {t}
                               </span>
                             ))}
                          </div>
                       </section>

                       <section className="bg-white/5 p-6 rounded-3xl border border-white/5 space-y-4">
                          <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                             <Brain size={12} /> Padrões Detectados
                          </h4>
                          <ul className="space-y-2">
                             <li className="text-[10px] text-slate-400 italic flex items-center gap-2">
                                <div className="w-1 h-1 rounded-full bg-indigo-500" /> Esquiva de conflito direto
                             </li>
                             <li className="text-[10px] text-slate-400 italic flex items-center gap-2">
                                <div className="w-1 h-1 rounded-full bg-indigo-500" /> Necessidade de validação
                             </li>
                          </ul>
                       </section>

                       <section className="bg-white/5 p-6 rounded-3xl border border-white/5 space-y-4">
                          <h4 className="text-[9px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                             <MessageSquare size={12} /> Sugestão de Pergunta
                          </h4>
                          <div className="p-4 bg-indigo-500/5 rounded-2xl border border-indigo-500/10">
                             <p className="text-[11px] font-medium text-indigo-300 italic">"Como você sente que essa necessidade de agradar impacta suas decisões hoje?"</p>
                          </div>
                       </section>
                    </div>
                  </div>
                ) : (currentCategory as any).questions ? (currentCategory as any).questions.map((qObj: any, i: number) => {
                  const qText = typeof qObj === 'string' ? qObj : qObj.q;
                  const qPH = typeof qObj === 'object' ? qObj.placeholder : 'Decodifique o inconsciente...';
                  
                  return (
                    <div key={i} className="group flex flex-col md:flex-row gap-8">
                      <div className="w-12 h-12 rounded-2xl bg-slate-950 flex items-center justify-center text-sm font-black text-slate-500 shrink-0 mt-2 border border-white/10 shadow-2xl group-hover:border-indigo-500/50 transition-all">
                        {i + 1}
                      </div>
                      <div className="flex-1 space-y-6">
                        <div className="flex items-center justify-between">
                          <p className="text-xl font-bold text-slate-100 leading-snug italic-serif group-hover:text-indigo-400 transition-colors">{qText}</p>
                          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                             <button className="p-2.5 text-slate-500 hover:text-indigo-400 transition-all" title="IA Sugere Pergunta">
                               <Sparkles size={16} />
                             </button>
                             <button className="p-2.5 text-slate-500 hover:text-emerald-400 transition-all" title="Análise IA">
                               <Brain size={16} />
                             </button>
                          </div>
                        </div>
                        
                        <div className="relative group/field">
                          <textarea 
                            value={answers[qText] || ''}
                            onChange={(e) => handleAnswerChange(qText, e.target.value)}
                            placeholder={qPH}
                            className="w-full bg-slate-950/60 border border-white/5 rounded-3xl px-8 py-6 outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all text-slate-200 resize-none min-h-[140px] italic-serif text-lg leading-relaxed shadow-2xl placeholder:text-slate-800 focus:bg-slate-950"
                          />
                          <div className="absolute bottom-6 right-6 flex gap-3">
                             <button className="flex items-center gap-2 px-4 py-2 bg-white/5 text-slate-500 hover:text-indigo-400 rounded-xl border border-white/10 shadow-xl transition-all hover:scale-105 active:scale-95 group/btn">
                               <Mic size={18} />
                               <span className="text-[10px] font-black uppercase tracking-widest hidden lg:block">Voz</span>
                             </button>
                             <button className="flex items-center gap-2 px-4 py-2 bg-white/5 text-slate-500 hover:text-emerald-400 rounded-xl border border-white/10 shadow-xl transition-all hover:scale-105 active:scale-95">
                               <CheckCircle2 size={18} />
                               <span className="text-[10px] font-black uppercase tracking-widest hidden lg:block">Pronto</span>
                             </button>
                          </div>
                        </div>

                        {/* IA Dynamic Insight */}
                        <AnimatePresence>
                          {answers[qText]?.length > 30 && (
                            <motion.div 
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="p-6 bg-indigo-500/5 border border-indigo-500/10 rounded-2xl flex items-start gap-4"
                            >
                              <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
                                <Sparkles size={16} />
                              </div>
                              <div className="space-y-1">
                                <p className="text-[10px] font-black text-indigo-300 uppercase tracking-[0.2em]">IA Insight Dinâmico</p>
                                <p className="text-xs text-slate-400 italic leading-relaxed">
                                  "Este relato possui correlação com sentimentos de {(i % 2 === 0 ? 'Abandono Paterno' : 'Insegurança Profissional')}. Recomendo aprofundar na próxima sessão."
                                </p>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    </div>
                  );
                }) : (
                  <div className="flex flex-col items-center justify-center h-[400px] text-center space-y-6">
                    <div className="w-24 h-24 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400 border border-emerald-500/20 animate-pulse">
                      <currentCategory.icon size={48} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white italic-serif">Módulo Livre: {(currentCategory as any).title}</h3>
                      <p className="text-slate-500 max-w-sm mx-auto mt-2">
                        Inicie esta investigação quando sentir que o paciente está pronto para este mergulho emocional.
                      </p>
                    </div>
                    <button className="px-10 py-4 bg-emerald-600 text-white rounded-2xl font-bold hover:bg-emerald-500 transition-all shadow-2xl shadow-emerald-600/20 active:scale-95 uppercase tracking-widest text-[10px]">
                      Ativar Módulo de Investigação
                    </button>
                  </div>
                )}
              </div>

              <div className="p-10 bg-slate-950/60 border-t border-white/5 mt-auto flex items-center justify-between relative z-10 backdrop-blur-md">
                <div className="flex items-center gap-4 text-slate-500">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-[10px] font-black uppercase tracking-[0.3em]">IA Sincronizada em Tempo Real</span>
                </div>
                <div className="flex gap-4">
                   <button className="px-8 py-4 rounded-2xl font-black text-slate-500 hover:text-white hover:bg-white/5 transition-all uppercase tracking-widest text-[10px]">Descartar</button>
                   <button 
                    onClick={() => {
                      if (showContinuous) {
                        const nextIndex = continuousModules.findIndex(c => c.id === activeCategory) + 1;
                        if (nextIndex < continuousModules.length) {
                          setActiveCategory(continuousModules[nextIndex].id);
                        }
                      } else {
                        const nextIndex = essentialCategories.findIndex(c => c.id === activeCategory) + 1;
                        if (nextIndex < essentialCategories.length) {
                          setActiveCategory(essentialCategories[nextIndex].id);
                        } else {
                          setShowContinuous(true);
                          setActiveCategory(continuousModules[0].id);
                        }
                      }
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="flex items-center gap-3 px-12 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-500 transition-all shadow-2xl shadow-indigo-600/30 uppercase tracking-[0.2em] text-[10px] active:scale-95 group"
                   >
                     Aprofundar <ChevronRight size={20} className="transition-transform group-hover:translate-x-1" />
                   </button>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}
