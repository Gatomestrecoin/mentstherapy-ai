import React, { useState } from 'react';
import { 
  User, 
  Lock, 
  Users, 
  Brain, 
  LayoutDashboard, 
  FileText, 
  Palette, 
  Bell, 
  CreditCard, 
  Globe, 
  LifeBuoy,
  MessageSquare,
  Camera,
  Smartphone,
  Shield,
  ShieldCheck,
  Eye,
  EyeOff,
  Zap,
  Mic,
  Moon,
  Sun,
  Layout,
  Clock,
  ExternalLink,
  ChevronRight,
  Sparkles,
  Cloud,
  Check
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { useAuth } from '../contexts/AuthContext';

const SECTIONS = [
  { id: 'profile', title: 'Perfil Profissional', icon: User, description: 'Sua identidade clínica' },
  { id: 'security', title: 'Segurança & Acesso', icon: Lock, description: 'Proteção e privacidade' },
  { id: 'exclusivity', title: 'Propriedade Intelectual', icon: Shield, description: 'Certificado de autoria' },
  { id: 'patients', title: 'Config. Pacientes', icon: Users, description: 'Fluxo e visualização' },
  { id: 'ai', title: 'Inteligência Artificial', icon: Brain, description: 'Automação e insights' },
  { id: 'dashboard', title: 'Dashboard & Agenda', icon: LayoutDashboard, description: 'Organização do espaço' },
  { id: 'reports', title: 'Relatórios & Docs', icon: FileText, description: 'Geração automática' },
  { id: 'experience', title: 'Experiência Visual', icon: Palette, description: 'Temas e efeitos' },
  { id: 'notifications', title: 'Notificações', icon: Bell, description: 'Alertas e lembretes' },
  { id: 'support', title: 'Ajuda & Suporte', icon: LifeBuoy, description: 'Central de auxílio' },
];

export default function Settings() {
  const [activeTab, setActiveTab] = useState('profile');
  const { user } = useAuth();
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 pb-20">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="space-y-1">
          <h2 className="text-3xl font-bold text-white italic-serif">Configurações Inteligentes</h2>
          <p className="text-slate-500 text-sm">Personalize sua central de comando clínica e digital.</p>
        </div>
        <div className="flex items-center gap-3">
          <AnimatePresence>
            {saved && (
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest bg-emerald-500/10 px-4 py-2 rounded-full border border-emerald-500/20"
              >
                <Check size={14} />
                <span>Alterações Salvas</span>
              </motion.div>
            )}
          </AnimatePresence>
          <button 
            onClick={handleSave}
            className="px-8 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl text-xs font-bold uppercase tracking-widest transition-all shadow-lg shadow-indigo-500/20"
          >
            Salvar Configurações
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-8">
        {/* Sidebar Tabs */}
        <aside className="space-y-2">
          {SECTIONS.map((section) => (
            <button
              key={section.id}
              onClick={() => setActiveTab(section.id)}
              className={cn(
                "w-full flex items-center gap-4 p-4 rounded-2xl transition-all group border text-left",
                activeTab === section.id
                  ? "bg-indigo-500/10 border-indigo-500/30 text-white"
                  : "bg-white/5 border-transparent text-slate-500 hover:bg-white/10 hover:text-slate-300"
              )}
            >
              <section.icon size={20} className={cn(
                activeTab === section.id ? "text-indigo-400" : "text-slate-600 group-hover:text-slate-400"
              )} />
              <div className="flex flex-col">
                <span className="text-xs font-bold uppercase tracking-widest">{section.title}</span>
                <span className="text-[10px] opacity-60 font-medium">{section.description}</span>
              </div>
              {activeTab === section.id && <ChevronRight size={14} className="ml-auto text-indigo-400" />}
            </button>
          ))}
        </aside>

        {/* Content Area */}
        <div className="bg-slate-900/50 border border-white/5 rounded-[2.5rem] p-8 lg:p-12 min-h-[600px] backdrop-blur-sm relative overflow-hidden">
          {/* Subtle Background Glow */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[100px] pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-purple-500/5 blur-[100px] pointer-events-none" />

          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-10 relative z-10"
            >
              {/* Profile Section */}
              {activeTab === 'profile' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-8">
                    <div className="relative group">
                      <div className="w-32 h-32 rounded-[2rem] bg-indigo-500/10 border-2 border-white/5 overflow-hidden flex items-center justify-center transition-all group-hover:border-indigo-500/50">
                        <User size={48} className="text-indigo-500/40" />
                      </div>
                      <button className="absolute -bottom-2 -right-2 w-10 h-10 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-xl border-4 border-slate-900 hover:scale-110 transition-transform">
                        <Camera size={16} />
                      </button>
                    </div>
                    <div className="space-y-2">
                      <h3 className="text-2xl font-bold text-white italic-serif">Identidade Profissional</h3>
                      <p className="text-slate-500 text-sm">Como seus pacientes e o sistema identificam você.</p>
                      <div className="flex gap-2 pt-2">
                        <span className="px-3 py-1 bg-white/5 rounded-lg text-[10px] font-bold text-slate-400 uppercase tracking-widest border border-white/5 italic">Verificado IA</span>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Nome Completo</label>
                      <input type="text" className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all" defaultValue={user?.name || "Dr. Fernando Silva"} />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Especialidade Principal</label>
                      <input type="text" className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all" defaultValue="Psicólogo Clínico & Hipnoterapeuta" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">CRP / Registro Profissional</label>
                      <input type="text" className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all" defaultValue="CRP 06/123456" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Cidade / Estado</label>
                      <input type="text" className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all" defaultValue="São Paulo, SP" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Bio Profissional</label>
                    <textarea rows={4} className="w-full bg-white/5 border border-white/5 rounded-3xl py-4 px-6 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all resize-none" defaultValue="Especialista em saúde emocional e reprogramação mental com mais de 10 anos de experiência clínica." />
                  </div>
                </div>
              )}

              {/* AI Section (Critical) */}
              {activeTab === 'ai' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-indigo-500/20 rounded-2xl flex items-center justify-center text-indigo-400">
                      <Brain size={24} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white italic-serif">Cérebro Digital IA</h3>
                      <p className="text-slate-500 text-sm">Configure o nível de assistência da inteligência artificial.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="p-6 bg-white/5 border border-white/5 rounded-[2rem] space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm font-bold text-white">Insights Automáticos</p>
                          <p className="text-[10px] text-slate-500 font-medium italic">IA analisa relatos em tempo real</p>
                        </div>
                        <div className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" className="sr-only peer" defaultChecked />
                          <div className="w-11 h-6 bg-slate-800 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                        </div>
                      </div>
                    </div>

                    <div className="p-6 bg-white/5 border border-white/5 rounded-[2rem] space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="space-y-1">
                          <p className="text-sm font-bold text-white">Transcrição de Áudio</p>
                          <p className="text-[10px] text-slate-500 font-medium italic">Conversão de fala para notas clínicas</p>
                        </div>
                        <div className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" className="sr-only peer" defaultChecked />
                          <div className="w-11 h-6 bg-slate-800 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-indigo-500/5 p-8 rounded-[2.5rem] border border-indigo-500/10 space-y-6">
                    <div className="flex items-center gap-3 mb-2">
                      <Sparkles size={20} className="text-indigo-400" />
                      <h4 className="text-sm font-bold text-white uppercase tracking-widest">Base Teórica da Assistente IA</h4>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                      {['Psicanálise', 'TCC', 'Existencial', 'Hipnoterapia', 'Integrativa', 'Gestalt', 'Humanista', 'Junguiana'].map(line => (
                        <button key={line} className="px-4 py-3 rounded-2xl bg-white/5 border border-white/5 text-[10px] font-bold text-slate-400 uppercase tracking-widest hover:bg-indigo-500/10 hover:border-indigo-500/30 transition-all">
                          {line}
                        </button>
                      ))}
                    </div>
                    <p className="text-[10px] text-slate-500 italic text-center">A IA moldará seus insights e relatórios com base na linha teórica selecionada.</p>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Configurações de Voz (IA)</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold text-slate-400">Velocidade da Fala</span>
                            <span className="text-indigo-400 font-mono text-xs">1.0x</span>
                          </div>
                          <input type="range" className="w-full h-1.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-indigo-500" />
                       </div>
                       <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-bold text-slate-400">Tom Emocional</span>
                            <span className="text-indigo-400 font-mono text-xs">Acolhedor</span>
                          </div>
                          <input type="range" className="w-full h-1.5 bg-slate-800 rounded-full appearance-none cursor-pointer accent-indigo-500" />
                       </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Experience / Visual Section */}
              {activeTab === 'experience' && (
                <div className="space-y-10">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-purple-500/20 rounded-2xl flex items-center justify-center text-purple-400">
                      <Palette size={24} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white italic-serif">Atmosfera Visual</h3>
                      <p className="text-slate-500 text-sm">O ambiente digital onde sua mente trabalha.</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Temas Premium</h4>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                      {[
                        { name: 'Azul Terapêutico', class: 'bg-blue-600' },
                        { name: 'Lilás Emocional', class: 'bg-purple-600' },
                        { name: 'Verde Calmante', class: 'bg-emerald-600' },
                        { name: 'Dark Premium', class: 'bg-slate-950 border border-white/20' },
                        { name: 'Futurista IA', class: 'bg-indigo-600' },
                        { name: 'Gold Executive', class: 'bg-amber-600' },
                        { name: 'Branco Minimalista', class: 'bg-white' },
                      ].map((theme) => (
                        <button key={theme.name} className="flex flex-col items-center gap-3 group">
                           <div className={cn("w-full h-20 rounded-2xl p-1 transition-all group-hover:scale-105 group-hover:ring-2 ring-indigo-500/50 shadow-lg", theme.class)} />
                           <span className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter group-hover:text-slate-300">{theme.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Efeitos de Imersão</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                       {[
                         { id: 'glass', title: 'Glassmorphism', desc: 'Transparências e blurs suaves' },
                         { id: 'particles', title: 'Partículas Emocionais', desc: 'Movimentos sutis em background' },
                         { id: 'glow', title: 'Brilho Terapêutico', desc: 'Luzes dinâmicas que acompanham o humor' },
                         { id: 'transitions', title: 'Transições Premium', desc: 'Animações fluidas entre telas' },
                       ].map(effect => (
                        <div key={effect.id} className="p-6 bg-white/5 border border-white/5 rounded-3xl flex items-center justify-between">
                           <div className="space-y-1">
                             <p className="text-sm font-bold text-white">{effect.title}</p>
                             <p className="text-[10px] text-slate-500 italic">{effect.desc}</p>
                           </div>
                           <div className="relative inline-flex items-center cursor-pointer">
                              <input type="checkbox" className="sr-only peer" defaultChecked />
                              <div className="w-11 h-6 bg-slate-800 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                            </div>
                        </div>
                       ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Security Section */}
              {activeTab === 'security' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-rose-500/20 rounded-2xl flex items-center justify-center text-rose-400">
                      <Shield size={24} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white italic-serif">Fortaleza de Dados</h3>
                      <p className="text-slate-500 text-sm">Privacidade absoluta para você e seus pacientes.</p>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="p-8 bg-rose-500/5 border border-rose-500/10 rounded-[2.5rem] space-y-6">
                      <div className="flex items-center justify-between">
                         <div className="space-y-1">
                           <h4 className="text-lg font-bold text-white italic-serif">Privacidade Clínica Avançada</h4>
                           <p className="text-xs text-slate-500">Ocultar automaticamente informações sensíveis em locais públicos.</p>
                         </div>
                         <div className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" />
                            <div className="w-11 h-6 bg-slate-800 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-600"></div>
                          </div>
                      </div>
                      
                      <div className="h-px bg-rose-500/10" />

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                         <button className="p-6 bg-white/5 border border-white/5 rounded-3xl flex items-center gap-4 text-left hover:bg-white/10 transition-all group">
                            <Smartphone className="text-rose-400" size={24} />
                            <div>
                               <p className="text-sm font-bold text-white">Biometria / Face ID</p>
                               <p className="text-[10px] text-slate-500">Ativar no aplicativo móvel</p>
                            </div>
                            <ChevronRight size={14} className="ml-auto text-slate-600 group-hover:translate-x-1 transition-transform" />
                         </button>
                         <button className="p-6 bg-white/5 border border-white/5 rounded-3xl flex items-center gap-4 text-left hover:bg-white/10 transition-all group">
                            <Lock className="text-rose-400" size={24} />
                            <div>
                               <p className="text-sm font-bold text-white">2 Fatores (2FA)</p>
                               <p className="text-[10px] text-slate-500">Segurança extra no login</p>
                            </div>
                            <ChevronRight size={14} className="ml-auto text-slate-600 group-hover:translate-x-1 transition-transform" />
                         </button>
                      </div>
                    </div>

                    <div className="p-6 bg-white/5 border border-white/5 rounded-3xl space-y-4">
                      <div className="flex items-center justify-between">
                         <p className="text-sm font-bold text-white">Bloquear Print Screen</p>
                         <div className="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" className="sr-only peer" defaultChecked />
                            <div className="w-11 h-6 bg-slate-800 rounded-full peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-600"></div>
                          </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Exclusivity Section */}
              {activeTab === 'exclusivity' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-indigo-500/20 rounded-2xl flex items-center justify-center text-indigo-400">
                      <Shield size={24} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white italic-serif">Certificado de Exclusividade</h3>
                      <p className="text-slate-500 text-sm">Registro de propriedade intelectual e autoria do sistema.</p>
                    </div>
                  </div>

                  <div className="p-10 bg-gradient-to-br from-slate-900 to-indigo-950 border border-white/10 rounded-[3rem] relative overflow-hidden group shadow-2xl">
                    <div className="absolute top-0 right-0 p-8 opacity-10">
                       <Shield size={120} className="text-white" />
                    </div>
                    
                    <div className="space-y-8 relative z-10">
                       <div className="space-y-6">
                          <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 rounded-full border border-indigo-500/30">
                             <Sparkles size={12} className="text-indigo-400" />
                             <span className="text-[10px] font-black text-indigo-300 uppercase tracking-widest">Relatório de Autoria Consolidado</span>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                             <div className="space-y-1">
                                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Criador & Detentor dos Direitos</p>
                                <p className="text-2xl font-bold text-white italic-serif">Renato Fernandes</p>
                             </div>
                             <div className="space-y-1">
                                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Identificação Fiscal</p>
                                <p className="text-xl font-bold text-slate-300 font-mono">014.061.056-19</p>
                             </div>
                             <div className="space-y-1">
                                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Localização da Sede</p>
                                <p className="text-xl font-bold text-slate-300">Contagem - Minas Gerais</p>
                             </div>
                             <div className="space-y-1">
                                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status de Exclusividade</p>
                                <div className="flex items-center gap-2 text-emerald-400">
                                   <ShieldCheck size={20} />
                                   <span className="text-sm font-bold uppercase tracking-tighter">Sistema Protegido & Licenciado</span>
                                </div>
                             </div>
                          </div>
                       </div>

                       <div className="p-6 bg-black/40 rounded-2xl border border-white/5 space-y-4">
                          <div className="flex items-start gap-4">
                             <div className="w-8 h-8 rounded-lg bg-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0">
                                <Lock size={16} />
                             </div>
                             <p className="text-xs text-slate-400 leading-relaxed italic">
                                Este software é uma obra intelectual única, protegida por leis internacionais de direitos autorais. Qualquer tentativa de plágio, clonagem de código ou engenharia reversa sem autorização expressa do criador está sujeita a medidas judiciais cabíveis.
                             </p>
                          </div>
                       </div>

                       <div className="flex justify-end pt-4">
                          <p className="text-[10px] text-slate-600 font-bold uppercase tracking-[0.3em]">Signature Verified via Mentis Secure Node</p>
                       </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Patients Section */}
              {activeTab === 'patients' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-400">
                      <Users size={24} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white italic-serif">Fichas e Prontuários</h3>
                      <p className="text-slate-500 text-sm">Personalize a visualização e os dados coletados.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="p-8 bg-white/5 border border-white/5 rounded-[2.5rem] space-y-6">
                      <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Exibição na Listagem</h4>
                      <div className="space-y-4">
                        {[
                          { label: 'Avatar Emocional IA', checked: true },
                          { label: 'Último Humor Detectado', checked: true },
                          { label: 'Idade e Profissão', checked: true },
                          { label: 'Status de Tratamento', checked: false },
                        ].map(field => (
                          <div key={field.label} className="flex items-center justify-between">
                            <span className="text-xs text-slate-300">{field.label}</span>
                            <input type="checkbox" className="w-4 h-4 rounded-lg bg-slate-800 border-white/10 text-indigo-600 focus:ring-0" defaultChecked={field.checked} />
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="p-8 bg-white/5 border border-white/5 rounded-[2.5rem] space-y-6">
                      <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Campos da Anamnese</h4>
                      <div className="space-y-4">
                        {[
                          { label: 'Histórico Familiar', checked: true },
                          { label: 'Uso de Medicamentos', checked: true },
                          { label: 'Relacionamentos Afetivos', checked: true },
                          { label: 'Ocupação Profissional', checked: true },
                          { label: 'Traumas Infantis', checked: true },
                        ].map(field => (
                          <div key={field.label} className="flex items-center justify-between">
                            <span className="text-xs text-slate-300">{field.label}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-[9px] font-bold text-indigo-400 uppercase tracking-tighter bg-indigo-500/10 px-2 py-0.5 rounded">Obrigatório</span>
                              <input type="checkbox" className="w-4 h-4 rounded-lg bg-slate-800 border-white/10 text-indigo-600 focus:ring-0" defaultChecked={field.checked} />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Dashboard Section */}
              {activeTab === 'dashboard' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-amber-500/20 rounded-2xl flex items-center justify-center text-amber-400">
                      <LayoutDashboard size={24} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white italic-serif">Layout da Clínica</h3>
                      <p className="text-slate-500 text-sm">Organize seus widgets e informações prioritárias.</p>
                    </div>
                  </div>

                  <div className="p-8 bg-white/5 border border-white/5 rounded-[2.5rem] space-y-6">
                    <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Organização de Cards</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {[
                        { label: 'Agenda Diária', icon: Clock },
                        { label: 'Humor Global', icon: Brain },
                        { label: 'Pacientes Ativos', icon: Users },
                        { label: 'Resumo IA', icon: Sparkles },
                      ].map(card => (
                        <div key={card.label} className="p-4 bg-slate-900 border border-white/5 rounded-2xl border-dashed flex flex-col items-center gap-3 group hover:border-amber-500/50 cursor-move transition-colors">
                           <card.icon size={20} className="text-slate-600 group-hover:text-amber-400" />
                           <span className="text-[10px] font-bold text-slate-500 group-hover:text-amber-200">{card.label}</span>
                        </div>
                      ))}
                    </div>
                    <p className="text-[9px] text-slate-600 text-center uppercase tracking-widest">Arraste para reorganizar sua visão prioritária</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                     <div className="p-6 bg-white/5 border border-white/5 rounded-3xl space-y-4">
                        <div className="flex items-center justify-between">
                           <div className="space-y-1">
                              <p className="text-sm font-bold text-white">Cronômetro Terapêutico</p>
                              <p className="text-[10px] text-slate-500">Exibir alerta visual ao final da sessão</p>
                           </div>
                           <input type="checkbox" className="w-4 h-4 rounded-lg bg-slate-800 border-white/10 text-indigo-600 focus:ring-0" defaultChecked />
                        </div>
                        <div className="pt-2">
                           <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Tempo Padrão de Sessão</label>
                           <select className="w-full mt-2 bg-slate-800 border-none rounded-xl py-3 px-4 text-xs text-slate-300 outline-none">
                              <option>45 minutos</option>
                              <option>50 minutos</option>
                              <option>60 minutos</option>
                           </select>
                        </div>
                     </div>

                     <div className="p-6 bg-white/5 border border-white/5 rounded-3xl space-y-4">
                        <div className="flex items-center justify-between">
                           <div className="space-y-1">
                              <p className="text-sm font-bold text-white">Integração Zoom/Meet</p>
                              <p className="text-[10px] text-slate-500">Gerar links automaticamente</p>
                           </div>
                           <input type="checkbox" className="w-4 h-4 rounded-lg bg-slate-800 border-white/10 text-indigo-600 focus:ring-0" />
                        </div>
                        <button className="w-full py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-bold text-slate-400 uppercase tracking-widest hover:bg-white/10 transition-all">
                           Conectar Google Calendar
                        </button>
                     </div>
                  </div>
                </div>
              )}

              {/* Support Section */}
              {activeTab === 'support' && (
                <div className="space-y-8">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 bg-indigo-500/20 rounded-2xl flex items-center justify-center text-indigo-400">
                      <LifeBuoy size={24} />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white italic-serif">Suporte & Conhecimento</h3>
                      <p className="text-slate-500 text-sm">Estamos aqui para garantir sua excelência clínica.</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {[
                      { title: 'Chat com IA Suporte', icon: MessageSquare, desc: 'Dúvidas rápidas sobre a plataforma' },
                      { title: 'Vídeo Tutoriais', icon: Smartphone, desc: 'Domine todos os recursos da Mentis' },
                      { title: 'Central de Ajuda', icon: Globe, desc: 'Documentação completa e guias' },
                    ].map(item => (
                      <button key={item.title} className="p-8 bg-white/5 border border-white/5 rounded-[2.5rem] flex flex-col items-center gap-4 text-center hover:bg-white/10 transition-all group">
                        <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
                           <item.icon size={24} />
                        </div>
                        <h4 className="text-sm font-bold text-white">{item.title}</h4>
                        <p className="text-[10px] text-slate-500 leading-relaxed font-medium">{item.desc}</p>
                      </button>
                    ))}
                  </div>

                  <div className="p-8 bg-indigo-600/10 border border-indigo-500/20 rounded-[2.5rem] flex flex-col md:flex-row items-center justify-between gap-6">
                     <div className="space-y-1 text-center md:text-left">
                        <h4 className="text-lg font-bold text-white italic-serif">Sugira uma Funcionalidade</h4>
                        <p className="text-xs text-indigo-300">Sua voz ajuda a moldar o futuro da Mentis Therapy AI.</p>
                     </div>
                     <button className="px-8 py-3 bg-indigo-600 rounded-2xl text-xs font-bold text-white uppercase tracking-widest shadow-lg shadow-indigo-500/20 hover:scale-105 transition-all">
                        Enviar Sugestão
                     </button>
                  </div>
                </div>
              )}

              {/* Placeholder for other sections */}
              {!['profile', 'ai', 'experience', 'security', 'patients', 'dashboard', 'support'].includes(activeTab) && (
                <div className="flex flex-col items-center justify-center py-20 space-y-4 opacity-50">
                  <Clock size={48} className="text-slate-600 animate-pulse" />
                  <p className="text-sm font-medium tracking-widest uppercase">Módulo em Integração Cognitiva...</p>
                  <p className="text-xs text-slate-500 italic max-w-xs text-center">Este recurso está sendo aprimorado para fornecer a melhor experiência premium possível.</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
