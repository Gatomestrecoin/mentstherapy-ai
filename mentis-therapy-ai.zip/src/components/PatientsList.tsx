import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Plus, 
  Search, 
  MoreVertical, 
  UserPlus, 
  Users,
  Filter,
  ChevronRight,
  ChevronLeft,
  Phone,
  Briefcase,
  Heart,
  Activity,
  FileText,
  Play,
  X,
  Brain,
  ShieldAlert,
  Camera,
  Mic,
  Sparkles,
  CheckCircle2,
  Smile,
  Target,
  CloudLightning as Trauma,
  History,
  Palette,
  Eye,
  Star,
  Clock,
  TrendingUp,
  Calendar as CalendarIcon,
  BrainCircuit
} from 'lucide-react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  ResponsiveContainer 
} from 'recharts';
import { Patient } from '../types';
import { cn } from '../lib/utils';

const EMOTIONAL_COLORS = {
  ansiedade: 'from-purple-500/20 to-indigo-500/20',
  tristeza: 'from-blue-500/20 to-slate-500/20',
  equilibrio: 'from-emerald-500/20 to-teal-500/20',
  trauma: 'from-rose-500/20 to-orange-500/20',
  autoestima: 'from-amber-500/20 to-yellow-500/20',
};

const STEPS = [
  { id: 1, title: 'Identidade Humana', icon: Users },
  { id: 2, title: 'Primeira Escuta', icon: Sparkles },
  { id: 3, title: 'Expectativas & Alinhamento', icon: Target },
  { id: 4, title: 'Perfil Prévio IA', icon: Brain },
];

export default function PatientsList({ patients, setPatients }: { patients: Patient[], setPatients: React.Dispatch<React.SetStateAction<Patient[]>> }) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [isRecording, setIsRecording] = useState(false);

  const [newPatient, setNewPatient] = useState<Partial<Patient>>({
    name: '',
    preferredName: '',
    age: 0,
    cpf: '',
    phone: '',
    email: '',
    profession: '',
    maritalStatus: '',
    avatarUrl: '',
    emotionalColor: 'equilibrio',
    temperament: 'Fleumático',
    emotionalLevel: 50,
    ansiedade: 30,
    humor: 'Estável',
    sono: 'Normal',
    clinicalData: {
      mainComplaint: '',
      whatBroughtYouHere: '',
      expectations: '',
      durationOfSymptoms: '',
      medications: '',
      psychiatricHistory: '',
      familyHistory: '',
      infancyRelaionships: '',
      affectiveLife: '',
      spirituality: '',
      sexuality: '',
      traumas: '',
      addictions: '',
      habits: '',
      therapeuticGoals: [],
    }
  });

  const handleAddPatient = (e: React.FormEvent) => {
    e.preventDefault();
    const patient: Patient = {
      ...newPatient as Patient,
      id: Math.random().toString(36).substr(2, 9),
    };
    setPatients(prev => [...prev, patient]);
    setShowAddForm(false);
    setCurrentStep(1);
    setNewPatient({
      name: '',
      clinicalData: {
        mainComplaint: '',
        whatBroughtYouHere: '',
        expectations: '',
        durationOfSymptoms: '',
        medications: '',
        psychiatricHistory: '',
        familyHistory: '',
        infancyRelaionships: '',
        affectiveLife: '',
        spirituality: '',
        sexuality: '',
        traumas: '',
        addictions: '',
        habits: '',
        therapeuticGoals: [],
      }
    });
  };

  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.cpf.includes(searchTerm) ||
    p.temperament?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.clinicalData.mainComplaint.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="space-y-4"
    >
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight italic-serif">Consciências Mapeadas</h1>
          <p className="text-slate-400 text-sm font-medium">Gestão de históricos e conexões terapêuticas.</p>
        </div>
        <button 
          onClick={() => setShowAddForm(true)}
          className="flex items-center justify-center gap-2 bg-indigo-500 hover:bg-indigo-400 text-white px-5 py-3 rounded-xl font-bold transition-all shadow-lg shadow-indigo-500/20 active:scale-95 text-sm"
        >
          <UserPlus size={18} />
          <span>Cadastrar Consciência</span>
        </button>
      </div>

      <div className="flex gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-600" size={16} />
          <input 
            type="text" 
            placeholder="Mapear por nome ou CPF..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900/50 border border-white/5 rounded-xl py-3 pl-11 pr-4 text-slate-200 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500/50 transition-all outline-none"
          />
        </div>
        <button className="bg-slate-900/50 border border-white/5 p-3 rounded-xl text-slate-400 hover:bg-white/5 transition-colors">
          <Filter size={18} />
        </button>
      </div>

      <div className="space-y-3">
        {filteredPatients.length === 0 ? (
          <div className="bg-slate-900/30 border border-dashed border-white/10 rounded-[2rem] p-16 text-center">
            <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-xl border border-white/5">
              <Users size={24} className="text-slate-700" />
            </div>
            <h3 className="text-xl font-bold text-white mb-1 italic-serif">Vazio Existencial</h3>
            <p className="text-slate-500 text-sm max-w-xs mx-auto">Nenhuma consciência mapeada no sistema. Inicie um novo cadastro.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredPatients.map((patient) => (
              <motion.div 
                layoutId={patient.id}
                key={patient.id} 
                onClick={() => setSelectedPatient(patient)}
                className="bg-slate-900/50 backdrop-blur-3xl p-6 rounded-[2.5rem] border border-white/5 hover:border-indigo-500/30 hover:bg-slate-900 transition-all cursor-pointer group relative overflow-hidden shadow-xl"
              >
                {/* Aura Background */}
                <div className={cn(
                  "absolute -right-10 -top-10 w-32 h-32 blur-[80px] rounded-full transition-all duration-700 opacity-20 group-hover:opacity-40",
                  `bg-gradient-to-br ${EMOTIONAL_COLORS[patient.emotionalColor as keyof typeof EMOTIONAL_COLORS] || EMOTIONAL_COLORS.equilibrio}`
                )} />

                <div className="flex items-center gap-4 mb-6 relative z-10">
                  <div className={cn(
                    "w-14 h-14 rounded-2xl flex items-center justify-center text-white text-xl font-bold border border-white/10 shadow-lg transition-transform group-hover:scale-110",
                    `bg-gradient-to-br ${EMOTIONAL_COLORS[patient.emotionalColor as keyof typeof EMOTIONAL_COLORS] || EMOTIONAL_COLORS.equilibrio}`
                  )}>
                    {patient.avatarUrl ? (
                      <img src={patient.avatarUrl} alt="" className="w-full h-full object-cover rounded-2xl" />
                    ) : patient.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white group-hover:text-indigo-400 transition-colors italic-serif">{patient.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{patient.temperament}</span>
                      <span className="w-1 h-1 rounded-full bg-white/10" />
                      <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{patient.age} Ciclos</span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-6 relative z-10">
                  <div className="bg-white/5 p-3 rounded-2xl border border-white/5">
                    <p className="text-[8px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-1">Nível Emocional</p>
                    <div className="flex items-baseline gap-1">
                      <span className="text-lg font-bold text-white">{patient.emotionalLevel || 0}%</span>
                      <TrendingUp size={12} className="text-emerald-400" />
                    </div>
                  </div>
                  <div className="bg-white/5 p-3 rounded-2xl border border-white/5">
                    <p className="text-[8px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-1">Sessões</p>
                    <span className="text-lg font-bold text-white">08</span>
                  </div>
                </div>

                <div className="space-y-2 bg-white/5 p-4 rounded-2xl border border-white/5 relative z-10">
                  <div className="flex items-center justify-between">
                    <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">IA Alerta</p>
                    {patient.riskLevel === 'high' && <ShieldAlert size={12} className="text-rose-400" />}
                  </div>
                  <p className="text-xs text-slate-300 line-clamp-2 italic italic-serif leading-relaxed">
                    "{patient.clinicalData.mainComplaint}"
                  </p>
                </div>

                <div className="mt-6 flex items-center justify-between relative z-10">
                   <div className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                      <CalendarIcon size={12} />
                      Próxima: 18 Mai
                   </div>
                   <div className="w-8 h-8 bg-indigo-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 transform translate-y-1 opacity-0 group-hover:opacity-100 group-hover:translate-y-0 transition-all">
                      <ChevronRight size={18} />
                   </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Patient Details Modal */}
      <AnimatePresence>
        {selectedPatient && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-white/10 rounded-[3rem] w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl relative"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/[0.02]">
                <div className="flex items-center gap-4">
                  <div className={cn(
                    "w-14 h-14 rounded-2xl flex items-center justify-center text-white text-2xl font-bold shadow-2xl border border-white/10",
                    `bg-gradient-to-br ${EMOTIONAL_COLORS[selectedPatient.emotionalColor as keyof typeof EMOTIONAL_COLORS] || EMOTIONAL_COLORS.equilibrio}`
                  )}>
                    {selectedPatient.avatarUrl ? (
                      <img src={selectedPatient.avatarUrl} alt="" className="w-full h-full object-cover rounded-2xl" />
                    ) : selectedPatient.name.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-3">
                      <h2 className="text-3xl font-bold text-white italic-serif">{selectedPatient.preferredName || selectedPatient.name}</h2>
                      {selectedPatient.riskLevel && (
                        <span className={cn(
                          "px-2 py-0.5 rounded-full text-[8px] font-black uppercase tracking-widest border",
                          selectedPatient.riskLevel === 'high' || selectedPatient.riskLevel === 'severe' 
                            ? "bg-rose-500/10 border-rose-500/50 text-rose-400" 
                            : "bg-emerald-500/10 border-emerald-500/50 text-emerald-400"
                        )}>
                          Risco {selectedPatient.riskLevel}
                        </span>
                      )}
                    </div>
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mt-0.5">
                      {selectedPatient.name} • {selectedPatient.profession} • {selectedPatient.age} Anos
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                   <div className="text-right hidden md:block">
                      <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Temperamento</p>
                      <p className="text-sm font-bold text-indigo-400">{selectedPatient.temperament || 'Não definido'}</p>
                   </div>
                   <button 
                    onClick={() => setSelectedPatient(null)}
                    className="w-10 h-10 flex items-center justify-center bg-white/5 hover:bg-white/10 text-slate-400 rounded-full transition-all"
                  >
                    <X size={20} />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-8 lg:p-12 custom-scrollbar bg-slate-900/50">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
                  {/* Left Column: Quick Profile & Stats */}
                  <div className="lg:col-span-4 space-y-8">
                    {/* IA Emotional Profile Card */}
                    <div className="bg-white/[0.03] p-8 rounded-[2.5rem] border border-white/5 space-y-6 relative overflow-hidden group">
                       <div className={cn(
                          "absolute -right-20 -top-20 w-48 h-48 blur-[100px] rounded-full opacity-20",
                          `bg-gradient-to-br ${EMOTIONAL_COLORS[selectedPatient.emotionalColor as keyof typeof EMOTIONAL_COLORS] || EMOTIONAL_COLORS.equilibrio}`
                       )} />
                       
                       <h3 className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest flex items-center gap-2">
                         <Brain size={12} /> Perfil Psíquico IA
                       </h3>
                       
                       <div className="space-y-4 relative z-10">
                          <div className="space-y-1.5">
                             <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 uppercase">
                                <span>Nível Emocional</span>
                                <span className="text-white">{selectedPatient.emotionalLevel}%</span>
                             </div>
                             <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                                <motion.div 
                                  initial={{ width: 0 }}
                                  animate={{ width: `${selectedPatient.emotionalLevel}%` }}
                                  className="h-full bg-indigo-500"
                                />
                             </div>
                          </div>
                          
                          <div className="space-y-1.5">
                             <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 uppercase">
                                <span>Ansiedade</span>
                                <span className="text-purple-400">{selectedPatient.ansiedade}%</span>
                             </div>
                             <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                                <motion.div 
                                  initial={{ width: 0 }}
                                  animate={{ width: `${selectedPatient.ansiedade}%` }}
                                  className="h-full bg-purple-500"
                                />
                             </div>
                          </div>
                       </div>

                       <div className="grid grid-cols-2 gap-4 mt-6">
                          <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                             <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mb-1">Dormitório</p>
                             <p className="text-xs font-bold text-slate-200">{selectedPatient.sono || 'Normal'}</p>
                          </div>
                          <div className="p-4 bg-white/5 rounded-2xl border border-white/5">
                             <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mb-1">Humor</p>
                             <p className="text-xs font-bold text-slate-200">{selectedPatient.humor || 'Estável'}</p>
                          </div>
                       </div>
                    </div>

                    {/* Contact & Meta */}
                    <div className="bg-white/[0.03] p-8 rounded-[2.5rem] border border-white/5">
                      <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-6 flex items-center gap-2">
                        <UserPlus size={12} /> Dados Identitários
                      </h3>
                      <div className="space-y-5">
                        {[
                          { label: 'Telefone', value: selectedPatient.phone, icon: Phone, color: 'text-indigo-400' },
                          { label: 'E-mail', value: selectedPatient.email || 'Não informado', icon: Star, color: 'text-emerald-400' },
                          { label: 'Identificador', value: selectedPatient.cpf, icon: Activity, color: 'text-amber-400' },
                          { label: 'Vínculo', value: selectedPatient.maritalStatus, icon: Heart, color: 'text-rose-400' },
                        ].map((item, i) => (
                          <div key={i} className="flex items-center gap-4 group">
                             <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-slate-500 group-hover:bg-white/10 group-hover:text-white transition-all">
                                <item.icon size={16} />
                             </div>
                             <div>
                                <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest leading-none mb-1">{item.label}</p>
                                <p className="text-sm font-medium text-slate-300">{item.value}</p>
                             </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Weekly Mood Trend (Existing style but enhanced) */}
                    <div className="bg-white/5 border border-white/5 p-6 rounded-[2.5rem]">
                       <div className="flex items-center justify-between mb-6">
                         <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Fluxo Semanal</span>
                         <TrendingUp size={14} className="text-emerald-400" />
                       </div>
                       <div className="flex items-end gap-1.5 h-16 px-2">
                          {[40, 70, 45, 90, 65, 80, 50].map((h, i) => (
                            <motion.div 
                              key={i}
                              initial={{ height: 0 }}
                              animate={{ height: `${h}%` }}
                              className="flex-1 bg-indigo-500/30 rounded-t-lg hover:bg-indigo-400/50 transition-colors cursor-pointer"
                            />
                          ))}
                       </div>
                    </div>
                  </div>

                  {/* Right Column: Deep Clinical Storytelling */}
                  <div className="lg:col-span-8 space-y-10">
                    {/* IA Synthesis Header */}
                    <section className="bg-indigo-500/5 p-8 rounded-[2.5rem] border border-indigo-500/10 relative overflow-hidden">
                       <div className="absolute top-0 right-0 p-4">
                          <BrainCircuit size={48} className="text-indigo-500/10 animate-pulse" />
                       </div>
                       <h3 className="text-xl font-bold text-white mb-4 italic-serif flex items-center gap-3">
                         Síntese Terapêutica IA
                       </h3>
                       <p className="text-slate-300 leading-relaxed italic text-lg lg:text-xl font-medium italic-serif">
                         "{selectedPatient.aiSummary || `Paciente apresenta perfil ${selectedPatient.temperament} com foco em ${selectedPatient.clinicalData.mainComplaint.toLowerCase()}. É perceptível uma necessidade latente de acolhimento e ressignificação de vínculos.`}"
                       </p>
                    </section>
                    
                    {/* The Core Story */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                       <section className="space-y-4">
                          <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                            <Sparkles size={12} className="text-indigo-400" /> Primeira Escuta
                          </h4>
                          <div className="bg-white/5 p-6 rounded-3xl border border-white/5 min-h-[120px]">
                            <p className="text-sm text-slate-400 leading-relaxed italic">
                              {selectedPatient.clinicalData.whatBroughtYouHere || 'Não registrado.'}
                            </p>
                          </div>
                       </section>

                       <section className="space-y-4">
                          <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2">
                            <Trauma size={12} className="text-rose-400" /> Cicatrizes e Marcas
                          </h4>
                          <div className="bg-rose-500/5 p-6 rounded-3xl border border-rose-500/10 min-h-[120px]">
                            <p className="text-sm text-slate-400 leading-relaxed">
                              {selectedPatient.clinicalData.traumas || 'Nenhum trauma crítico mapeado.'}
                            </p>
                          </div>
                       </section>
                    </div>

                    {/* Relational Mapping */}
                    <section className="space-y-6">
                       <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Mapeamento de Vínculos</h4>
                       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div className="bg-white/5 p-6 rounded-3xl border border-white/5">
                             <div className="flex items-center gap-3 mb-3">
                               <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                                  <Heart size={16} />
                               </div>
                               <span className="text-sm font-bold text-white italic-serif">Infância e Origens</span>
                             </div>
                             <p className="text-xs text-slate-400 leading-relaxed">
                                {selectedPatient.clinicalData.infancyRelaionships || 'Não detalhado.'}
                             </p>
                          </div>
                          <div className="bg-white/5 p-6 rounded-3xl border border-white/5">
                             <div className="flex items-center gap-3 mb-3">
                               <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-400">
                                  <Users size={16} />
                               </div>
                               <span className="text-sm font-bold text-white italic-serif">Vida Afetiva Atual</span>
                             </div>
                             <p className="text-xs text-slate-400 leading-relaxed">
                                {selectedPatient.clinicalData.affectiveLife || 'Não detalhado.'}
                             </p>
                          </div>
                       </div>
                    </section>

                    {/* Objective Tags */}
                    <section className="bg-slate-950/30 p-8 rounded-[2.5rem] border border-white/5">
                       <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-6">Objetivos da Jornada</h4>
                       <div className="flex flex-wrap gap-3">
                          {(selectedPatient.clinicalData.therapeuticGoals && selectedPatient.clinicalData.therapeuticGoals.length > 0) ? (
                            selectedPatient.clinicalData.therapeuticGoals.map((goal, idx) => (
                              <span key={idx} className="px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-xs font-medium text-indigo-400">
                                {goal}
                              </span>
                            ))
                          ) : (
                            <p className="text-xs text-slate-500 italic">Nenhum objetivo específico registrado ainda.</p>
                          )}
                          <button className="px-4 py-2 bg-white/5 border border-dashed border-white/10 rounded-xl text-xs font-bold text-slate-500 hover:text-slate-300 transition-all">
                            + Adicionar Meta
                          </button>
                       </div>
                    </section>
                  </div>
                </div>
              </div>

              <div className="p-6 border-t border-white/5 flex justify-end gap-3 bg-white/[0.01]">
                <button 
                  onClick={() => setSelectedPatient(null)}
                  className="px-6 py-3 rounded-xl font-bold text-slate-400 hover:bg-white/5 transition-all text-[11px] uppercase tracking-widest"
                >
                  Fechar
                </button>
                <button className="px-8 py-3 bg-indigo-500 text-white rounded-xl font-bold hover:bg-indigo-400 transition-all flex items-center gap-2 shadow-lg shadow-indigo-500/20 text-[11px] uppercase tracking-widest">
                  <Play size={14} fill="currentColor" />
                  Imersão AI
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Patient Modal */}
      <AnimatePresence>
        {showAddForm && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-white/10 rounded-[3rem] w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl"
            >
              <div className="p-8 border-b border-white/5 flex items-center justify-between bg-white/[0.02]">
                <h2 className="text-2xl font-bold text-white italic-serif">Mapear Nova Consciência</h2>
                <button 
                  onClick={() => setShowAddForm(false)}
                  className="w-12 h-12 flex items-center justify-center bg-white/5 hover:bg-white/10 text-slate-400 rounded-full transition-all"
                >
                  <X />
                </button>
              </div>

              <form onSubmit={handleAddPatient} className="flex-1 flex flex-col overflow-hidden relative">
                <div className="flex-1 overflow-y-auto p-10 space-y-12 custom-scrollbar relative">
                  {/* Background Particles Decoration */}
                  <div className="absolute inset-0 pointer-events-none opacity-20 overflow-hidden">
                    <div className="absolute top-10 right-10 w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full animate-pulse" />
                    <div className="absolute bottom-10 left-10 w-96 h-96 bg-emerald-500/10 blur-[120px] rounded-full animate-pulse" style={{ animationDelay: '2s' }} />
                  </div>

                {/* Progress Bar */}
                <div className="relative z-10">
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em]">Fluxo de Consciência</span>
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-[0.2em]">{Math.round((currentStep / STEPS.length) * 100)}% concluído</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${(currentStep / STEPS.length) * 100}%` }}
                      className="h-full bg-gradient-to-r from-indigo-600 via-purple-500 to-indigo-400"
                    />
                  </div>
                  <div className="hidden lg:flex justify-between mt-4">
                    {STEPS.map((step) => (
                      <div key={step.id} className={cn(
                        "flex flex-col items-center gap-1 transition-all",
                        currentStep >= step.id ? "opacity-100" : "opacity-30"
                      )}>
                        <div className={cn(
                          "w-8 h-8 rounded-full flex items-center justify-center transition-all",
                          currentStep === step.id ? "bg-indigo-500 text-white shadow-lg shadow-indigo-500/40" : "bg-white/5 text-slate-500"
                        )}>
                          <step.icon size={14} />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Wizard Steps */}
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentStep}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="relative z-10"
                  >
                    {currentStep === 1 && (
                      <div className="space-y-10">
                        <div className="text-center space-y-2 mb-10">
                          <h3 className="text-3xl font-bold text-white italic-serif">Iniciando a Jornada Humana</h3>
                          <p className="text-slate-500 text-sm">O primeiro passo é reconhecer quem está à nossa frente.</p>
                        </div>
                        
                        <div className="flex flex-col items-center mb-10">
                          <div className="relative group">
                            <div className={cn(
                              "w-32 h-32 rounded-full border-4 border-white/5 flex items-center justify-center overflow-hidden bg-slate-950 transition-all group-hover:border-indigo-500/50",
                              `bg-gradient-to-br ${EMOTIONAL_COLORS[newPatient.emotionalColor as keyof typeof EMOTIONAL_COLORS] || EMOTIONAL_COLORS.equilibrio}`
                            )}>
                              {newPatient.avatarUrl ? (
                                <img src={newPatient.avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                              ) : (
                                <Camera size={40} className="text-slate-700" />
                              )}
                            </div>
                            <button type="button" className="absolute bottom-0 right-0 w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white border-4 border-slate-900 shadow-xl">
                              <Plus size={20} />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
                            <div className="space-y-2">
                              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Como prefere ser chamado(a)?</label>
                              <input 
                                type="text"
                                value={newPatient.preferredName}
                                onChange={e => setNewPatient({...newPatient, preferredName: e.target.value})}
                                placeholder="Ex: Maria"
                                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Nome Completo</label>
                              <input 
                                type="text"
                                value={newPatient.name}
                                onChange={e => setNewPatient({...newPatient, name: e.target.value})}
                                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Idade</label>
                              <input 
                                type="number"
                                value={newPatient.age}
                                onChange={e => setNewPatient({...newPatient, age: parseInt(e.target.value)})}
                                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all"
                              />
                            </div>
                            <div className="space-y-2">
                              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">Profissão</label>
                              <input 
                                type="text"
                                value={newPatient.profession}
                                onChange={e => setNewPatient({...newPatient, profession: e.target.value})}
                                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 px-6 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all"
                              />
                            </div>
                        </div>
                      </div>
                    )}

                    {currentStep === 2 && (
                      <div className="space-y-10">
                        <div className="text-center space-y-2 mb-10">
                          <h3 className="text-3xl font-bold text-white italic-serif">O que trouxe você até aqui hoje?</h3>
                          <p className="text-slate-500 text-sm">Este é o momento de escuta pura e acolhimento.</p>
                        </div>

                        <div className="space-y-8 max-w-4xl mx-auto">
                          <div className="space-y-4">
                            <div className="flex items-center justify-between">
                              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Queixa Principal (Sua Dor)</label>
                              <div className="flex items-center gap-2">
                                <button type="button" className="p-2 rounded-full bg-white/5 text-indigo-400">
                                  <Mic size={16} />
                                </button>
                                <Sparkles size={16} className="text-indigo-400 animate-pulse" />
                              </div>
                            </div>
                            <textarea 
                              rows={6}
                              value={newPatient.clinicalData?.whatBroughtYouHere}
                              onChange={e => setNewPatient({
                                ...newPatient, 
                                clinicalData: { ...newPatient.clinicalData!, whatBroughtYouHere: e.target.value }
                              })}
                              className="w-full bg-white/5 border border-white/5 rounded-3xl px-8 py-6 text-lg text-white italic-serif focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all resize-none"
                              placeholder="Sinta-se à vontade para expressar sua dor..."
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {currentStep === 3 && (
                      <div className="space-y-10">
                        <div className="text-center space-y-2 mb-10">
                          <h3 className="text-3xl font-bold text-white italic-serif">Expectativas & Alinhamento</h3>
                          <p className="text-slate-500 text-sm">Onde desejamos chegar ao fim desta jornada.</p>
                        </div>
                        <div className="max-w-4xl mx-auto space-y-8">
                          <div className="space-y-4">
                             <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">O que você espera do processo terapêutico?</label>
                             <textarea 
                               rows={6}
                               value={newPatient.clinicalData?.expectations}
                               onChange={e => setNewPatient({
                                 ...newPatient, 
                                 clinicalData: { ...newPatient.clinicalData!, expectations: e.target.value }
                               })}
                               className="w-full bg-white/5 border border-white/5 rounded-3xl px-8 py-6 text-white italic-serif focus:bg-white/10 focus:border-indigo-500/50 outline-none transition-all resize-none"
                             />
                          </div>
                        </div>
                      </div>
                    )}

                    {currentStep === 4 && (
                      <div className="space-y-10">
                        <div className="text-center space-y-2 mb-10">
                          <h3 className="text-3xl font-bold text-white italic-serif">Perfil Prévio IA</h3>
                          <p className="text-slate-500 text-sm">Primeiras conexões detectadas pela inteligência.</p>
                        </div>

                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
                           <div className="bg-indigo-500/10 p-8 rounded-[2rem] border border-indigo-500/20 relative overflow-hidden">
                              <h4 className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest mb-4">Primeira Análise Clínica IA</h4>
                              <p className="text-slate-200 text-base italic-serif leading-relaxed italic">
                                "Baseado no relato inicial, o paciente demonstra um núcleo latente de busca por acolhimento. O engajamento parece ser alto para processos de ressignificação. Profundidade emocional detectada em nível moderado."
                              </p>
                              <Sparkles className="absolute top-4 right-4 text-indigo-400 opacity-20" size={48} />
                           </div>

                           <div className="space-y-6">
                              <div className="p-6 bg-slate-950/50 rounded-[1.5rem] border border-white/5">
                                 <div className="flex items-center justify-between mb-4">
                                   <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Temas Recomendados para Anamnese Viva</span>
                                   <Target size={14} className="text-indigo-400" />
                                 </div>
                                 <div className="flex flex-wrap gap-2">
                                    {['Histórico Familiar', 'Padrões de Humor', 'Vínculos Sociais'].map(tag => (
                                      <span key={tag} className="px-3 py-1.5 bg-white/5 border border-white/5 rounded-lg text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                        {tag}
                                      </span>
                                    ))}
                                 </div>
                              </div>
                           </div>
                        </div>
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="p-8 border-t border-white/5 flex items-center justify-between bg-white/[0.01]">
                <div className="flex gap-4">
                  {currentStep > 1 && (
                    <button 
                      type="button"
                      onClick={() => setCurrentStep(prev => prev - 1)}
                      className="px-8 py-4 rounded-2xl font-bold text-slate-400 hover:bg-white/5 transition-all text-sm flex items-center gap-2"
                    >
                      <ChevronLeft size={18} />
                      Voltar
                    </button>
                  )}
                </div>
                
                <div className="flex gap-4">
                  {currentStep < 4 ? (
                    <button 
                      type="button"
                      onClick={() => setCurrentStep(prev => prev + 1)}
                      className="px-10 py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-500 transition-all shadow-lg shadow-indigo-600/20 flex items-center gap-2 text-sm"
                    >
                      Continuar Jornada
                      <ChevronRight size={18} />
                    </button>
                  ) : (
                    <button 
                      type="submit"
                      className="px-12 py-4 bg-emerald-500 text-white rounded-2xl font-bold hover:bg-emerald-400 transition-all shadow-lg shadow-emerald-500/20 active:scale-95 text-sm flex items-center gap-2"
                    >
                      <CheckCircle2 size={18} />
                      Efetivar Cadastro
                    </button>
                  )}
                </div>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  </motion.div>
);
}
