import React, { useState, useEffect } from 'react';
import { 
  Check, 
  Zap, 
  Crown, 
  Sparkles, 
  ShieldCheck, 
  CreditCard, 
  Smartphone, 
  Clock, 
  ArrowRight,
  Star,
  Layers,
  Infinity,
  HelpCircle,
  Building,
  Target
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

const PLANS = [
  {
    id: 'essencial',
    name: 'Plano Essencial',
    price: '49',
    priceYearly: '529',
    saving: '59',
    description: 'Ideal para profissionais que estão começando sua jornada digital.',
    color: 'from-blue-600 to-indigo-600',
    icon: Target,
    features: [
      'Até 20 pacientes ativos',
      'Agenda clínica inteligente',
      'Prontuário digital seguro',
      'Histórico terapêutico completo',
      'Anamnese baseada em IA',
      'Lembretes automáticos',
      'Dashboard básico',
      'Relatórios simples'
    ],
    annualBenefits: [
      '1 mês de bônus IA',
      'Templates básicos plus'
    ],
    buttonText: 'Começar Agora',
    popular: false
  },
  {
    id: 'profissional',
    name: 'Plano Profissional',
    price: '99',
    priceYearly: '1069',
    saving: '119',
    description: 'O equilíbrio perfeito entre tecnologia assistiva e prática clínica.',
    color: 'from-indigo-600 to-purple-600',
    icon: Sparkles,
    features: [
      'Tudo do Plano Essencial',
      'IA Clínica Avançada (GPT-4)',
      'Transcrição automática de áudio',
      'Relatórios gerados por IA',
      'Insights emocionais profundos',
      'Gráficos e evoluções',
      'Hipnoterapia assistida por IA',
      'Até 100 pacientes ativos'
    ],
    annualBenefits: [
      '1 mês de bônus IA premium',
      'Templates de evolução Profissional',
      'Vozes premium exclusivas'
    ],
    buttonText: 'Escolher o Mais Popular',
    popular: true,
    tag: 'MAIS POPULAR'
  },
  {
    id: 'elite',
    name: 'Plano Elite IA',
    price: '149',
    priceYearly: '1609',
    saving: '179',
    description: 'Para clínicos que exigem o máximo de performance e análise preditiva.',
    color: 'from-purple-600 to-rose-600',
    icon: Crown,
    features: [
      'Tudo do Plano Profissional',
      'Supervisão clínica por IA',
      'Suporte multiusuário (equipe)',
      'Gestão financeira clínica',
      'Análises avançadas de big data',
      'Pacientes Ilimitados',
      'IA Preditiva Emocional',
      'Dashboard Executivo'
    ],
    annualBenefits: [
      'Relatórios executivos exclusivos',
      'Selo Elite no perfil',
      'Suporte Prioritário VIP'
    ],
    buttonText: 'Upgrade para Elite',
    popular: false
  },
  {
    id: 'black',
    name: 'Plano Black Infinite',
    price: '259',
    priceYearly: '2797',
    saving: '311',
    description: 'A experiência definitiva de branding e potência tecnológica.',
    color: 'from-slate-800 to-black',
    icon: Infinity,
    features: [
      'Tudo do Plano Elite',
      'White Label (Sua marca/cor)',
      'Domínio Personalizado',
      'Branding Exclusivo no App',
      'API de Integração Própria',
      'Voz IA Premium (Estúdio)',
      'Suporte Prioritário VIP 24/7',
      'Backup em tempo real'
    ],
    annualBenefits: [
      'Onboarding VIP personalizado',
      'Consultoria estratégica mensal',
      'Personalização total da plataforma'
    ],
    buttonText: 'Solicitar Acesso Black',
    popular: false,
    tag: 'ULTRA PREMIUM'
  }
];

export default function Subscriptions() {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');
  const [timeLeft, setTimeLeft] = useState({ days: 6, hours: 14, mins: 22 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.mins > 0) return { ...prev, mins: prev.mins - 1 };
        if (prev.hours > 0) return { ...prev, hours: prev.hours - 1, mins: 59 };
        if (prev.days > 0) return { ...prev, days: prev.days - 1, hours: 23, mins: 59 };
        return prev;
      });
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-12 pb-20 px-4">
      {/* Header */}
      <div className="text-center space-y-4 max-w-3xl mx-auto">
        <motion.div
           initial={{ opacity: 0, scale: 0.9 }}
           animate={{ opacity: 1, scale: 1 }}
           className="inline-flex items-center gap-2 px-4 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-[10px] font-black text-indigo-400 uppercase tracking-[0.2em] mb-4"
        >
          <Zap size={14} className="fill-indigo-400" />
          <span>Assinatura Premium</span>
        </motion.div>
        <h1 className="text-4xl md:text-6xl font-bold text-white italic-serif leading-tight">
          Transforme sua clínica com <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-rose-400 animate-pulse">
            Inteligência Artificial.
          </span>
        </h1>
        <p className="text-slate-400 text-lg">
          A plataforma terapêutica mais inteligente para profissionais da saúde emocional.
        </p>

        {/* Billing Toggle */}
        <div className="flex flex-col items-center gap-4 pt-8">
           <div className="bg-slate-900 p-1 rounded-2xl border border-white/5 flex gap-1 relative">
              <button 
                onClick={() => setBillingCycle('monthly')}
                className={cn(
                  "px-8 py-3 rounded-xl text-xs font-bold uppercase tracking-widest transition-all relative z-10",
                  billingCycle === 'monthly' ? "text-white" : "text-slate-500 hover:text-slate-300"
                )}
              >
                Mensal
              </button>
              <button 
                onClick={() => setBillingCycle('yearly')}
                className={cn(
                  "px-8 py-3 rounded-xl text-xs font-bold uppercase tracking-widest transition-all relative z-10 flex items-center gap-2",
                  billingCycle === 'yearly' ? "text-white" : "text-slate-500 hover:text-slate-300"
                )}
              >
                Anual
                <span className="px-2 py-0.5 bg-emerald-500/10 text-emerald-400 text-[8px] font-black rounded-lg border border-emerald-500/20">
                   -10% 🔥
                </span>
              </button>
              {/* Animated Switcher background */}
              <motion.div 
                layoutId="cycle-bg"
                className="absolute inset-y-1 bg-indigo-600 rounded-xl shadow-lg shadow-indigo-500/20"
                animate={{
                  x: billingCycle === 'monthly' ? 4 : 106,
                  width: billingCycle === 'monthly' ? 98 : 142
                }}
                transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              />
           </div>
           <AnimatePresence mode="wait">
             {billingCycle === 'yearly' && (
               <motion.p 
                 initial={{ opacity: 0, y: -10 }}
                 animate={{ opacity: 1, y: 0 }}
                 exit={{ opacity: 0, y: -10 }}
                 className="text-[10px] font-bold text-emerald-400 uppercase tracking-[0.2em] italic"
               >
                 ✨ Economize até R$ 311 no plano anual ✨
               </motion.p>
             )}
           </AnimatePresence>
        </div>

        {/* Trial Countdown */}
        <div className="mt-8 inline-flex flex-col items-center gap-2 p-6 bg-rose-500/5 border border-rose-500/10 rounded-[2rem] relative overflow-hidden backdrop-blur-sm">
           <div className="relative z-10 flex flex-col items-center gap-3">
              <span className="text-[10px] font-bold text-rose-400 uppercase tracking-widest flex items-center gap-2">
                 <Clock size={12} /> Seu acesso Trial IA expira em:
              </span>
              <div className="flex gap-4">
                 {[
                   { label: 'Dias', val: timeLeft.days },
                   { label: 'Horas', val: timeLeft.hours },
                   { label: 'Min', val: timeLeft.mins },
                 ].map(t => (
                   <div key={t.label} className="flex flex-col items-center">
                      <span className="text-3xl font-bold text-white font-mono">{t.val.toString().padStart(2, '0')}</span>
                      <span className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">{t.label}</span>
                   </div>
                 ))}
              </div>
              <p className="text-[10px] text-slate-500 italic mt-2">
                "Profissionais premium economizam até 12 horas semanais com IA clínica."
              </p>
           </div>
           <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-rose-500/10 to-transparent opacity-30 pointer-events-none" />
        </div>
      </div>

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {PLANS.map((plan, idx) => (
          <motion.div
            key={plan.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            className={cn(
              "relative flex flex-col p-8 rounded-[2.5rem] border transition-all duration-500 group overflow-hidden",
              plan.popular 
                ? "bg-slate-900 border-indigo-500/50 shadow-2xl shadow-indigo-500/20 scale-105 z-10" 
                : "bg-slate-950/50 border-white/5 hover:border-indigo-500/30"
            )}
          >
            {/* Background Glow for popular */}
            {plan.popular && (
              <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-indigo-600/10 to-transparent opacity-50 pointer-events-none" />
            )}
            
            {/* Yearly Glow */}
            {billingCycle === 'yearly' && (
              <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/5 to-transparent pointer-events-none" />
            )}

            {plan.tag && (
              <div className={cn(
                "absolute top-6 right-6 px-3 py-1 rounded-full text-[8px] font-black tracking-widest text-white shadow-lg",
                plan.id === 'profissional' ? "bg-indigo-600 ring-2 ring-indigo-500/50" : "bg-slate-800"
              )}>
                {plan.tag}
              </div>
            )}

            <div className="relative z-10 flex flex-col h-full">
              <div className={cn(
                "w-12 h-12 rounded-2xl flex items-center justify-center mb-6 text-white bg-gradient-to-br transition-transform group-hover:scale-110",
                plan.color
              )}>
                <plan.icon size={24} />
              </div>

              <div className="mb-8">
                <h3 className="text-xl font-bold text-white mb-2">{plan.name}</h3>
                <div className="flex items-baseline gap-1 relative h-12 overflow-hidden">
                  <AnimatePresence mode="wait">
                    <motion.div
                      key={billingCycle}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="flex items-baseline gap-1"
                    >
                      <span className="text-slate-500 text-sm">R$</span>
                      <span className={cn(
                        "text-4xl font-bold transition-colors",
                        billingCycle === 'yearly' ? "text-emerald-400" : "text-white"
                      )}>
                        {billingCycle === 'monthly' ? plan.price : Math.floor(parseInt(plan.priceYearly) / 12)}
                      </span>
                      <span className="text-slate-500 text-sm">/mês*</span>
                    </motion.div>
                  </AnimatePresence>
                </div>
                {billingCycle === 'yearly' && (
                  <motion.p 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-[10px] font-bold text-emerald-500/80 uppercase tracking-widest mt-1"
                  >
                    Pagamento único de R$ {plan.priceYearly}
                  </motion.p>
                )}
                <p className="text-xs text-slate-500 mt-4 leading-relaxed line-clamp-2">{plan.description}</p>
              </div>

              {billingCycle === 'yearly' && plan.saving && (
                <div className="mb-4 px-3 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center gap-2">
                   <div className="w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center text-slate-950">
                      <Check size={12} strokeWidth={4} />
                   </div>
                   <span className="text-[10px] font-black text-emerald-400 uppercase tracking-tighter">Economia de R$ {plan.saving}</span>
                </div>
              )}

              <div className="space-y-4 flex-1 mb-10">
                {plan.features.map((feature, fIdx) => (
                  <div key={fIdx} className="flex items-start gap-3">
                    <div className={cn(
                      "p-0.5 rounded-full mt-1",
                      plan.popular ? "bg-indigo-500/20 text-indigo-400" : "bg-white/5 text-slate-400"
                    )}>
                      <Check size={12} />
                    </div>
                    <span className="text-xs text-slate-300 font-medium">{feature}</span>
                  </div>
                ))}
                
                {billingCycle === 'yearly' && plan.annualBenefits && (
                  <div className="pt-4 space-y-3 border-t border-white/5">
                    <p className="text-[8px] font-black text-emerald-400 uppercase tracking-[0.2em]">Bônus Exclusivos Anuais</p>
                    {plan.annualBenefits.map((benefit, bIdx) => (
                      <div key={bIdx} className="flex items-center gap-3">
                         <Star size={12} className="text-amber-500 fill-amber-500" />
                         <span className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter">{benefit}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <button className={cn(
                "w-full py-4 rounded-2xl text-xs font-black uppercase tracking-widest transition-all",
                plan.popular 
                  ? "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-500 hover:scale-[1.02]" 
                  : "bg-white/5 border border-white/5 text-slate-300 hover:bg-white/10 hover:text-white"
              )}>
                {plan.buttonText}
              </button>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Comparison Table */}
      <div className="mt-20 px-4 space-y-10">
        <div className="text-center space-y-2">
           <h2 className="text-3xl font-bold text-white italic-serif">Comparação Visual Detalhada</h2>
           <p className="text-slate-500 text-sm">Entenda como a tecnologia assistiva evolui em cada nível.</p>
        </div>

        <div className="bg-slate-900/50 border border-white/5 rounded-[3rem] overflow-hidden backdrop-blur-md">
           <table className="w-full text-left border-collapse">
              <thead>
                 <tr className="border-b border-white/5">
                    <th className="p-8 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] w-1/3">Recurso Inteligente</th>
                    {PLANS.map(p => (
                      <th key={p.id} className="p-8 text-[10px] font-black text-white uppercase tracking-[0.2em] text-center">{p.name.split(' ')[1]}</th>
                    ))}
                 </tr>
              </thead>
              <tbody className="text-white">
                 {[
                   { label: 'Mensal', vals: ['R$ 49', 'R$ 99', 'R$ 149', 'R$ 259'] },
                   { label: 'Anual (Preço Único)', vals: ['R$ 529', 'R$ 1.069', 'R$ 1.609', 'R$ 2.797'] },
                   { label: 'Limite de Pacientes', vals: ['20', '100', 'Ilimitado', 'Ilimitado'] },
                   { label: 'IA Clínica Assistiva', vals: ['Básico', 'Avançado', 'Preditivo', 'Black Custom'] },
                   { label: 'Transcrição de Voz', vals: ['Manual', 'IA Gratuita', 'IA Premium', 'IA Estúdio'] },
                   { label: 'Branding Personalizado', vals: ['Não', 'Não', 'Selo Bio', 'White Label'] }
                 ].map((row, rIdx) => (
                   <tr key={rIdx} className="border-b border-white/5 hover:bg-white/[0.02] transition-colors">
                      <td className="p-8 text-sm font-medium text-slate-400">{row.label}</td>
                      {row.vals.map((v, vIdx) => (
                        <td key={vIdx} className="p-8 text-xs font-bold text-center text-slate-300">
                          {v.includes('R$') && billingCycle === 'yearly' && vIdx < row.vals.length ? (
                            <span className={cn(rIdx === 1 ? "text-emerald-400" : "")}>{v}</span>
                          ) : v}
                        </td>
                      ))}
                   </tr>
                 ))}
              </tbody>
           </table>
        </div>
      </div>

      {/* Strategy Quote */}
      <div className="max-w-xl mx-auto text-center py-10 bg-indigo-500/5 border border-indigo-500/10 rounded-[2rem] px-8">
         <p className="text-sm text-slate-400 italic">
           "Profissionais que escolhem o plano anual permanecem mais focados na evolução clínica e economizam significativamente no investimento tecnológico."
         </p>
      </div>

      {/* Payment Methods Footer */}
      <div className="text-center space-y-8 pt-10">
         <div className="inline-flex items-center gap-8 opacity-40 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-700">
            <CreditCard size={32} />
            <Layers size={32} />
            <Smartphone size={32} />
            <ShieldCheck size={32} />
            <Building size={32} />
         </div>
         <p className="text-[10px] text-slate-600 font-bold uppercase tracking-[0.3em]">
           Pagamento Seguro & Recorrência via Stripe / Asaas
         </p>
         <h4 className="text-lg font-bold text-white italic-serif">Invista na evolução da sua clínica com inteligência artificial.</h4>
      </div>
    </div>
  );
}
