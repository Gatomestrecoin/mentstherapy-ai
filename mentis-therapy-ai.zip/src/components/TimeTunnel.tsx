import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  History, 
  ChevronRight, 
  ChevronLeft, 
  RefreshCcw,
  Target,
  Sparkles, 
  Search,
  Activity,
  Brain,
  ShieldAlert,
  Ghost,
  Frown,
  Skull,
  Zap,
  Scale,
  Users,
  Clock,
  CheckCircle2,
  AlertCircle,
  FileText,
  Mic,
  BrainCircuit,
  TrendingUp,
  Heart,
  Lock
} from 'lucide-react';
import { cn } from '../lib/utils';
import { Patient, TimeTunnelData } from '../types';
import InlineRecorder from './InlineRecorder';

const LIFE_PHASES = [
  { id: '0-5', label: '0–5 anos', description: 'Primeira infância e formação básica' },
  { id: '6-10', label: '6–10 anos', description: 'Socialização e fase escolar inicial' },
  { id: '11-15', label: '11–15 anos', description: 'Puberdade e transição adolescente' },
  { id: '16-20', label: '16–20 anos', description: 'Identidade e escolhas juvenis' },
  { id: 'adulta', label: 'Vida Adulta', description: 'Responsabilidades e maturidade' },
  { id: 'relacionamentos', label: 'Relacionamentos', description: 'Vínculos afetivos e amorosos' },
  { id: 'perdas', label: 'Perdas Importantes', description: 'Lutos e ausências marcantes' },
  { id: 'traumas', label: 'Eventos Traumáticos', description: 'Momentos de ruptura emocional' },
];

const TUNNEL_BLOCKS = [
  {
    id: 'rejeicao',
    title: '💔 BLOCO 1 — PRIMEIRA REJEIÇÃO',
    objective: 'Identificar quando o paciente começou a sentir rejeição emocional.',
    icon: Ghost,
    color: 'rose',
    questions: [
      'Qual foi a primeira vez que você se sentiu rejeitado(a)?',
      'Quem causou esse sentimento?',
      'Como você reagiu emocionalmente?',
      'Você lembra da idade aproximada?',
      'O que desejava receber naquele momento?',
      'Sentia que precisava agradar para ser aceito(a)?',
      'Já se sentiu excluído(a) na infância?',
      'Como era tratado(a) pelos colegas?',
      'Recebia comparações negativas?',
      'Você se sentia invisível emocionalmente?',
      'Existia favoritismo dentro da família?',
      'O que essa rejeição fez você acreditar sobre si?',
      'Você ainda sente reflexos disso hoje?',
      'Existe medo de ser rejeitado atualmente?',
      'Como essa experiência mudou seus relacionamentos?'
    ]
  },
  {
    id: 'abandono',
    title: '🚪 BLOCO 2 — ABANDONO',
    objective: 'Mapear perdas emocionais e sensação de abandono.',
    icon: Frown,
    color: 'amber',
    questions: [
      'Você já se sentiu abandonado(a)?',
      'Quem mais te abandonou emocionalmente?',
      'Como isso impactou sua vida?',
      'Existia ausência emocional dos pais?',
      'Você se sentia sozinho(a) frequentemente?',
      'Já perdeu alguém importante?',
      'Tem medo de ficar sozinho(a)?',
      'Costuma criar dependência emocional?',
      'Você sente necessidade constante de atenção?',
      'Como reage quando alguém se afasta?',
      'Já sentiu que não era prioridade?',
      'Você se apega facilmente?',
      'Existe tristeza ligada ao passado?',
      'O abandono ainda dói emocionalmente?',
      'Como isso afeta seus relacionamentos hoje?'
    ]
  },
  {
    id: 'humilhacao',
    title: '😔 BLOCO 3 — HUMILHAÇÃO',
    objective: 'Identificar experiências que afetaram autoestima e identidade.',
    icon: ShieldAlert,
    color: 'orange',
    questions: [
      'Você já foi humilhado(a)?',
      'Quem mais fazia críticas a você?',
      'Já sentiu vergonha de si?',
      'Como era tratado(a) dentro de casa?',
      'Já sofreu bullying?',
      'Alguma frase te marcou negativamente?',
      'Você sentia que nunca era suficiente?',
      'Existiam cobranças excessivas?',
      'Já foi ridicularizado(a)?',
      'Você se sente inferior às pessoas?',
      'Tem medo de errar por julgamento?',
      'Costuma esconder emoções?',
      'Como reage às críticas atualmente?',
      'O que mais machuca sua autoestima?',
      'Qual lembrança mais dolorosa sobre humilhação?'
    ]
  },
  {
    id: 'perdas',
    title: '🕊️ BLOCO 4 — PERDAS',
    objective: 'Investigar lutos emocionais e impactos afetivos.',
    icon: Skull,
    color: 'slate',
    questions: [
      'Qual foi a maior perda da sua vida?',
      'Como você lidou com essa perda?',
      'Já perdeu alguém importante emocionalmente?',
      'Você teve apoio nesse período?',
      'Existe luto não resolvido?',
      'Já perdeu partes de si emocionalmente?',
      'Você evita falar sobre perdas?',
      'Qual perda mais mudou você?',
      'Existe medo de perder pessoas?',
      'Você sente vazio emocional?',
      'Alguma perda gerou revolta?',
      'Existe culpa ligada a alguma perda?',
      'O que nunca conseguiu superar?',
      'Como essa perda afetou sua vida?',
      'O que ainda dói ao lembrar?'
    ]
  },
  {
    id: 'medo',
    title: '😨 BLOCO 5 — MEDO',
    objective: 'Detectar medos conscientes e inconscientes.',
    icon: Zap,
    color: 'indigo',
    questions: [
      'Qual seu maior medo?',
      'Quando esse medo começou?',
      'Você evita situações por medo?',
      'Tem medo de abandono?',
      'Tem medo de fracassar?',
      'Tem medo de julgamento?',
      'Existe medo relacionado à infância?',
      'Seu corpo reage ao medo?',
      'Já teve crises de ansiedade?',
      'Você sente medo constante?',
      'Qual situação mais te paralisa?',
      'Você sente medo de rejeição?',
      'O medo interfere nas suas decisões?',
      'O que faria se não tivesse medo?',
      'Como gostaria de se sentir emocionalmente?'
    ]
  },
  {
    id: 'culpa',
    title: '⚖️ BLOCO 6 — CULPA',
    objective: 'Investigar culpa emocional e autocrítica.',
    icon: Scale,
    color: 'purple',
    questions: [
      'Você se sente culpado(a) frequentemente?',
      'Existe algo que não consegue se perdoar?',
      'Você assume culpa pelos outros?',
      'Já se sentiu responsável pelo sofrimento de alguém?',
      'Como sua família lidava com erros?',
      'Você sente culpa por dizer “não”?',
      'Existe culpa ligada à felicidade?',
      'Você sente que precisa merecer amor?',
      'Tem dificuldade em descansar?',
      'Se cobra excessivamente?',
      'Existe culpa religiosa ou familiar?',
      'Você se pune emocionalmente?',
      'Como reage quando erra?',
      'O que mais pesa emocionalmente hoje?',
      'O que gostaria de perdoar em si?'
    ]
  },
  {
    id: 'comparacao',
    title: '👨👩👧 BLOCO 7 — COMPARAÇÃO FAMILIAR',
    objective: 'Detectar impactos emocionais das comparações familiares.',
    icon: Users,
    color: 'emerald',
    questions: [
      'Você era comparado(a) com irmãos ou parentes?',
      'Como isso fazia você se sentir?',
      'Quem mais fazia comparações?',
      'Você sentia que precisava provar valor?',
      'Já se sentiu inferior na família?',
      'Existia favoritismo?',
      'Como era tratado(a) em relação aos outros?',
      'Você sente necessidade de reconhecimento?',
      'Costuma se comparar hoje?',
      'Existe inveja ou competição emocional?',
      'Como essas comparações afetaram sua autoestima?',
      'Você sente que nunca era suficiente?',
      'Ainda busca aprovação familiar?',
      'Existe mágoa ligada à infância?',
      'O que gostaria que tivessem reconhecido em você?'
    ]
  }
];

interface TimeTunnelProps {
  patients: Patient[];
}

export default function TimeTunnel({ patients }: TimeTunnelProps) {
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentBlockIndex, setCurrentBlockIndex] = useState(0);
  const [currentPhaseId, setCurrentPhaseId] = useState(LIFE_PHASES[0].id);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [tunnelData, setTunnelData] = useState<Partial<TimeTunnelData> | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [recordingTarget, setRecordingTarget] = useState<string | null>(null);

  const startVoiceCapture = (question: string) => {
    setRecordingTarget(question);
    setIsRecording(true);
  };

  const handleVoiceComplete = (analysis: any, transcript: string) => {
    if (recordingTarget) {
      setAnswers(prev => ({ 
        ...prev, 
        [recordingTarget]: prev[recordingTarget] ? `${prev[recordingTarget]}\n\n[Transcrição IA]: ${transcript}` : transcript 
      }));
    }
    setIsRecording(false);
    setRecordingTarget(null);
  };

  const selectedPatient = patients.find(p => p.id === selectedPatientId);
  const currentBlock = TUNNEL_BLOCKS[currentBlockIndex];
  const currentPhase = LIFE_PHASES.find(p => p.id === currentPhaseId);

  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.cpf.includes(searchQuery)
  );

  const handleAnswerChange = (question: string, value: string) => {
    setAnswers(prev => ({ ...prev, [question]: value }));
  };

  const analyzeBlock = async () => {
    if (!selectedPatient) return;
    setIsAnalyzing(true);
    try {
      const blockResponses = currentBlock.questions.map(q => ({
        question: q,
        answer: answers[q] || ''
      }));

      const res = await fetch('/api/gemini/analyze-time-tunnel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          blockTitle: currentBlock.title,
          responses: blockResponses,
          patientContext: `${selectedPatient.name}, ${selectedPatient.age} anos. Queixa: ${selectedPatient.clinicalData.mainComplaint}`
        })
      });
      const analysis = await res.json();
      
      const newBlock = {
        title: currentBlock.title,
        responses: blockResponses,
        analysis
      };

      setTunnelData(prev => ({
        ...prev,
        blocks: [...(prev?.blocks || []), newBlock]
      }));

      if (currentBlockIndex < TUNNEL_BLOCKS.length - 1) {
        setCurrentBlockIndex(prev => prev + 1);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      } else {
        generateFinalReport();
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const generateFinalReport = async () => {
    if (!selectedPatient || !tunnelData?.blocks) return;
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/gemini/generate-time-tunnel-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          allBlocks: tunnelData.blocks,
          patientContext: selectedPatient.clinicalData
        })
      });
      const report = await res.json();
      setTunnelData(prev => ({ ...prev, finalReport: report }));
      setShowReport(true);
    } catch (error) {
      console.error(error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (!selectedPatientId) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto space-y-8"
      >
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-emerald-400 text-[9px] font-bold uppercase tracking-[0.2em] shadow-lg shadow-emerald-500/5">
            <Clock size={12} /> Investigação Transgeracional
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tighter italic-serif">Túnel do Tempo</h1>
          <p className="text-slate-400 max-w-xl mx-auto text-base leading-relaxed italic-serif">
            Mergulho assistido em camadas subconscientes para decodificação de traumas.
          </p>
        </div>

        <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-8 shadow-2xl backdrop-blur-md">
          <div className="relative mb-8">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
            <input 
              type="text"
              placeholder="Localizar consciência..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-white/5 rounded-xl py-4 pl-14 pr-5 outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all font-medium text-slate-200 text-base shadow-inner"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPatients.map(patient => (
              <button
                key={patient.id}
                onClick={() => setSelectedPatientId(patient.id)}
                className="flex items-center gap-4 p-4 rounded-2xl border border-white/5 hover:border-emerald-500/30 hover:bg-white/[0.02] transition-all group text-left shadow-xl"
              >
                <div className="w-12 h-12 bg-slate-950 rounded-xl flex items-center justify-center text-emerald-400 text-lg font-bold border border-white/5 group-hover:border-emerald-500/50 transition-all shadow-inner">
                  {patient.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-white text-base tracking-tight">{patient.name}</h3>
                  <p className="text-[10px] text-slate-500 font-medium uppercase tracking-widest">{patient.age} Ciclos</p>
                </div>
                <ChevronRight size={20} className="ml-auto text-slate-700 group-hover:text-emerald-400 transition-all group-hover:translate-x-1" />
              </button>
            ))}
          </div>
        </div>
      </motion.div>
    );
  }

  if (showReport && tunnelData?.finalReport) {
    return (
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="max-w-6xl mx-auto space-y-10"
      >
        <div className="flex items-center justify-between bg-slate-900/50 p-6 rounded-[2rem] border border-white/5 backdrop-blur-md shadow-2xl">
          <button 
            onClick={() => setShowReport(false)}
            className="flex items-center gap-3 text-[10px] font-bold text-slate-500 hover:text-emerald-400 transition-all uppercase tracking-widest"
          >
            <ChevronLeft size={20} /> Retornar à Incursão
          </button>
          <div className="flex gap-4">
            <button className="flex items-center gap-3 px-6 py-3 bg-white/5 border border-white/5 rounded-2xl text-[10px] font-bold text-slate-300 hover:bg-white/10 hover:text-white transition-all uppercase tracking-widest">
              <FileText size={18} /> Exportar Dossiê Vital
            </button>
            <button className="flex items-center gap-3 px-8 py-3 bg-emerald-500 text-white rounded-2xl text-[10px] font-bold hover:bg-emerald-400 transition-all shadow-xl shadow-emerald-500/20 uppercase tracking-widest active:scale-95">
              <Sparkles size={18} /> Protocolo de Cura IA
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-8 space-y-10">
            <section className="bg-slate-900/50 rounded-[3rem] p-12 border border-white/5 shadow-2xl relative overflow-hidden backdrop-blur-md">
              <div className="absolute -top-10 -right-10 p-8 opacity-5 rotate-12">
                <BrainCircuit size={200} />
              </div>
              <h2 className="text-3xl font-bold text-white mb-10 italic-serif flex items-center gap-4">
                <Activity className="text-emerald-400" /> Bio-Feedback Consolidado
              </h2>
              <p className="text-slate-300 leading-relaxed text-xl italic-serif border-l-[6px] border-emerald-500/30 pl-8 py-4 bg-emerald-500/5 rounded-r-[2rem]">
                {tunnelData.finalReport.emotionalMap}
              </p>
            </section>

            <section className="bg-slate-900/50 rounded-[3rem] p-12 border border-white/5 shadow-2xl backdrop-blur-md">
              <h3 className="text-xl font-bold text-white mb-12 flex items-center gap-4 italic-serif uppercase tracking-widest opacity-80">
                <Clock className="text-indigo-400" /> Estratigrafia da Consciência
              </h3>
              <div className="space-y-16 relative before:absolute before:left-[13px] before:top-2 before:bottom-2 before:w-[2px] before:bg-white/5">
                {tunnelData.finalReport.timeline.map((item, idx) => (
                  <div key={idx} className="relative pl-12">
                    <div className="absolute left-0 top-1.5 w-7 h-7 bg-slate-950 border-[5px] border-indigo-500 rounded-full z-10 shadow-[0_0_15px_rgba(99,102,241,0.5)]" />
                    <div>
                      <h4 className="font-bold text-white text-2xl mb-4 italic-serif">{item.period}</h4>
                      <ul className="grid grid-cols-1 gap-4">
                        {item.events.map((event, eIdx) => (
                          <li key={eIdx} className="text-slate-400 flex items-start gap-4 text-sm leading-relaxed bg-white/[0.02] p-5 rounded-2xl border border-white/5 hover:bg-white/5 transition-all">
                            <span className="w-2 h-2 rounded-full bg-indigo-500/40 mt-2 shrink-0" />
                            {event}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            <section className="bg-slate-900/50 rounded-[3rem] p-12 border border-white/5 shadow-2xl backdrop-blur-md">
              <h3 className="text-xl font-bold text-white mb-10 flex items-center gap-4 italic-serif uppercase tracking-widest opacity-80">
                <Target className="text-emerald-400" /> Vetores de Intervenção
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {tunnelData.finalReport.priorityAreas.map((area, idx) => (
                  <div key={idx} className="p-6 bg-slate-950 rounded-[2rem] border border-white/5 flex items-center gap-5 hover:border-emerald-500/30 transition-all group">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 shadow-xl group-hover:scale-110 transition-transform">
                      <Zap size={20} />
                    </div>
                    <span className="text-xs font-bold text-slate-300 uppercase tracking-widest leading-relaxed">{area}</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <div className="lg:col-span-4 space-y-8">
            <div className="bg-slate-950 rounded-[3rem] p-10 text-white shadow-2xl border border-white/5 sticky top-8">
              <div className="space-y-10">
                <div className="space-y-6">
                  <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] mb-6 flex items-center gap-3 text-emerald-400">
                    <ShieldAlert size={18} /> Núcleos Traumáticos
                  </h3>
                  <ul className="space-y-4">
                    {tunnelData.finalReport.mainTraumas.map((trauma, idx) => (
                      <li key={idx} className="bg-white/5 border border-white/5 p-6 rounded-[1.5rem] text-xs font-medium leading-relaxed text-slate-400 hover:text-white transition-colors">
                        {trauma}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-6">
                  <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] mb-6 flex items-center gap-3 text-rose-500">
                    <Lock size={18} /> DNA de Crenças
                  </h3>
                  <div className="space-y-4">
                    {tunnelData.finalReport.coreBeliefs.map((belief, idx) => (
                      <div key={idx} className="p-5 bg-rose-500/5 border border-rose-500/10 rounded-2xl text-[11px] font-medium text-rose-300 italic-serif italic leading-relaxed">
                        "{belief}"
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] mb-6 flex items-center gap-3 text-indigo-400">
                    <Heart size={18} /> Espectro Emocional
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {tunnelData.finalReport.predominantEmotions.map((emotion, idx) => (
                      <span key={idx} className="px-4 py-2 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-[9px] font-bold text-indigo-400 uppercase tracking-widest">
                        {emotion}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="space-y-6">
                  <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] mb-6 flex items-center gap-3 text-rose-400">
                    <Zap size={18} /> Impulsos Ativos
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {tunnelData.finalReport.triggers.map((trigger, idx) => (
                      <span key={idx} className="px-4 py-2 bg-rose-500/10 border border-rose-500/20 rounded-xl text-[9px] font-bold text-rose-400 uppercase tracking-widest" >
                        {trigger}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="bg-emerald-500/10 rounded-[2rem] border border-emerald-500/20 p-8 shadow-inner shadow-emerald-500/5">
                  <h3 className="text-[10px] font-bold uppercase tracking-[0.3em] mb-5 flex items-center gap-3 text-emerald-400">
                    <TrendingUp size={18} /> Síntese Meta-Psicológica
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed font-medium italic-serif">
                    {tunnelData.finalReport.summary}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Sidebar: Phases & Blocks Progress */}
      <div className="lg:col-span-3 space-y-6">
        <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-6 shadow-2xl backdrop-blur-md sticky top-8">
          <div className="flex items-center gap-4 mb-8">
            <div className="w-12 h-12 bg-slate-950 rounded-xl flex items-center justify-center text-emerald-400 text-xl font-bold border border-white/5 shadow-inner">
              {selectedPatient.name.charAt(0)}
            </div>
            <div>
              <h3 className="text-base font-bold text-white tracking-tight italic-serif">{selectedPatient.name}</h3>
              <button 
                onClick={() => setSelectedPatientId('')}
                className="text-[8px] font-bold text-slate-500 uppercase tracking-[0.2em] hover:text-emerald-400 transition-all mt-0.5"
              >
                Alternar
              </button>
            </div>
          </div>

          <div className="space-y-8">
            <div>
              <h4 className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.3em] mb-4 flex items-center gap-2.5 px-1">
                <Clock size={14} /> Estratos
              </h4>
              <div className="grid grid-cols-1 gap-2">
                {LIFE_PHASES.map((phase) => (
                  <button
                    key={phase.id}
                    onClick={() => setCurrentPhaseId(phase.id)}
                    className={cn(
                      "flex flex-col p-3.5 rounded-xl border text-left transition-all group",
                      currentPhaseId === phase.id
                        ? "bg-emerald-500 border-emerald-400 text-white shadow-xl shadow-emerald-500/20"
                        : "bg-slate-950 border-white/5 hover:bg-white/5 text-slate-500"
                    )}
                  >
                    <span className="text-[9px] font-bold uppercase tracking-[0.2em]">{phase.label}</span>
                    <span className={cn(
                      "text-[8px] mt-0.5 opacity-60 font-medium",
                      currentPhaseId === phase.id ? "text-emerald-100" : "text-slate-600 group-hover:text-slate-400"
                    )}>{phase.description}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-4 px-1">
                <h4 className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.3em] flex items-center gap-2.5">
                  <ShieldAlert size={14} /> Fluxo
                </h4>
                <span className="text-[10px] font-mono font-bold text-emerald-400">{currentBlockIndex + 1}/{TUNNEL_BLOCKS.length}</span>
              </div>
              <div className="h-1 bg-white/5 rounded-full overflow-hidden mb-6 shadow-inner">
                <div 
                  className="h-full bg-emerald-500 transition-all duration-700 ease-out shadow-[0_0_10px_rgba(16,185,129,0.5)]" 
                  style={{ width: `${((currentBlockIndex + 1) / TUNNEL_BLOCKS.length) * 100}%` }}
                />
              </div>
              <div className="space-y-2">
                {TUNNEL_BLOCKS.map((block, idx) => (
                  <div 
                    key={block.id}
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-xl text-[8px] font-bold uppercase tracking-[0.2em] transition-all",
                      idx === currentBlockIndex 
                        ? "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 shadow-lg"
                        : idx < currentBlockIndex 
                          ? "text-emerald-500 opacity-80"
                          : "text-slate-600 opacity-40"
                    )}
                  >
                    {idx < currentBlockIndex ? <CheckCircle2 size={12} /> : <div className="w-1.5 h-1.5 rounded-full bg-current opacity-40 shadow-[0_0_5px_currentColor]" />}
                    {block.id}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content: Questions & AI Interaction */}
      <div className="lg:col-span-9 flex flex-col gap-8">
        <motion.div
          key={currentBlock.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="bg-slate-900/50 rounded-[2.5rem] border border-white/5 shadow-2xl overflow-hidden backdrop-blur-md"
        >
          <div className={cn(
            "p-8 border-b border-white/5 flex items-center justify-between relative overflow-hidden",
            `bg-${currentBlock.color}-500/5`
          )}>
            <div className="absolute top-0 right-0 p-6 opacity-5 scale-125 rotate-12">
              <currentBlock.icon size={100} />
            </div>
            <div className="flex items-center gap-6 relative z-10">
              <div className={cn(
                "w-16 h-16 rounded-2xl text-white shadow-2xl flex items-center justify-center border border-white/10",
                `bg-${currentBlock.color}-500 shadow-${currentBlock.color}-500/20`
              )}>
                <currentBlock.icon size={32} />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white italic-serif tracking-tight">{currentBlock.title}</h2>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em] mt-0.5">{currentBlock.objective}</p>
              </div>
            </div>
            <div className="flex flex-col items-end relative z-10">
              <div className="flex items-center gap-2.5 text-emerald-400 bg-emerald-500/10 px-4 py-2 rounded-full border border-emerald-500/20 shadow-lg">
                <Brain size={16} className="animate-pulse" />
                <span className="text-[8px] font-bold uppercase tracking-[0.2em]">Varredura Ativa</span>
              </div>
              <span className="text-[9px] font-bold text-slate-500 mt-2 uppercase tracking-widest">{currentPhase?.label}</span>
            </div>
          </div>

          <div className="p-8 space-y-10">
            {currentBlock.questions.map((q, i) => (
              <div key={i} className="group relative">
                <div className="flex gap-6">
                  <div className="w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center text-[10px] font-bold text-slate-500 group-hover:bg-indigo-500/20 group-hover:text-indigo-400 transition-all shrink-0 mt-1 border border-white/5 shadow-inner">
                    {i + 1}
                  </div>
                  <div className="flex-1 space-y-4">
                    <p className="text-lg font-bold text-slate-200 leading-relaxed italic-serif group-hover:text-white transition-colors">
                      {q}
                    </p>
                    <div className="relative group/field">
                      <textarea 
                        value={answers[q] || ''}
                        onChange={(e) => handleAnswerChange(q, e.target.value)}
                        placeholder="Responder..."
                        className="w-full bg-slate-950 border border-white/5 rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all text-slate-300 min-h-[100px] resize-none text-base italic-serif shadow-inner placeholder:text-slate-700"
                      />
                      <button 
                        onClick={() => startVoiceCapture(q)}
                        className="absolute bottom-4 right-4 w-10 h-10 bg-white/5 border border-white/10 rounded-xl text-slate-500 hover:text-indigo-400 hover:border-indigo-500/30 transition-all shadow-xl backdrop-blur-md flex items-center justify-center hover:scale-110 active:scale-95"
                      >
                        <Mic size={18} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-8 bg-slate-950/50 border-t border-white/5 flex items-center justify-between">
            <button
              onClick={() => setCurrentBlockIndex(prev => Math.max(0, prev - 1))}
              disabled={currentBlockIndex === 0}
              className="flex items-center gap-2 px-6 py-3 bg-white/5 border border-white/5 rounded-xl text-[10px] font-bold text-slate-500 hover:text-white hover:bg-white/10 transition-all disabled:opacity-20 uppercase tracking-widest"
            >
              <ChevronLeft size={16} /> Anterior
            </button>
            <button
              onClick={analyzeBlock}
              disabled={isAnalyzing}
              className="flex items-center gap-3 px-10 py-4 bg-emerald-500 text-white rounded-xl text-[10px] font-bold transition-all shadow-2xl shadow-emerald-500/20 hover:bg-emerald-400 disabled:opacity-50 uppercase tracking-[0.2em] active:scale-95"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCcw className="animate-spin" size={16} /> Analisando...
                </>
              ) : (
                <>
                  {currentBlockIndex === TUNNEL_BLOCKS.length - 1 ? "Finalizar" : "Avançar"} <ChevronRight size={16} />
                </>
              )}
            </button>
          </div>
        </motion.div>

        {tunnelData?.blocks?.some(b => b.title === currentBlock.title) && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-12 bg-gradient-to-br from-indigo-900 to-indigo-950 rounded-[3rem] text-white shadow-2xl border border-white/10 relative overflow-hidden"
          >
            <div className="absolute -top-10 -right-10 p-8 opacity-5 rotate-12">
              <Sparkles size={250} />
            </div>
            <div className="flex items-center justify-between mb-12 relative z-10">
              <h3 className="text-2xl font-bold flex items-center gap-4 italic-serif">
                <Sparkles className="text-emerald-400" /> Diagnóstico Transiente IA
              </h3>
              <div className="px-5 py-2 bg-white/10 rounded-full text-[10px] font-bold uppercase tracking-[0.2em] text-emerald-400 border border-white/10 backdrop-blur-md">
                Processamento Quântico Ativo
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 relative z-10">
              <div className="space-y-8">
                <div className="space-y-5">
                  <h4 className="text-[10px] font-bold uppercase text-indigo-300 tracking-[0.3em] flex items-center gap-3">
                    <ShieldAlert size={18} className="text-rose-400" /> Pontos de Ruptura Detectados
                  </h4>
                  <ul className="space-y-3">
                    {tunnelData.blocks.find(b => b.title === currentBlock.title)?.analysis?.traumas.map((t, i) => (
                      <li key={i} className="text-sm text-indigo-100 flex items-start gap-4 bg-white/5 p-4 rounded-2xl border border-white/5 italic-serif">
                        <span className="w-2 h-2 rounded-full bg-rose-500 mt-2 shrink-0 shadow-[0_0_8px_rgba(244,63,94,0.6)]" />
                        {t}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="space-y-5">
                  <h4 className="text-[10px] font-bold uppercase text-indigo-300 tracking-[0.3em] flex items-center gap-3">
                    <Lock size={18} className="text-emerald-400" /> Algoritmos de Crença Gerados
                  </h4>
                  <ul className="space-y-3">
                    {tunnelData.blocks.find(b => b.title === currentBlock.title)?.analysis?.beliefs.map((b, i) => (
                      <li key={i} className="text-sm text-indigo-100 flex items-start gap-4 bg-white/5 p-4 rounded-2xl border border-white/5 italic-serif">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 mt-2 shrink-0 shadow-[0_0_8px_rgba(16,185,129,0.6)]" />
                        {b}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="space-y-8">
                <div className="space-y-5">
                  <h4 className="text-[10px] font-bold uppercase text-indigo-300 tracking-[0.3em] flex items-center gap-3">
                    <Activity size={18} className="text-amber-400" /> Ciclos Iterativos Repetitivos
                  </h4>
                  <ul className="space-y-3">
                    {tunnelData.blocks.find(b => b.title === currentBlock.title)?.analysis?.patterns.map((p, i) => (
                      <li key={i} className="text-sm text-indigo-100 flex items-start gap-4 bg-white/5 p-4 rounded-2xl border border-white/5 italic-serif">
                        <span className="w-2 h-2 rounded-full bg-amber-500 mt-2 shrink-0 shadow-[0_0_8px_rgba(245,158,11,0.6)]" />
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="space-y-5">
                  <h4 className="text-[10px] font-bold uppercase text-indigo-300 tracking-[0.3em] flex items-center gap-3">
                    <Ghost size={18} className="text-rose-300" /> Léxico de Trauma (Gatilhos)
                  </h4>
                  <div className="flex flex-wrap gap-3">
                    {tunnelData.blocks.find(b => b.title === currentBlock.title)?.analysis?.traumaticWords.map((word, i) => (
                      <span key={i} className="px-4 py-2 bg-rose-500/10 rounded-xl text-[10px] font-bold text-rose-300 border border-rose-500/20 uppercase tracking-widest">
                        {word}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>

      {isRecording && (
        <InlineRecorder 
          patientId={selectedPatientId}
          focus={currentBlock.title}
          sessionId={currentBlockIndex}
          onClose={() => setIsRecording(false)}
          onComplete={handleVoiceComplete}
        />
      )}
    </div>
  );
}
