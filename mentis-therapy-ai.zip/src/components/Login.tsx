import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Mail, Lock, LogIn, Github, ArrowRight, Fingerprint, Eye, EyeOff } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import AuthLayout from './AuthLayout';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const { login, isLoading } = useAuth();
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Por favor, preencha todos os campos.');
      return;
    }
    try {
      await login(email, password);
    } catch (err) {
      setError('Falha na autenticação. Verifique suas credenciais.');
    }
  };

  return (
    <AuthLayout 
      title="A plataforma terapêutica mais inteligente para profissionais da saúde emocional."
      subtitle="Transforme sua prática clínica com tecnologia assistiva de ponta e insights emocionais profundos."
    >
      <div className="space-y-8">
        <div>
          <h2 className="text-2xl font-bold text-white italic-serif mb-2">Entrar</h2>
          <p className="text-sm text-slate-500 font-medium tracking-tight">Utilize suas credenciais profissionais para acesso seguro.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {error && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-xs font-bold text-rose-500 text-center"
            >
              {error}
            </motion.div>
          )}

          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest ml-1">E-mail Profissional</label>
            <div className="relative group">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-400 transition-colors" size={18} />
              <input 
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="nome@clinica.com"
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-12 pr-4 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 transition-all outline-none"
              />
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between items-center px-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Senha de Acesso</label>
              <Link to="/forgot-password" size={10} className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest hover:text-indigo-300 transition-colors">Esqueceu a senha?</Link>
            </div>
            <div className="relative group">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-400 transition-colors" size={18} />
              <input 
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-white/5 border border-white/5 rounded-2xl py-4 pl-12 pr-12 text-sm text-white focus:bg-white/10 focus:border-indigo-500/50 transition-all outline-none"
              />
              <button 
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-600 hover:text-slate-400"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>

          <button 
            type="submit"
            disabled={isLoading}
            className="w-full bg-indigo-500 text-white rounded-2xl py-4 font-bold text-sm flex items-center justify-center gap-2 hover:bg-indigo-600 transition-all shadow-xl shadow-indigo-500/20 active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                Entrar na Plataforma
                <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        <div className="relative py-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-white/5"></div>
          </div>
          <div className="relative flex justify-center text-[10px] font-bold uppercase tracking-widest">
            <span className="bg-[#0f1118] px-4 text-slate-600">Ou continue com</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <button className="flex items-center justify-center gap-3 bg-white/5 border border-white/5 rounded-2xl py-4 hover:bg-white/10 transition-all group">
            <svg className="w-5 h-5 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
              <path fill="#EA4335" d="M12 5.04c1.94 0 3.51.68 4.75 1.83l3.48-3.48C18.1 1.44 15.3 0 12 0 7.31 0 3.25 2.67 1.25 6.55l4.02 3.12C6.23 6.94 8.87 5.04 12 5.04z"/>
              <path fill="#4285F4" d="M23.49 12.27c0-.85-.07-1.48-.22-2.13H12v4.03h6.5c-.28 1.48-1.12 2.74-2.38 3.59l3.71 2.88c2.16-1.99 3.42-4.93 3.42-8.37z"/>
              <path fill="#FBBC05" d="M5.27 14.53c-.25-.74-.39-1.54-.39-2.38 0-.84.14-1.64.39-2.38L1.25 6.55C.45 8.19 0 10.03 0 12c0 1.97.45 3.81 1.25 5.45l4.02-2.92z"/>
              <path fill="#34A853" d="M12 24c3.24 0 5.95-1.07 7.94-2.91l-3.71-2.88c-1.1.74-2.51 1.18-4.23 1.18-3.21 0-5.94-2.17-6.91-5.11L1.24 17.55C3.24 21.33 7.31 24 12 24z"/>
            </svg>
            <span className="text-xs font-bold text-white uppercase tracking-widest">Google</span>
          </button>
          <button className="flex items-center justify-center gap-3 bg-white/5 border border-white/5 rounded-2xl py-4 hover:bg-white/10 transition-all group">
            <Fingerprint className="text-slate-400 group-hover:text-indigo-400 transition-colors group-hover:scale-110 transition-transform" size={20} />
            <span className="text-xs font-bold text-white uppercase tracking-widest">Biometria</span>
          </button>
        </div>

        <p className="text-center text-sm text-slate-500 font-medium">
          Ainda não é um parceiro? {' '}
          <Link to="/register" className="text-indigo-400 font-bold hover:text-indigo-300 transition-colors">Solicitar Registro</Link>
        </p>
      </div>
    </AuthLayout>
  );
}
