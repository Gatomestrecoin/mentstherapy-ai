import React from 'react';
import { motion } from 'motion/react';
import { Brain, ShieldCheck } from 'lucide-react';

export default function AuthLayout({ children, title, subtitle }: { children: React.ReactNode, title: string, subtitle: string }) {
  return (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4 relative overflow-hidden font-sans">
      {/* Immersive Background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] rounded-full bg-indigo-500/10 blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] rounded-full bg-lilac-500/10 blur-[120px]" />
        <div className="absolute top-[20%] right-[10%] w-[20%] h-[20%] rounded-full bg-emerald-500/5 blur-[100px]" />
        
        {/* Particle-like dots */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0.1, scale: 0.5 }}
            animate={{ 
              opacity: [0.1, 0.3, 0.1],
              scale: [0.5, 1, 0.5],
              y: [0, -40, 0],
              x: [0, (i % 2 === 0 ? 20 : -20), 0]
            }}
            transition={{ 
              duration: 5 + (i % 5), 
              repeat: Infinity, 
              ease: "linear",
              delay: i * 0.2
            }}
            className="absolute w-1 h-1 bg-indigo-400/20 rounded-full"
            style={{ 
              top: `${Math.random() * 100}%`, 
              left: `${Math.random() * 100}%` 
            }}
          />
        ))}
      </div>

      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 gap-0 relative z-10 bg-slate-950/40 backdrop-blur-3xl rounded-[2.5rem] border border-white/5 overflow-hidden shadow-2xl shadow-black/50">
        
        {/* Left Side - Visual & Branding */}
        <div className="hidden lg:flex flex-col justify-between p-12 bg-gradient-to-br from-slate-900/50 to-indigo-950/30 border-r border-white/5">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 bg-indigo-500 rounded-2xl flex items-center justify-center text-white shadow-xl shadow-indigo-500/30">
                <Brain size={28} />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight italic-serif">MindTherapy AI</span>
            </div>
            
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl font-light text-white leading-tight mb-6 italic-serif"
            >
              {title}
            </motion.h1>
            <p className="text-slate-400 text-lg leading-relaxed font-light">
              {subtitle}
            </p>
          </div>

          <div className="space-y-6">
            <div className="flex items-center gap-4 p-4 bg-white/5 rounded-2xl border border-white/5">
              <div className="w-10 h-10 bg-white/5 rounded-xl flex items-center justify-center text-indigo-400">
                <ShieldCheck size={20} />
              </div>
              <div>
                <p className="text-xs font-bold text-white uppercase tracking-widest text-[9px]">Ambiente Seguro</p>
                <p className="text-xs text-slate-500">Criptografia Ponta-a-Ponta & LGPD</p>
              </div>
            </div>
            
            <p className="text-[10px] text-slate-600 font-bold uppercase tracking-[0.2em]">
              © 2026 Plataforma Terapêutica Inteligente
            </p>
          </div>
        </div>

        {/* Right Side - Form */}
        <div className="p-8 md:p-12 lg:p-16 flex flex-col justify-center">
          <div className="lg:hidden flex items-center gap-3 mb-12">
            <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white">
              <Brain size={24} />
            </div>
            <span className="text-xl font-bold text-white italic-serif">MindTherapy AI</span>
          </div>
          
          {children}
        </div>
      </div>
    </div>
  );
}
