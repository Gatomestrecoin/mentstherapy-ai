import React from 'react';
import { motion } from 'motion/react';
import { 
  FileText, 
  Download, 
  ChevronRight, 
  Clock, 
  User, 
  TrendingUp,
  Brain,
  Share2,
  Sparkles
} from 'lucide-react';
import { Patient, Session } from '../types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function Reports({ sessions, patients }: { sessions: Session[], patients: Patient[] }) {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-7xl mx-auto space-y-8"
    >
      <div className="space-y-2">
        <h1 className="text-2xl font-bold text-white tracking-tighter italic-serif">Relatórios Inteligentes</h1>
        <p className="text-slate-400 text-base italic-serif leading-relaxed">Documentação clínica e evolução gerada por IA.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-8 space-y-6 shadow-2xl backdrop-blur-md">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white italic-serif">Pendentes</h2>
            <span className="bg-amber-500/10 text-amber-400 text-[9px] font-bold px-3 py-1.5 rounded-full border border-amber-500/20 uppercase tracking-widest">3 Aguardando</span>
          </div>
          
          <div className="space-y-3">
            {[
              { patient: 'Ana Beatriz', type: 'Relatório Mensal', due: 'Hoje' },
              { patient: 'Carlos Eduardo', type: 'Encaminhamento', due: 'Amanhã' },
              { patient: 'Mariana Costa', type: 'Análise Progresso', due: '2 dias' },
            ].map((report, i) => (
              <div key={i} className="flex items-center gap-4 p-4 rounded-xl hover:bg-white/[0.02] transition-all border border-white/5 group shadow-lg">
                <div className="w-10 h-10 bg-indigo-500/10 rounded-lg flex items-center justify-center text-indigo-400 border border-indigo-500/20 group-hover:bg-indigo-500 group-hover:text-white transition-all transform group-hover:scale-105">
                  <FileText size={18} />
                </div>
                <div className="flex-1">
                  <p className="font-bold text-slate-200 group-hover:text-white transition-colors uppercase tracking-widest text-[9px] leading-relaxed">{report.type}</p>
                  <p className="text-[8px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">{report.patient} • {report.due}</p>
                </div>
                <button className="bg-indigo-600 text-white p-2 rounded-lg hover:bg-indigo-500 transition-all shadow-lg active:scale-95">
                  <ChevronRight size={16} />
                </button>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-8 flex flex-col justify-center items-center text-center space-y-6 shadow-2xl backdrop-blur-md relative overflow-hidden">
          <div className="absolute -top-10 -right-10 opacity-5 rotate-12">
            <Brain size={180} />
          </div>
          <div className="w-16 h-16 bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-400 shadow-2xl border border-indigo-500/20 relative z-10">
            <Brain size={32} />
          </div>
          <div className="relative z-10 space-y-2">
            <h3 className="text-2xl font-bold text-white italic-serif">Consolidador IA</h3>
            <p className="text-slate-400 max-w-sm mx-auto leading-relaxed text-sm italic-serif">Consolidação automática da evolução clínica.</p>
          </div>
          <button className="bg-indigo-600 text-white px-8 py-3.5 rounded-xl font-bold flex items-center gap-3 hover:bg-indigo-500 transition-all shadow-2xl shadow-indigo-600/20 active:scale-95 uppercase tracking-[0.2em] text-[9px] relative z-10">
            <Sparkles size={16} className="text-emerald-300" /> Iniciar Síntese
          </button>
        </div>
      </div>

      <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 overflow-hidden shadow-2xl backdrop-blur-md">
        <div className="p-8 border-b border-white/5 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white italic-serif">Arquivo Geral</h2>
          <div className="flex gap-3">
            <button className="p-3 bg-white/5 border border-white/10 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-all shadow-lg"><TrendingUp size={18} /></button>
            <button className="p-3 bg-white/5 border border-white/10 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-all shadow-lg"><Share2 size={18} /></button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-950/50 text-slate-500 text-[9px] font-bold uppercase tracking-[0.3em] border-b border-white/5">
              <tr>
                <th className="px-8 py-4">Arquivo</th>
                <th className="px-8 py-4">Paciente</th>
                <th className="px-8 py-4">Data</th>
                <th className="px-8 py-4 text-right">Ação</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.02]">
              {sessions.length > 0 ? sessions.map((s, i) => (
                <tr key={i} className="hover:bg-white/[0.01] transition-colors group">
                  <td className="px-8 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-indigo-500/10 rounded-lg flex items-center justify-center text-indigo-400 border border-indigo-500/20">
                        <FileText size={14} />
                      </div>
                      <span className="font-bold text-slate-200 text-xs italic-serif group-hover:text-white transition-colors tracking-tight">Sessao_{s.id.slice(0,4)}.pdf</span>
                    </div>
                  </td>
                  <td className="px-8 py-4">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-slate-400 group-hover:text-slate-200 transition-colors">
                      {patients.find(p => p.id === s.patientId)?.name || 'Paciente'}
                    </span>
                  </td>
                  <td className="px-8 py-4">
                    <div className="flex items-center gap-2 text-slate-500 group-hover:text-slate-300 transition-colors">
                      <Clock size={12} className="text-indigo-400" />
                      <span className="text-[10px] font-mono font-medium">{format(new Date(s.date), "dd/MM/yyyy")}</span>
                    </div>
                  </td>
                  <td className="px-8 py-4 text-right">
                    <button className="p-2 text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-all border border-emerald-500/0 hover:border-emerald-500/20 active:scale-95 shadow-lg">
                      <Download size={18} />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={4} className="px-8 py-12 text-center">
                    <div className="flex flex-col items-center gap-3">
                      <div className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center text-slate-700">
                        <FileText size={24} />
                      </div>
                      <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-600">Nenhum rastro encontrado.</span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
