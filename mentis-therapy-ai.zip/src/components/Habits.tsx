import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle2, 
  Heart, 
  Zap, 
  Users, 
  Brain, 
  Target,
  Flame,
  ChevronRight,
  TrendingUp,
  Sparkles,
  Trophy,
  Calendar,
  Search,
  ChevronLeft,
  Briefcase,
  Star,
  Award,
  BarChart3,
  Lightbulb,
  ShieldCheck,
  Dna,
  TreeDeciduous,
  CircleDashed,
  RefreshCcw
} from 'lucide-react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  ResponsiveContainer 
} from 'recharts';
import { cn } from '../lib/utils';
import { Patient, Habit, AIPersonalizedHabits } from '../types';
import { HABIT_CATEGORIES, SUGGESTED_HABITS } from '../constants/habitConstants';

interface HabitsProps {
  patients: Patient[];
}

export default function Habits({ patients }: HabitsProps) {
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState(HABIT_CATEGORIES[0].id);
  const [completedHabits, setCompletedHabits] = useState<Record<string, string[]>>({}); // patientId -> habitTitles[]
  const [aiHabits, setAiHabits] = useState<AIPersonalizedHabits | null>(null);
  const [isGeneratingAI, setIsGeneratingAI] = useState(false);

  const selectedPatient = patients.find(p => p.id === selectedPatientId);

  const generateAIHabits = async () => {
    if (!selectedPatient) return;
    setIsGeneratingAI(true);
    try {
      const response = await fetch('/api/gemini/personalize-habits', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientContext: selectedPatient.clinicalData.mainComplaint,
          currentMood: 'Neutro', // Could be dynamic
          recentStressLevel: 'Médio' // Could be dynamic
        })
      });
      const data = await response.json();
      setAiHabits(data);
    } catch (error) {
      console.error('Error generating AI habits:', error);
    } finally {
      setIsGeneratingAI(false);
    }
  };
  const filteredPatients = patients.filter(p => 
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.cpf.includes(searchQuery)
  );

  const radarData = useMemo(() => {
    if (!selectedPatientId) return [];
    return HABIT_CATEGORIES.map(cat => ({
      subject: cat.label,
      value: Math.floor(Math.random() * 60) + 40, // Mocked data for now
      fullMark: 100,
    }));
  }, [selectedPatientId]);

  const toggleHabit = (habitTitle: string) => {
    if (!selectedPatientId) return;
    setCompletedHabits(prev => {
      const patientHabits = prev[selectedPatientId] || [];
      if (patientHabits.includes(habitTitle)) {
        return { ...prev, [selectedPatientId]: patientHabits.filter(h => h !== habitTitle) };
      }
      return { ...prev, [selectedPatientId]: [...patientHabits, habitTitle] };
    });
  };

  const isHabitCompleted = (habitTitle: string) => {
    return completedHabits[selectedPatientId]?.includes(habitTitle);
  };

  if (!selectedPatientId) {
    return (
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-4xl mx-auto space-y-8"
      >
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-amber-500/10 border border-amber-500/20 rounded-full text-amber-400 text-[10px] font-bold uppercase tracking-[0.2em] shadow-lg shadow-amber-500/5">
            <Trophy size={12} /> 365 Hábitos Poderosos
          </div>
          <h1 className="text-3xl font-bold text-white tracking-tighter italic-serif">Arquitetura de Hábitos</h1>
          <p className="text-slate-400 max-w-2xl mx-auto text-base leading-relaxed italic-serif">
            Transforme a vida dos seus pacientes através de micro-ações diárias baseadas em inteligência emocional e neurociência.
          </p>
        </div>

        <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-8 shadow-2xl backdrop-blur-md">
          <div className="relative mb-8">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
            <input 
              type="text"
              placeholder="Localizar consciência..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-white/5 rounded-xl py-4 pl-14 pr-4 outline-none focus:ring-2 focus:ring-amber-500/50 transition-all font-medium text-slate-200 text-base shadow-inner"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredPatients.map(patient => (
              <button
                key={patient.id}
                onClick={() => setSelectedPatientId(patient.id)}
                className="flex items-center gap-4 p-4 rounded-2xl border border-white/5 hover:border-amber-500/30 hover:bg-white/[0.02] transition-all group text-left shadow-xl"
              >
                <div className="w-12 h-12 bg-slate-950 rounded-xl flex items-center justify-center text-amber-400 text-lg font-bold border border-white/5 group-hover:border-amber-500/50 transition-all shadow-inner">
                  {patient.name.charAt(0)}
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm tracking-tight">{patient.name}</h3>
                  <p className="text-[10px] text-slate-500 font-medium uppercase tracking-widest">{patient.clinicalData.mainComplaint}</p>
                </div>
                <ChevronRight size={18} className="ml-auto text-slate-700 group-hover:text-amber-400 transition-all group-hover:translate-x-1" />
              </button>
            ))}
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-7xl mx-auto space-y-6 pb-20"
    >
      {/* Header with Patient Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-slate-900/50 p-6 rounded-[2rem] border border-white/5 backdrop-blur-md shadow-2xl">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => setSelectedPatientId('')}
            className="w-10 h-10 flex items-center justify-center hover:bg-white/5 rounded-xl transition-all text-slate-500 hover:text-amber-400 border border-white/5"
          >
            <ChevronLeft size={20} />
          </button>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-slate-950 rounded-xl flex items-center justify-center text-amber-400 text-xl font-bold border border-white/5 shadow-inner">
              {selectedPatient.name.charAt(0)}
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white tracking-tight italic-serif">{selectedPatient.name}</h1>
              <div className="flex items-center gap-3 mt-1">
                <span className="text-[9px] font-bold text-amber-400 uppercase tracking-widest px-2 py-0.5 bg-amber-500/10 border border-amber-500/20 rounded-md">Mentalidade {selectedPatient.clinicalData.mainComplaint}</span>
                <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-1">
                  <Calendar size={12} /> Streak: 12 dias
                </span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex gap-3">
          <div className="bg-slate-950 border border-white/5 px-4 py-2 rounded-xl flex items-center gap-3 shadow-inner">
            <div className="text-right">
              <p className="text-[8px] font-bold text-slate-600 uppercase tracking-[0.2em]">Nível Evolutivo</p>
              <p className="text-xs font-bold text-slate-200 italic-serif">Mestre da Emoção</p>
            </div>
            <div className="w-8 h-8 bg-amber-500 text-white rounded-lg flex items-center justify-center shadow-lg shadow-amber-500/20">
              <Award size={18} />
            </div>
          </div>
          <div className="bg-indigo-600 px-4 py-2 rounded-xl flex items-center gap-3 shadow-xl">
            <div className="text-right text-white">
              <p className="text-[8px] font-bold text-indigo-200 uppercase tracking-[0.2em]">Potencial Ativo</p>
              <p className="text-xs font-bold">1.240 Pontos</p>
            </div>
            <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center text-white backdrop-blur-sm">
              <TrendingUp size={18} />
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Charts and AI */}
        <div className="lg:col-span-4 space-y-6">
          {/* Life Balance Radar */}
          <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-8 shadow-2xl backdrop-blur-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.3em] flex items-center gap-2">
                <BarChart3 size={16} className="text-indigo-400" /> Fluxo de Equilíbrio
              </h3>
              <Sparkles size={16} className="text-amber-400" />
            </div>
            <div className="h-60 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart cx="50%" cy="50%" outerRadius="80%" data={radarData}>
                  <PolarGrid stroke="#ffffff10" />
                  <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 8, fontWeight: 700 }} />
                  <Radar
                    name={selectedPatient.name}
                    dataKey="value"
                    stroke="#6366f1"
                    fill="#6366f1"
                    fillOpacity={0.2}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Evolution Tree */}
          <div className="bg-emerald-500/10 rounded-[2rem] border border-emerald-500/20 p-8 shadow-2xl relative overflow-hidden backdrop-blur-md">
            <div className="absolute -top-6 -right-6 p-4 opacity-5 rotate-12 scale-125">
              <TreeDeciduous size={100} />
            </div>
            <h3 className="text-[9px] font-bold uppercase tracking-[0.3em] mb-6 flex items-center gap-2 text-emerald-400">
              <Dna size={16} /> Arquitetura Evolutiva
            </h3>
            <div className="space-y-6 relative z-10">
              <div className="flex items-center gap-4">
                <div className="w-1.5 h-12 bg-white/5 rounded-full relative overflow-hidden">
                  <div className="absolute bottom-0 w-full bg-emerald-500 rounded-full" style={{ height: '70%' }}></div>
                </div>
                <div>
                  <p className="text-[8px] font-bold text-emerald-400/60 uppercase tracking-[0.2em]">Status de Expansão</p>
                  <p className="text-xl font-bold text-white italic-serif text-slate-200">Consolidação Psíquica</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-950/50 border border-white/5 p-3 rounded-xl">
                  <p className="text-[8px] text-emerald-500 font-bold uppercase tracking-widest mb-1">Fundação</p>
                  <p className="text-xs font-bold text-slate-200">Enraizado</p>
                </div>
                <div className="bg-slate-950/50 border border-white/5 p-3 rounded-xl">
                  <p className="text-[8px] text-emerald-500 font-bold uppercase tracking-widest mb-1">Fruição</p>
                  <p className="text-xs font-bold text-slate-200">Ativo</p>
                </div>
              </div>
            </div>
          </div>

          {/* AI Suggestion */}
          <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-8 shadow-2xl backdrop-blur-md">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-[9px] font-bold text-slate-400 uppercase tracking-[0.3em] flex items-center gap-2">
                <Lightbulb size={16} className="text-amber-400" /> Bio-Feedback IA
              </h3>
              <button 
                onClick={generateAIHabits}
                disabled={isGeneratingAI}
                className="p-2 hover:bg-white/5 rounded-xl transition-all text-amber-400 disabled:opacity-50 border border-white/5"
              >
                <Sparkles size={16} className={cn(isGeneratingAI && "animate-spin")} />
              </button>
            </div>
            
            <AnimatePresence mode="wait">
              {aiHabits ? (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  key="ai-v0"
                  className="space-y-6"
                >
                  <div className="bg-amber-500/5 border border-amber-500/10 p-6 rounded-[1.5rem] relative overflow-hidden">
                    <p className="text-base text-amber-200 font-medium leading-relaxed italic-serif mb-4">
                      "{aiHabits.motivationalQuote}"
                    </p>
                    
                    {aiHabits.identifiedPatterns && aiHabits.identifiedPatterns.length > 0 && (
                      <div className="mb-4 flex flex-wrap gap-1.5">
                        {aiHabits.identifiedPatterns.map((pattern, i) => (
                          <span key={i} className="px-2 py-0.5 bg-red-500/10 border border-red-500/20 rounded-full text-[8px] font-bold text-red-400 uppercase tracking-widest">
                            {pattern}
                          </span>
                        ))}
                      </div>
                    )}

                    <div className="space-y-3">
                      <p className="text-[8px] font-bold text-amber-500 uppercase tracking-[0.3em]">Protocolos Sugeridos:</p>
                      {aiHabits.priorityHabits.map((h, i) => (
                        <div key={i} className="flex items-center gap-3 text-[11px] text-slate-300">
                          <CheckCircle2 size={14} className="text-amber-500" />
                          <span className="font-bold border-b border-white/5 pb-0.5">{h.title}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-indigo-500/5 border border-indigo-500/10 p-6 rounded-[1.5rem]">
                    <h4 className="text-[8px] font-bold text-indigo-400 uppercase tracking-[0.3em] mb-3 flex items-center gap-2">
                      <Target size={14} /> Salto Quântico 7 Dias
                    </h4>
                    <p className="text-xs text-slate-200 font-bold mb-2">{aiHabits.sevenDayChallenge.goal}</p>
                    <div className="p-3 bg-slate-950/50 rounded-xl border border-white/5 text-[10px] text-indigo-200 italic-serif leading-relaxed">
                      {aiHabits.sevenDayChallenge.dailyAction}
                    </div>
                  </div>
                </motion.div>
              ) : (
                <div className="bg-slate-950/50 border border-white/5 p-6 rounded-[1.5rem] space-y-4">
                  <p className="text-xs text-slate-400 font-medium leading-relaxed italic-serif">
                    Gere uma matriz de hábitos alinhada ao estado atual.
                  </p>
                  <button 
                    onClick={generateAIHabits}
                    disabled={isGeneratingAI}
                    className="w-full bg-amber-500 text-white px-4 py-2.5 rounded-xl text-[9px] font-bold flex items-center justify-center gap-2 shadow-lg shadow-amber-500/20 hover:bg-amber-400 transition-all uppercase tracking-widest active:scale-95"
                  >
                    {isGeneratingAI ? <RefreshCcw className="animate-spin" size={14} /> : <Sparkles size={14} />}
                    {isGeneratingAI ? 'Sincronizando...' : 'Iniciar Mapeamento'}
                  </button>
                </div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Right Column: Habit Categories and List */}
        <div className="lg:col-span-8 flex flex-col gap-6">
          {/* Category Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide px-1">
            {HABIT_CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={cn(
                  "px-4 py-3 rounded-2xl border whitespace-nowrap transition-all flex items-center gap-2 group",
                  selectedCategory === cat.id
                    ? "bg-slate-950 border-white/10 text-white shadow-xl scale-105"
                    : "bg-slate-900/50 border-white/5 text-slate-500 hover:border-white/10 hover:bg-slate-900"
                )}
              >
                <div className={cn(
                  "w-7 h-7 rounded-lg flex items-center justify-center transition-all",
                  selectedCategory === cat.id ? "bg-amber-500 text-white shadow-lg shadow-amber-500/20" : "bg-slate-950 text-slate-600 group-hover:text-amber-400"
                )}>
                  {cat.id === 'amor' && <Heart size={14} />}
                  {cat.id === 'saúde' && <Zap size={14} />}
                  {cat.id === 'família' && <Users size={14} />}
                  {cat.id === 'espiritualidade' && <Sparkles size={14} />}
                  {cat.id === 'mindset' && <Brain size={14} />}
                  {cat.id === 'inteligência emocional' && <Target size={14} />}
                  {cat.id === 'negócios' && <Briefcase size={14} />}
                </div>
                <span className="text-[9px] font-bold uppercase tracking-[0.1em]">{cat.label}</span>
              </button>
            ))}
          </div>

          {/* Current Category Habits */}
          <div className="space-y-6">
            <div className="flex items-center justify-between border-l-[4px] border-amber-500 pl-4 bg-amber-500/5 py-3 rounded-r-2xl">
              <div>
                <h2 className="text-xl font-bold text-white italic-serif tracking-tight">Círculo de Hábitos</h2>
                <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Sincronização Ativa</p>
              </div>
              <div className="flex gap-2 pr-2">
                <span className="px-3 py-1 bg-slate-950 border border-white/5 rounded-lg text-[8px] font-bold text-slate-500 uppercase tracking-widest">Total: {SUGGESTED_HABITS[selectedCategory as keyof typeof SUGGESTED_HABITS]?.length || 0}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {SUGGESTED_HABITS[selectedCategory as keyof typeof SUGGESTED_HABITS]?.map((habit, idx) => (
                <motion.div
                  key={idx}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.05 }}
                  className={cn(
                    "p-6 rounded-[2rem] border transition-all group relative overflow-hidden backdrop-blur-md",
                    isHabitCompleted(habit.title)
                      ? "bg-slate-950/30 border-white/5 opacity-40"
                      : "bg-slate-900/50 border-white/5 hover:border-amber-500/30 hover:bg-slate-900 shadow-xl"
                  )}
                >
                  <div className="flex justify-between items-start mb-6">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center transition-all group-hover:scale-110",
                      isHabitCompleted(habit.title) ? "bg-slate-950 text-slate-700" : "bg-slate-950 text-amber-500 border border-white/5 shadow-inner"
                    )}>
                      {isHabitCompleted(habit.title) ? <ShieldCheck size={20} /> : <CircleDashed size={20} className="animate-pulse" />}
                    </div>
                    {isHabitCompleted(habit.title) ? (
                      <div className="px-3 py-1 bg-emerald-500 text-white rounded-full text-[8px] font-bold tracking-[0.2em] uppercase">
                        Integrado
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 text-[8px] font-bold text-slate-500 uppercase tracking-widest bg-slate-950 px-3 py-1 rounded-lg border border-white/5">
                        +12 EP
                      </div>
                    )}
                  </div>

                  <h3 className={cn(
                    "text-lg font-bold mb-2 group-hover:text-amber-400 transition-colors italic-serif tracking-tight",
                    isHabitCompleted(habit.title) ? "text-slate-600 line-through" : "text-white"
                  )}>
                    {habit.title}
                  </h3>
                  <p className={cn(
                    "text-xs mb-6 leading-relaxed italic-serif font-medium",
                    isHabitCompleted(habit.title) ? "text-slate-700" : "text-slate-400"
                  )}>
                    {habit.description}
                  </p>

                  <div className="flex items-center justify-between pt-4 border-t border-white/5">
                    <div className="flex -space-x-2">
                       {[1, 2, 3].map(i => (
                         <div key={i} className="w-6 h-6 rounded-full bg-slate-950 border border-slate-900 flex items-center justify-center text-[7px] font-bold text-slate-500">
                            {i}
                         </div>
                       ))}
                    </div>
                    <button 
                      onClick={() => toggleHabit(habit.title)}
                      className={cn(
                        "flex items-center gap-2 px-6 py-2 rounded-xl font-bold text-[9px] transition-all uppercase tracking-[0.1em] active:scale-95",
                        isHabitCompleted(habit.title)
                          ? "bg-slate-950 text-slate-600 border border-white/5"
                          : "bg-white text-slate-900 hover:bg-slate-100"
                      )}
                    >
                      {isHabitCompleted(habit.title) ? "Reabrir" : "Concluir"}
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

