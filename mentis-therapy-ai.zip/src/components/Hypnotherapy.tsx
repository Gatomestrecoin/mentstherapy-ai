import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Wind, 
  Sparkles, 
  RefreshCcw,
  Play,
  FileText,
  Copy,
  CheckCircle2,
  Brain
} from 'lucide-react';
import { cn } from '../lib/utils';

const FOCUS_CATEGORIES = [
  {
    title: '🧠 Emocional',
    items: [
      { id: 'ansiedade', label: 'ansiedade' },
      { id: 'depressao', label: 'depressão' },
      { id: 'panico', label: 'síndrome do pânico' },
      { id: 'fobias', label: 'fobias' },
      { id: 'medo', label: 'medo' },
      { id: 'estresse', label: 'estresse' },
      { id: 'burnout', label: 'burnout' },
      { id: 'autoestima', label: 'baixa autoestima' },
      { id: 'timidez', label: 'timidez' },
      { id: 'inseguranca', label: 'insegurança' },
      { id: 'dependencia', label: 'dependência emocional' },
    ]
  },
  {
    title: '🍔 Compulsões',
    items: [
      { id: 'alimentar', label: 'compulsão alimentar' },
      { id: 'acucar', label: 'açúcar' },
      { id: 'alcool', label: 'álcool' },
      { id: 'cigarro', label: 'cigarro' },
      { id: 'pornografia', label: 'pornografia' },
      { id: 'compras', label: 'compras' },
      { id: 'redesSocial', label: 'redes sociais' },
    ]
  },
  {
    title: '❤️ Relacionamentos',
    items: [
      { id: 'abandono', label: 'abandono' },
      { id: 'rejeicao', label: 'rejeição' },
      { id: 'traicao', label: 'traição' },
      { id: 'ciume', label: 'ciúmes' },
      { id: 'carencia', label: 'carência emocional' },
      { id: 'bloqueios', label: 'bloqueios afetivos' },
    ]
  },
  {
    title: '👶 Infância',
    items: [
      { id: 'crianca_interior', label: 'criança interior' },
      { id: 'traumas_infantis', label: 'traumas infantis' },
      { id: 'ausencia_paterna', label: 'ausência paterna' },
      { id: 'ausencia_materna', label: 'ausência materna' },
      { id: 'humilhacao', label: 'humilhação' },
      { id: 'rejeicao_familiar', label: 'rejeição familiar' },
    ]
  },
  {
    title: '💰 Mentalidade',
    items: [
      { id: 'prosperidade', label: 'prosperidade' },
      { id: 'financeiras', label: 'crenças financeiras' },
      { id: 'sucesso', label: 'destravar sucesso' },
      { id: 'produtividade', label: 'produtividade' },
      { id: 'foco', label: 'foco' },
      { id: 'disciplina', label: 'disciplina' },
    ]
  },
  {
    title: '🌙 Sono',
    items: [
      { id: 'insonia', label: 'insônia' },
      { id: 'relaxamento_profundo', label: 'relaxamento profundo' },
      { id: 'desacelerar_pensamentos', label: 'desacelerar pensamentos' },
      { id: 'sono_restaurador', label: 'sono restaurador' },
    ]
  },
  {
    title: '✨ Espiritual',
    items: [
      { id: 'paz_interior', label: 'paz interior' },
      { id: 'proposito', label: 'propósito' },
      { id: 'conexao', label: 'conexão espiritual' },
      { id: 'equilibrio', label: 'equilíbrio emocional' },
      { id: 'cura', label: 'cura emocional' },
    ]
  }
];

export default function Hypnotherapy() {
  const [selectedFocus, setSelectedFocus] = useState<string[]>([]);
  const [objective, setObjective] = useState('');
  const [patientProfile, setPatientProfile] = useState('');
  const [script, setScript] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const toggleFocus = (id: string) => {
    setSelectedFocus(prev => 
      prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]
    );
  };

  const generateScript = async () => {
    if (!objective || selectedFocus.length === 0) return;
    setIsGenerating(true);
    try {
      const allItems = FOCUS_CATEGORIES.flatMap(c => c.items);
      const res = await fetch('/api/gemini/generate-hypnosis', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          objective,
          patientProfile: patientProfile || "Adulto em processo terapêutico.",
          selectedFocus: selectedFocus.map(id => allItems.find(i => i.id === id)?.label)
        })
      });
      const data = await res.json();
      setScript(data.script);
    } catch (error) {
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(script);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="max-w-6xl mx-auto space-y-8"
    >
      <div className="text-center space-y-4">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full text-indigo-400 text-[10px] font-bold uppercase tracking-[0.2em] shadow-lg shadow-indigo-500/5">
          <Brain size={12} /> IA Clínica
        </div>
        <h1 className="text-3xl font-bold text-white tracking-tighter italic-serif">Hipnoterapia IA Inteligente</h1>
        <p className="text-slate-400 max-w-2xl mx-auto text-base leading-relaxed italic-serif">
          Arquitetura automática de roteiros personalizados para reprogramação emocional e visualização guiada.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Selection Sidebar */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-8 shadow-2xl h-fit max-h-[700px] overflow-y-auto scrollbar-hide backdrop-blur-md">
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.3em] mb-6 flex items-center gap-3 sticky top-0 bg-slate-900/0 pb-3 z-10">
              <Sparkles size={16} className="text-indigo-400" /> Matriz de Foco
            </h3>
            
            <div className="space-y-8">
              {FOCUS_CATEGORIES.map((category) => (
                <div key={category.title} className="space-y-3">
                  <h4 className="text-[8px] font-bold text-slate-600 uppercase tracking-[0.2em] border-b border-white/5 pb-1.5">
                    {category.title}
                  </h4>
                  <div className="grid grid-cols-1 gap-1.5">
                    {category.items.map((item) => (
                      <button 
                        key={item.id}
                        onClick={() => toggleFocus(item.id)}
                        className={cn(
                          "flex items-center justify-between p-3 rounded-xl border text-left transition-all group",
                          selectedFocus.includes(item.id)
                            ? "bg-indigo-600 border-indigo-500 shadow-lg shadow-indigo-600/20"
                            : "bg-slate-950/50 border-white/5 hover:border-white/10 hover:bg-white/5"
                        )}
                      >
                        <span className={cn(
                          "text-[9px] font-bold capitalize tracking-wide transition-colors",
                          selectedFocus.includes(item.id) ? "text-white" : "text-slate-500 group-hover:text-slate-300"
                        )}>
                          {item.label}
                        </span>
                        {selectedFocus.includes(item.id) && (
                          <CheckCircle2 size={12} className="text-white" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Form and Result Section */}
        <div className="lg:col-span-8 space-y-8">
          <div className="bg-slate-900/50 rounded-[2rem] border border-white/5 p-8 shadow-2xl backdrop-blur-md space-y-8">
            <div className="space-y-8">
              <div className="space-y-3">
                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.3em] flex items-center gap-2">
                  <Wind size={16} className="text-indigo-400" /> Objetivo Subconsciente
                </label>
                <textarea 
                  rows={2}
                  value={objective}
                  onChange={e => setObjective(e.target.value)}
                  placeholder="Defina o objetivo (ex: Cura de fobia social...)"
                  className="w-full bg-slate-950 border border-white/5 rounded-2xl px-6 py-4 outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all italic-serif text-lg text-slate-200 resize-none shadow-inner placeholder:text-slate-700"
                />
              </div>

              <div className="space-y-3">
                <label className="text-[9px] font-bold text-slate-500 uppercase tracking-[0.3em] flex items-center gap-2">
                  <FileText size={16} className="text-emerald-400" /> Perfil Clínico
                </label>
                <textarea 
                  rows={2}
                  value={patientProfile}
                  onChange={e => setPatientProfile(e.target.value)}
                  placeholder="Contexto traumático e particularidades..."
                  className="w-full bg-slate-950 border border-white/5 rounded-xl px-6 py-4 outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all text-[13px] text-slate-400 resize-none shadow-inner"
                />
              </div>
            </div>

            <button 
              disabled={isGenerating || !objective || selectedFocus.length === 0}
              onClick={generateScript}
              className="w-full flex items-center justify-center gap-3 bg-indigo-600 hover:bg-indigo-500 text-white p-4 rounded-xl font-bold transition-all disabled:opacity-30 shadow-2xl shadow-indigo-600/20 active:scale-95 uppercase tracking-[0.2em] text-[10px]"
            >
              {isGenerating ? (
                <RefreshCcw className="animate-spin" size={20} />
              ) : (
                <Sparkles size={20} className="text-emerald-300" />
              )}
              {isGenerating ? "Processando..." : "Sintonizar Roteiro"}
            </button>
          </div>

          <AnimatePresence>
            {script && (
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-slate-900/50 rounded-[2.5rem] border border-white/5 shadow-2xl overflow-hidden backdrop-blur-md"
              >
                <div className="p-6 bg-indigo-600 text-white flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                      <FileText size={20} />
                    </div>
                    <span className="font-bold text-[9px] uppercase tracking-[0.3em]">Protocolo IA</span>
                  </div>
                  <div className="flex gap-3">
                    <button 
                      onClick={copyToClipboard}
                      className="w-10 h-10 flex items-center justify-center hover:bg-white/10 rounded-xl transition-all border border-white/10"
                    >
                      {copied ? <CheckCircle2 size={18} className="text-emerald-300" /> : <Copy size={18} />}
                    </button>
                    <button className="flex items-center gap-2 px-6 py-2 bg-emerald-500 rounded-xl hover:bg-emerald-400 transition-all text-[9px] font-bold text-emerald-950 uppercase tracking-widest shadow-xl">
                      <Play size={14} fill="currentColor" />
                      Ouvir
                    </button>
                  </div>
                </div>
                
                <div className="p-10 space-y-8">
                  <div className="flex flex-wrap gap-2">
                    {[
                      'Indução', 'Relaxamento', 'Visualização', 'Ressignificação', 'Reprogramação'
                    ].map(step => (
                      <span key={step} className="text-[8px] font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-lg border border-emerald-500/20 flex items-center gap-1.5 uppercase tracking-widest">
                        <CheckCircle2 size={10} /> {step}
                      </span>
                    ))}
                  </div>

                  <div className="prose prose-invert max-w-none">
                    <div className="whitespace-pre-wrap leading-relaxed text-slate-300 text-base italic-serif bg-slate-950/50 p-8 rounded-[2rem] border border-white/5 shadow-inner">
                      {script}
                    </div>
                  </div>
                </div>

                <div className="p-8 bg-slate-950/80 text-slate-500 flex gap-4 border-t border-white/5">
                  <Sparkles size={24} className="text-emerald-400 shrink-0 opacity-40" />
                  <p className="text-[10px] italic leading-relaxed font-medium uppercase tracking-widest opacity-60 italic-serif">
                    ESTE PROTOCOLO UTILIZA ANCORAGEM PSICANALÍTICA. AJUSTE A CADÊNCIA VOCAL CONFORME A RESPOSTA NEURAL.
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}

