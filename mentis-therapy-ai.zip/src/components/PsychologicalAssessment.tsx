import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  ClipboardList, 
  ChevronRight, 
  ChevronLeft, 
  Save, 
  Brain, 
  TrendingUp, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight,
  Info,
  History,
  Activity,
  FileText,
  ShieldAlert,
  Zap,
  Frown,
  Meh,
  Smile,
  Target,
  Clock
} from 'lucide-react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer,
  Bar,
  BarChart as RechartsBarChart,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell
} from 'recharts';
import { cn } from '../lib/utils';
import { Patient, AssessmentResult } from '../types';

const DASS21_QUESTIONS = [
  "Achei difícil me acalmar",
  "Senti minha boca seca",
  "Não consegui vivenciar sentimentos positivos",
  "Tive dificuldade para respirar",
  "Achei difícil ter iniciativa",
  "Reagi exageradamente às situações",
  "Senti tremores",
  "Senti-me nervoso(a)",
  "Preocupei-me com situações de pânico",
  "Senti que não tinha nada a desejar",
  "Senti-me agitado(a)",
  "Achei difícil relaxar",
  "Senti-me sem ânimo",
  "Fui intolerante com interrupções",
  "Senti que entraria em pânico",
  "Não consegui me entusiasmar",
  "Senti que não tinha valor",
  "Senti-me muito sensível",
  "Senti alterações cardíacas",
  "Senti medo sem motivo",
  "Senti que a vida não tinha sentido"
];

const GDS30_QUESTIONS = [
  "Está satisfeito(a) com sua vida?",
  "Diminuiu atividades e interesses?",
  "Sente que sua vida está vazia?",
  "Sente-se frequentemente entediado(a)?",
  "Está de bom humor na maior parte do tempo?",
  "Tem medo que algo ruim aconteça?",
  "Sente-se feliz frequentemente?",
  "Sente-se desamparado(a)?",
  "Prefere ficar em casa?",
  "Acha que tem mais problemas de memória?",
  "Acha maravilhoso estar vivo(a)?",
  "Sente-se inútil?",
  "Sente-se cheio(a) de energia?",
  "Sente que sua situação não tem saída?",
  "Acredita que a maioria das pessoas está melhor?",
  "Fica aborrecido(a) frequentemente?",
  "Tem dificuldade para tomar decisões?",
  "Sua mente está clara?",
  "Evita encontros sociais?",
  "Tem dificuldade de concentração?",
  "Acorda feliz?",
  "Sente-se triste frequentemente?",
  "Chora com facilidade?",
  "Tem dificuldade em sentir prazer?",
  "Sente-se sem esperança?",
  "Tem medo do futuro?",
  "Sente-se abandonado(a)?",
  "Sente falta de motivação?",
  "Acredita que vale menos que antes?",
  "Acha difícil começar coisas novas?"
];

export default function PsychologicalAssessment({ patients }: { patients: Patient[] }) {
  const [selectedPatientId, setSelectedPatientId] = useState('');
  const [activeTab, setActiveTab] = useState<'selection' | 'dass21' | 'gds30' | 'results'>('selection');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [responses, setResponses] = useState<Record<number, number>>({});
  const [result, setResult] = useState<AssessmentResult | null>(null);
  const [history, setHistory] = useState<AssessmentResult[]>([]);

  const resetAssessment = () => {
    setCurrentQuestionIndex(0);
    setResponses({});
    setResult(null);
  };

  const startDASS = () => {
    resetAssessment();
    setActiveTab('dass21');
  };

  const startGDS = () => {
    resetAssessment();
    setActiveTab('gds30');
  };

  const currentQuestions = activeTab === 'dass21' ? DASS21_QUESTIONS : GDS30_QUESTIONS;

  const handleResponse = (value: number) => {
    setResponses(prev => ({ ...prev, [currentQuestionIndex]: value }));
    if (currentQuestionIndex < currentQuestions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      calculateResult();
    }
  };

  const calculateResult = () => {
    if (activeTab === 'dass21') {
      const depressionIndices = [2, 4, 9, 12, 15, 16, 20];
      const anxietyIndices = [1, 3, 6, 8, 14, 18, 19];
      const stressIndices = [0, 5, 7, 10, 11, 13, 17];

      const depSum = depressionIndices.reduce((sum, idx) => sum + (responses[idx] || 0), 0) * 2;
      const anxSum = anxietyIndices.reduce((sum, idx) => sum + (responses[idx] || 0), 0) * 2;
      const strSum = stressIndices.reduce((sum, idx) => sum + (responses[idx] || 0), 0) * 2;

      const getDepClass = (s: number) => {
        if (s <= 9) return 'Normal';
        if (s <= 13) return 'Leve';
        if (s <= 20) return 'Moderado';
        if (s <= 27) return 'Severo';
        return 'Extremamente Severo';
      };

      const getAnxClass = (s: number) => {
        if (s <= 7) return 'Normal';
        if (s <= 9) return 'Leve';
        if (s <= 14) return 'Moderado';
        if (s <= 19) return 'Severo';
        return 'Extremamente Severo';
      };

      const getStrClass = (s: number) => {
        if (s <= 14) return 'Normal';
        if (s <= 18) return 'Leve';
        if (s <= 25) return 'Moderado';
        if (s <= 33) return 'Severo';
        return 'Extremamente Severo';
      };

      const newResult: AssessmentResult = {
        id: Math.random().toString(36).substr(2, 9),
        patientId: selectedPatientId,
        type: 'dass21',
        date: new Date().toISOString(),
        scores: { depression: depSum, anxiety: anxSum, stress: strSum },
        classifications: {
          depression: getDepClass(depSum),
          anxiety: getAnxClass(anxSum),
          stress: getStrClass(strSum)
        },
        aiReport: {
          interpretation: generateDASSInterpretation(depSum, anxSum, strSum),
          emotionalRisk: calculateRisk(depSum, anxSum, strSum),
          recommendations: generateDASSRecommendations(depSum, anxSum, strSum),
          patterns: ["Instabilidade emocional", "Reatividade a estressores"]
        },
        responses: { ...responses }
      };

      setResult(newResult);
      setHistory(prev => [newResult, ...prev]);
      setActiveTab('results');
    } else if (activeTab === 'gds30') {
      const gdsValues = Object.values(responses) as number[];
      const gdsSum = gdsValues.reduce((sum: number, val: number) => sum + val, 0);

      const getGdsClass = (s: number) => {
        if (s <= 10) return 'Normal';
        if (s <= 20) return 'Depressão Leve/Moderada';
        return 'Depressão Severa';
      };

      const totalScore = gdsSum;
      const gdsClass = getGdsClass(totalScore);

      const newResult: AssessmentResult = {
        id: Math.random().toString(36).substr(2, 9),
        patientId: selectedPatientId,
        type: 'gds30',
        date: new Date().toISOString(),
        scores: { depression: totalScore, anxiety: 0, stress: 0, total: totalScore },
        classifications: { total: gdsClass },
        aiReport: {
          interpretation: generateGDSInterpretation(totalScore),
          emotionalRisk: totalScore > 20 ? 'severe' : totalScore > 10 ? 'moderate' : 'low',
          recommendations: generateGDSRecommendations(totalScore),
          patterns: ["Isolamento social", "Baixa motivação"]
        },
        responses: { ...responses }
      };

      setResult(newResult);
      setHistory(prev => [newResult, ...prev]);
      setActiveTab('results');
    }
  };

  const generateDASSInterpretation = (d: number, a: number, s: number) => {
    if (d > 20 || a > 15 || s > 25) {
      return "Os resultados indicam sintomas importantes de ansiedade e sofrimento emocional persistente, sugerindo necessidade de acompanhamento terapêutico intensivo e possível avaliação psiquiátrica.";
    }
    return "Níveis de sofrimento emocional dentro dos parâmetros de normalidade ou leves. Recomenda-se acompanhamento preventivo e foco em regulação emocional.";
  };

  const calculateRisk = (d: number, a: number, s: number) => {
    if (d > 27 || a > 19 || s > 33) return 'severe';
    if (d > 20 || a > 14 || s > 25) return 'high';
    if (d > 13 || a > 9 || s > 18) return 'moderate';
    return 'low';
  };

  const generateDASSRecommendations = (d: number, a: number, s: number) => {
    const recs = ["Manter diário de emoções"];
    if (d > 10) recs.push("Focar em ativação comportamental");
    if (a > 10) recs.push("Técnicas de respiração diafragmática");
    if (s > 10) recs.push("Higiene do sono e manejo de estresse");
    return recs;
  };

  const generateGDSInterpretation = (s: number) => {
    if (s > 20) return "Paciente apresenta sinais compatíveis com depressão severa geriátrica, com alto risco de prejuízo funcional.";
    if (s > 10) return "Sinais de humor deprimido persistente e baixa motivação.";
    return "Estado emocional equilibrado conforme a faixa etária.";
  };

  const generateGDSRecommendations = (s: number) => {
    const recs = ["Estimulação cognitiva diária"];
    if (s > 10) recs.push("Incentivo ao convívio social e familiar");
    return recs;
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-slate-900/50 backdrop-blur-md p-6 rounded-[2rem] border border-white/5 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight italic-serif flex items-center gap-3">
            <Brain className="text-indigo-400" />
            Avaliação Psicológica Inteligente
          </h1>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-[0.2em] mt-1 ml-10">Mapeamento Clínico Assistido por IA</p>
        </div>
        
        <div className="flex-1 max-w-xs">
          <select 
            value={selectedPatientId}
            onChange={e => setSelectedPatientId(e.target.value)}
            className="w-full bg-slate-950 border border-white/5 rounded-xl px-4 py-2.5 text-xs font-medium text-slate-300 outline-none focus:ring-2 focus:ring-indigo-500/50 appearance-none shadow-inner"
          >
            <option value="">Selecionar Consciência...</option>
            {patients.map(p => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
            <option value="demo-1">Ana Beatriz (Demo)</option>
          </select>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {activeTab === 'selection' && (
          <motion.div 
            key="selection"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6"
          >
            <AssessmentCard 
              title="DASS-21 Inteligente"
              description="Escala de Depressão, Ansiedade e Estresse com análise de rede neural e classificação automática."
              icon={Activity}
              questions={21}
              time="5-8 min"
              onClick={startDASS}
              disabled={!selectedPatientId}
            />
            <AssessmentCard 
              title="Escala Geriátrica"
              description="Avaliação de depressão em idosos (GDS-30) com triagem de risco e encaminhamento sugerido."
              icon={History}
              questions={30}
              time="10-15 min"
              onClick={startGDS}
              disabled={!selectedPatientId}
            />
          </motion.div>
        )}

        {(activeTab === 'dass21' || activeTab === 'gds30') && (
          <motion.div 
            key="questionnaire"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-slate-900/50 backdrop-blur-md rounded-[2.5rem] border border-white/5 shadow-2xl p-10 max-w-3xl mx-auto"
          >
            <div className="flex justify-between items-center mb-12">
              <button 
                onClick={() => setActiveTab('selection')}
                className="text-slate-500 hover:text-white flex items-center gap-2 transition-all group"
              >
                <ChevronLeft size={18} className="group-hover:-translate-x-1 transition-transform" />
                <span className="text-[10px] font-bold uppercase tracking-widest">Abandonar</span>
              </button>
              
              <div className="text-right">
                <span className="text-sm font-bold text-white italic-serif">{currentQuestionIndex + 1} de {currentQuestions.length}</span>
                <div className="w-48 bg-white/5 h-1.5 rounded-full mt-2 overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${((currentQuestionIndex + 1) / currentQuestions.length) * 100}%` }}
                    className="h-full bg-indigo-500 shadow-[0_0_10px_rgba(99,102,241,0.5)]"
                  />
                </div>
              </div>
            </div>

            <div className="min-h-[200px] flex flex-col justify-center mb-12">
              <motion.h2 
                key={currentQuestionIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="text-3xl font-bold text-white text-center italic-serif leading-tight px-4"
              >
                {currentQuestions[currentQuestionIndex]}
              </motion.h2>
            </div>

            <div className="space-y-4">
              {activeTab === 'dass21' ? (
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { label: "Não se aplicou", value: 0, icon: Smile, color: 'hover:border-emerald-500 hover:text-emerald-400' },
                    { label: "Algum grau", value: 1, icon: Meh, color: 'hover:border-amber-500 hover:text-amber-400' },
                    { label: "Considerável", value: 2, icon: Frown, color: 'hover:border-orange-500 hover:text-orange-400' },
                    { label: "Muito aplicado", value: 3, icon: AlertCircle, color: 'hover:border-rose-500 hover:text-rose-400' }
                  ].map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => handleResponse(opt.value)}
                      className={cn(
                        "p-6 rounded-2xl bg-white/5 border border-white/5 text-slate-400 transition-all flex flex-col items-center gap-3 group",
                        opt.color
                      )}
                    >
                      <opt.icon size={32} />
                      <span className="text-[10px] font-bold uppercase tracking-widest">{opt.label}</span>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-4">
                  <button
                    onClick={() => handleResponse(1)}
                    className="p-8 rounded-2xl bg-white/5 border border-white/5 text-slate-400 hover:border-indigo-500 hover:text-indigo-400 transition-all flex items-center justify-center gap-3 group"
                  >
                    <span className="text-xl font-bold uppercase tracking-widest">SIM</span>
                  </button>
                  <button
                    onClick={() => handleResponse(0)}
                    className="p-8 rounded-2xl bg-white/5 border border-white/5 text-slate-400 hover:border-slate-500 hover:text-white transition-all flex items-center justify-center gap-3 group"
                  >
                    <span className="text-xl font-bold uppercase tracking-widest">NÃO</span>
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {activeTab === 'results' && result && (
          <motion.div 
            key="results"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Quick Summary Bar */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <RiskCard risk={result.aiReport.emotionalRisk} />
              {result.type === 'dass21' ? (
                <>
                  <StatCard label="Depressão" value={result.classifications.depression!} score={result.scores.depression} />
                  <StatCard label="Ansiedade" value={result.classifications.anxiety!} score={result.scores.anxiety} />
                  <StatCard label="Estresse" value={result.classifications.stress!} score={result.scores.stress} />
                </>
              ) : (
                <StatCard label="Classificação" value={result.classifications.total!} score={result.scores.total!} />
              )}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Analysis */}
              <div className="lg:col-span-2 space-y-6">
                <div className="bg-slate-900/50 backdrop-blur-md rounded-[2rem] border border-white/5 shadow-2xl p-8 space-y-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-xl font-bold text-white italic-serif">Interpretação Clínica Genômica</h3>
                      <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Análise automatizada via Mentis Engine</p>
                    </div>
                    <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400 border border-indigo-500/20">
                      <Zap size={24} />
                    </div>
                  </div>

                  <div className="p-6 bg-slate-950 rounded-2xl border border-white/5 space-y-4">
                    <p className="text-slate-300 leading-relaxed italic-serif italic text-lg">
                      "{result.aiReport.interpretation}"
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-2">Encaminhamentos & Prescrições</h4>
                      <div className="space-y-2">
                        {result.aiReport.recommendations.map((rec, i) => (
                          <div key={i} className="flex items-center gap-3 p-3 bg-white/5 border border-white/5 rounded-xl text-xs font-bold text-slate-400">
                             <CheckCircle2 size={16} className="text-emerald-400" />
                             {rec}
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-2">Padrões Emocionais Identificados</h4>
                      <div className="flex flex-wrap gap-2">
                        {result.aiReport.patterns.map((p, i) => (
                          <span key={i} className="px-3 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-lg text-[10px] font-bold text-indigo-400 uppercase tracking-widest">
                            {p}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Evolution Chart */}
                <div className="bg-slate-900/50 backdrop-blur-md rounded-[2rem] border border-white/5 shadow-2xl p-8">
                  <h3 className="text-lg font-bold text-white italic-serif mb-8 flex items-center gap-3">
                    <TrendingUp className="text-emerald-400" size={20} />
                    Mapeamento de Pulso Emocional
                  </h3>
                  <div className="h-[300px] w-full">
                    {result.type === 'dass21' ? (
                      <ResponsiveContainer width="100%" height="100%">
                        <RadarChart cx="50%" cy="50%" outerRadius="80%" data={[
                          { subject: 'Depressão', A: result.scores.depression, fullMark: 42 },
                          { subject: 'Ansiedade', A: result.scores.anxiety, fullMark: 42 },
                          { subject: 'Estresse', A: result.scores.stress, fullMark: 42 },
                        ]}>
                          <PolarGrid stroke="#ffffff10" />
                          <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 'bold' }} />
                          <Radar name="Intensidade" dataKey="A" stroke="#6366f1" fill="#6366f1" fillOpacity={0.4} />
                        </RadarChart>
                      </ResponsiveContainer>
                    ) : (
                      <ResponsiveContainer width="100%" height="100%">
                        <RechartsBarChart data={[{ name: 'Escore GDS', value: result.scores.total }]}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 'bold' }} />
                          <YAxis domain={[0, 30]} axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#0f172a', border: '1px solid rgba(255,255,255,0.05)', borderRadius: '12px' }}
                            itemStyle={{ color: '#fff', fontSize: '10px', fontWeight: 'bold' }}
                          />
                          <Bar dataKey="value" radius={[10, 10, 0, 0]}>
                            {
                              [{ name: 'Escore GDS', value: result.scores.total }].map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={entry.value > 20 ? '#f43f5e' : entry.value > 10 ? '#f59e0b' : '#10b981'} />
                              ))
                            }
                          </Bar>
                        </RechartsBarChart>
                      </ResponsiveContainer>
                    )}
                  </div>
                </div>
              </div>

              {/* Sidebar Info */}
              <div className="space-y-6">
                <div className="bg-slate-900/50 backdrop-blur-md rounded-[2rem] border border-white/5 shadow-2xl p-8 space-y-6">
                  <h3 className="text-sm font-bold text-white uppercase tracking-widest flex items-center gap-2">
                    <History size={16} className="text-indigo-400" /> Histórico Evolutivo
                  </h3>
                  <div className="space-y-4">
                    {history.length > 0 ? history.map((h, i) => (
                      <div key={i} className="p-4 bg-white/5 border border-white/5 rounded-xl flex items-center justify-between group hover:bg-white/10 transition-all cursor-pointer">
                        <div>
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{new Date(h.date).toLocaleDateString()}</p>
                          <p className="text-xs font-bold text-white">{h.type === 'dass21' ? 'DASS-21' : 'GDS-30'}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest">Risco</p>
                          <span className={cn(
                            "text-[10px] font-black uppercase",
                            h.aiReport.emotionalRisk === 'severe' ? "text-rose-500" : "text-emerald-400"
                          )}>
                            {h.aiReport.emotionalRisk}
                          </span>
                        </div>
                      </div>
                    )) : (
                      <p className="text-xs text-slate-600 font-medium text-center py-4">Nenhum registro anterior.</p>
                    )}
                  </div>
                </div>

                <div className="bg-gradient-to-br from-indigo-900/40 to-indigo-950/40 rounded-[2rem] p-8 border border-white/10 shadow-2xl backdrop-blur-md space-y-6">
                  <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-indigo-400">
                    <ShieldAlert size={28} />
                  </div>
                  <h3 className="text-xl font-bold text-white italic-serif">Encaminhamento Clínico</h3>
                  <p className="text-sm text-slate-300 leading-relaxed italic-serif italic">
                    "Alerta de risco identificado. Recomenda-se acompanhamento multidisciplinar."
                  </p>
                  <button className="w-full bg-white text-indigo-950 py-4 rounded-xl text-[10px] font-bold uppercase tracking-widest hover:bg-indigo-50 transition-all shadow-xl shadow-indigo-950/40 active:scale-95">
                    Gerar Documento PDF
                  </button>
                </div>
              </div>
            </div>

            <div className="flex justify-center pt-8">
               <button 
                onClick={() => setActiveTab('selection')}
                className="px-10 py-4 bg-white/5 border border-white/5 rounded-2xl text-[10px] font-bold text-slate-400 hover:text-white hover:bg-white/10 transition-all uppercase tracking-widest flex items-center gap-3"
               >
                 <ArrowRight size={16} className="rotate-180" /> Iniciar Outra Avaliação
               </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function AssessmentCard({ title, description, icon: Icon, questions, time, onClick, disabled }: any) {
  return (
    <button 
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "bg-slate-900/50 backdrop-blur-md rounded-[2rem] p-8 border border-white/5 text-left transition-all group flex flex-col justify-between hover:bg-white/[0.03] hover:border-indigo-500/30",
        disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer active:scale-95 shadow-2xl"
      )}
    >
      <div className="space-y-6">
        <div className="w-14 h-14 bg-indigo-500/10 rounded-2xl flex items-center justify-center text-indigo-400 border border-indigo-500/20 group-hover:scale-110 transition-transform">
          <Icon size={32} />
        </div>
        <div>
          <h3 className="text-2xl font-bold text-white mb-3 italic-serif">{title}</h3>
          <p className="text-sm text-slate-500 font-medium leading-relaxed">{description}</p>
        </div>
      </div>
      
      <div className="mt-8 flex items-center justify-between pt-6 border-t border-white/5 w-full">
        <div className="flex gap-4">
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            <ClipboardList size={14} className="text-indigo-400" />
            {questions} Itens
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
            <Clock size={14} className="text-emerald-400" />
            {time}
          </div>
        </div>
        <div className="w-8 h-8 rounded-full bg-indigo-500/10 flex items-center justify-center text-indigo-400 group-hover:bg-indigo-500 group-hover:text-white transition-all">
          <ArrowRight size={16} />
        </div>
      </div>
    </button>
  );
}

function RiskCard({ risk }: { risk: 'low' | 'moderate' | 'high' | 'severe' }) {
  const configs = {
    low: { label: 'Normal / Baixo', color: 'text-emerald-400', bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
    moderate: { label: 'Risco Moderado', color: 'text-amber-400', bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
    high: { label: 'Risco Elevado', color: 'text-orange-400', bg: 'bg-orange-500/10', border: 'border-orange-500/20' },
    severe: { label: 'Risco Crítico', color: 'text-rose-500', bg: 'bg-rose-500/10', border: 'border-rose-500/20' }
  };
  const config = configs[risk];
  
  return (
    <div className={cn("p-6 rounded-2xl border flex flex-col justify-center items-center gap-2", config.bg, config.border)}>
      <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">Risco Emocional</p>
      <p className={cn("text-sm font-black uppercase tracking-[0.1em] text-center", config.color)}>{config.label}</p>
    </div>
  );
}

function StatCard({ label, value, score }: { label: string; value: string; score: number }) {
  return (
    <div className="bg-slate-900/50 p-6 rounded-2xl border border-white/5 flex flex-col justify-center items-center gap-2 shadow-xl">
      <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{label}</p>
      <p className="text-sm font-black text-white uppercase tracking-[0.1em] text-center">{value}</p>
      <p className="text-[10px] font-bold text-white/40">{score} Pontos</p>
    </div>
  );
}
