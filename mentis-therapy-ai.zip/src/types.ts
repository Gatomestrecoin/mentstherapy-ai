export interface Patient {
  id: string;
  name: string;
  preferredName?: string;
  age: number;
  cpf: string;
  phone: string;
  email: string;
  profession: string;
  maritalStatus: string;
  avatarUrl?: string;
  emotionalColor?: string; // Aura emocional
  temperament?: 'Colérico' | 'Sanguíneo' | 'Fleumático' | 'Melancólico';
  emotionalLevel?: number; // 0-100
  riskLevel?: 'low' | 'moderate' | 'high' | 'severe';
  aiSummary?: string;
  ansiedade?: number; // 0-100
  humor?: string;
  sono?: string;
  clinicalData: {
    mainComplaint: string;
    whatBroughtYouHere: string;
    expectations: string;
    durationOfSymptoms: string;
    medications: string;
    psychiatricHistory: string;
    familyHistory: string;
    infancyRelaionships: string;
    affectiveLife: string;
    spirituality: string;
    sexuality: string;
    traumas: string;
    addictions: string;
    habits: string;
    therapeuticGoals: string[];
  };
}

export interface Session {
  id: string;
  patientId: string;
  date: string;
  transcript: string;
  summary: string;
  emotions: string[];
  temperament: string;
  suggestedQuestions: string[];
  clinicalHypothesis: string;
  emotionalKeywords?: string[];
  repetitivePatterns?: string[];
  themes?: { theme: string; content: string }[];
  traumaMapping?: string[];
  beliefMapping?: string[];
  patientEvolution?: string;
  therapeuticInterventions?: string[];
}

export interface TherapeuticPlan {
  id: string;
  patientId: string;
  title: string;
  sessions: {
    number: number;
    title: string;
    description: string;
    status: 'pending' | 'completed';
    notes?: string;
    questions?: string[];
    aiInsights?: string;
  }[];
}

export interface Habit {
  id: string;
  category: 'espiritualidade' | 'amor' | 'saúde' | 'família' | 'mindset' | 'inteligência emocional' | 'negócios';
  title: string;
  description: string;
  suggestedByAI?: boolean;
}

export interface HabitLog {
  id: string;
  patientId: string;
  habitId: string;
  date: string;
  completed: boolean;
  mood?: string;
}

export interface AIPersonalizedHabits {
  priorityHabits: { title: string; description: string }[];
  sevenDayChallenge: { area: string; goal: string; dailyAction: string };
  motivationalQuote: string;
  quickExercise: string;
  scientificRationale: string;
  identifiedPatterns: string[];
}

export interface TimeTunnelData {
  id: string;
  patientId: string;
  blocks: {
    title: string;
    responses: { question: string; answer: string }[];
    analysis?: {
      traumas: string[];
      patterns: string[];
      beliefs: string[];
      emotions: string[];
      triggers: string[];
      traumaticWords: string[];
    };
  }[];
  finalReport?: {
    emotionalMap: string;
    mainTraumas: string[];
    triggers: string[];
    predominantEmotions: string[];
    coreBeliefs: string[];
    summary: string;
    timeline: { period: string; events: string[] }[];
    priorityAreas: string[];
  };
}

export interface AssessmentResult {
  id: string;
  patientId: string;
  type: 'dass21' | 'gds30';
  date: string;
  scores: {
    depression: number;
    anxiety: number;
    stress: number;
    total?: number;
  };
  classifications: {
    depression?: string;
    anxiety?: string;
    stress?: string;
    total?: string;
  };
  aiReport: {
    interpretation: string;
    emotionalRisk: 'low' | 'moderate' | 'high' | 'severe';
    recommendations: string[];
    patterns: string[];
  };
  responses: Record<number, number>;
}
